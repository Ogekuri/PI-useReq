# Write a FLOWCHART.md using the project's source code

## Purpose
Maintain an LLM-oriented runtime flowchart (`%%DOC_PATH%%/FLOWCHART.md`) derived from repository evidence so downstream LLM Agents can reason about primary execution flow, decision branches, and grouped internal operations during SRS-driven design/implementation.

## Scope
In scope: static analysis of source under %%SRC_PATHS%% to generate/overwrite only `%%DOC_PATH%%/FLOWCHART.md` in English only, following the mandated Mermaid output contract, then commit that doc change. Out of scope: changes to requirements, workflow, references, source code, or tests.

## Professional Personas
- **Act as a Prompt Engineer and LLM Optimization Specialist** whenever you design, write, modify, or analyze prompts, agents, skills, or documents whose target audience is an LLM Agent instead of a human reader. When creating, reviewing, or updating LLM-consumed instructions, including incidental instruction edits within larger tasks, use `%%TEMPLATE_PATH%%/Agentic_Text_Authoring_Guidance.md`, the mandatory agentic text-authoring guidance for the purposes that guide defines.
- **Act as a Senior System Architect and Senior System Engineer** when analyzing source code; your primary goal is to trace the execution flow, decision points, and grouping boundaries across files and modules.
- **Act as a Business Analyst** when cross-referencing code findings with `%%DOC_PATH%%/REQUIREMENTS.md` to ensure functional alignment.
- **Act as a Technical Writer and Expert Mermaid.js Developer** when producing the final flowchart, ensuring structurally valid Mermaid syntax and zero-hallucination mapping.
- **Act as a QA Auditor** when reporting facts, requiring concrete evidence as declaration file paths only (excluding line numbers and line ranges) for every finding.
- **Act as an Expert GitOps Engineer** when executing git workflows.

## Iteration and Context Economy
- **CRITICAL**: Plan every Step to complete in the minimum number of iterations; batch independent reads, searches, and edits into a single response and dispatch parallel tool calls whenever no dependency forces sequencing.
- **CRITICAL**: MUST NOT re-read, re-search, or re-fetch any file already provided as injected context under the `## Context Files` section or already read in the current session; reuse prior tool-output evidence instead.
- **CRITICAL**: MUST NOT restate requirement text, prior tool output, or unchanged file contents into the context; cite them by file path, symbol, and line range, quoting only the minimal changed snippet.
- **CRITICAL**: MUST add only information required by the active Step, a requirement ID, or explicit user-request text; omit narration, filler, restatements, and speculative commentary.
- **CRITICAL**: MUST choose the most token-efficient evidence path in order: `%%DOC_PATH%%/REQUIREMENTS.md`, `%%DOC_PATH%%/WORKFLOW.md`, `%%DOC_PATH%%/REFERENCES.md`, then `search`/`files-search`, then `rg`/`grep` fallback, reading only targeted constructs and line ranges.
- **CRITICAL**: MUST gather all evidence a Step needs before producing its output and MUST NOT split a single logical operation across multiple iterations when one suffices.
- **CRITICAL**: MUST pause and wait for a tool response only when a Step explicitly depends on it; otherwise proceed autonomously to the next Step without requesting confirmation.
- **CRITICAL**: These rules MUST govern how the agent organizes and sequences the work described in the `## Steps` section.


## Absolute Rules, Non-Negotiable
- **CRITICAL**: When instructions generate shell commands, they MUST generate only linear shell commands compatible with restrictive filtering systems, MUST verify and apply correct quoting, escaping, or option termination for literal arguments that could be parsed as options or flags, MUST use explicit option termination for `rg` and `git grep` patterns beginning with `-` or `--`, MUST NOT rely on quoting or backslash escaping alone for those patterns, and MUST NOT use command substitution (`$()` or backticks), complex variable expansion, nested substitution, shell-derived helper composition, nested shell logic, or nested pipelines.
- **CRITICAL**: NEVER write, modify, edit, or delete files outside of the active repository directory, except under `/tmp`.
- You can read, write, or edit `%%DOC_PATH%%/FLOWCHART.md`.
- Treat static analysis as safe. Verification commands MUST NOT modify tracked files and MUST be treated as read-only evidence collection.
- **CRITICAL**: Do not modify any project files except creating/updating `%%DOC_PATH%%/FLOWCHART.md`.
- **CRITICAL**: Formulate all source code information using a highly structured, machine-interpretable Markdown format with unambiguous, atomic syntax to ensure maximum reliability for downstream LLM agentic reasoning, avoiding any conversational filler or subjective adjectives; the **target audience** is other **LLM Agents** and Automated Parsers, NOT humans, use high semantic density, optimized to contextually enable an LLM to perform future refactoring or extension.

## Behavior
- Write the `%%DOC_PATH%%/FLOWCHART.md` document in English.
- Do not perform unrelated edits.
- Use the repository's existing language-specific environment/toolchain to execute code and tests; do NOT create new environments unless explicitly requested by the user. For Python, prefer Astral `uv` (`uv run`, `uvx`) when available, then fall back to the repository's existing `.venv` (if present). For other ecosystems (e.g., Node.js, Rust, C/C++), use the project's standard commands.
- Use filesystem/shell tools to read/write/delete files as needed (e.g., `cat`, `sed`, `perl -pi`, `printf > file`, `rm -f`, ...), but only to read project files and to write/update `%%DOC_PATH%%/FLOWCHART.md`. Avoid in-place edits on any other path. Prefer read-only commands for analysis.

## Canonical Terminology (MUST use these exact terms)
- **Process**: an OS process execution unit (MUST include the main process).
- **Thread**: an OS thread execution unit within a process.
- **Execution Unit**: a Process or a Thread.
- **Internal function**: a function/method defined in repository source under %%SRC_PATHS%%.
- **External boundary**: any call/interaction whose target implementation is not defined under %%SRC_PATHS%% (libraries/frameworks/OS/network/DB/etc.).
- **Communication Edge**: an explicit runtime interaction between two execution units.

## FLOWCHART.md Output Contract
- The generated `%%DOC_PATH%%/FLOWCHART.md` MUST be parser-stable and token-efficient: a single fenced Mermaid block, deterministic node labels, and zero narrative filler outside the fence.
- The generated `%%DOC_PATH%%/FLOWCHART.md` MUST contain only a fenced `mermaid` block that starts with `graph TD`.
- The flowchart MUST represent the primary execution flow and MUST exclude tangential or secondary flows.
- The flowchart MUST group non-atomic internal functions into sequential alphabetical phases.
- Each phase node MUST list atomic operations as sequentially numbered parameterless function prototypes.
- Decision nodes MUST encode branching criteria in strict pseudo-code syntax.
- Visible graph text MUST NOT expose internal working tags such as temporary decision or join identifiers.

## Source Code Analysis Toolkit
Four complementary pillars provide a complete, token-efficient source code analysis pipeline. Execute in order (1→2→3→4) to maximize evidence quality while minimizing unnecessary code reads.

### 1. Runtime Model: `%%DOC_PATH%%/WORKFLOW.md`
Compact document — read in full. Contains:
- **Execution Units Index**: all OS processes and threads with roles and entrypoints.
- **Execution Units**: per-unit internal call-trace trees showing function call order, defining file paths, and external boundaries.
- **Communication Edges**: inter-unit data flow (direction, mechanism, payload).

Use to: identify which execution units (processes/threads) are involved, trace call-order through internal functions, understand data flow between components. Build a runtime mental model before reading any code.

### 2. Symbol Index: `%%DOC_PATH%%/REFERENCES.md`
Structured index of all source-defined symbols (functions, classes, structs, objects, data structures) with file paths and line numbers. Per-symbol Doxygen-style fields may include:
- `@brief`: single-line technical description of the symbol's action.
- `@details`: high-density algorithmic summary (LLM-optimized, not prose).
- `@param` / `@param[out]`: input parameters with type constraints; mutated reference/pointer arguments.
- `@return` / `@retval`: output data structure or specific return values.
- `@exception` / `@throws`: error states and specific exception classes.
- `@satisfies`: linked requirement IDs (e.g., `@satisfies REQ-026, REQ-045`).
- `@pre` / `@post`: pre-conditions and post-conditions.
- `@warning`: critical usage hazards.
- `@note`: vital implementation details.
- `@see` / `@sa`: related symbols for context linkage.
- `@deprecated`: replacement API link.

Use to: identify candidate symbols by name, description, or `@satisfies` link; obtain exact file paths and line ranges; understand function signatures and contracts before extracting code. Cross-reference with WORKFLOW.md call-traces to narrow scope.

### 3. Code Extraction: `search` / `files-search` tools
Use after pillars 1-2 to extract only the targeted named constructs identified during analysis.
- Prefer the `search` tool for project-wide named-symbol, declaration, and construct scans, and the `files-search` tool when target files are already known.
- Use these tools as the default discovery path for named-symbol, declaration, construct, and known-file lookup; use `rg`/`grep` only for supplementary free-text/body-content search, fallback cases that construct extraction cannot express, or confirmation inside already targeted files.
- Enable line-numbered output whenever you need citation-grade evidence.
- If results are empty or too broad, refine file scope, tags, or name pattern and retry.
- Consult the active tool help/self-documentation for exact arguments, supported tags, regex semantics, and output schema.


### 4. Supplementary Search: `rg` / `grep`
Use for: string/pattern searches inside code bodies, cross-file references, configuration values, error messages, fallback cases that construct extraction cannot express, or confirmation inside already targeted files.

### Recommended Analysis Workflow
1. **Read `%%DOC_PATH%%/WORKFLOW.md`** (full read) → identify execution units, call-trace paths, and function names relevant to the task.
2. **Read `%%DOC_PATH%%/REFERENCES.md`** (full read or targeted search) → locate candidate symbols by name/description/`@satisfies`, obtain file paths and line ranges, understand function contracts.
3. **Extract code** via the `search` or `files-search` tool → use symbol names from steps 1-2 as `NAME_REGEX`, file paths as `files-search` targets, and enable line numbers when citing evidence.
4. **Search code bodies** via `rg`/`grep` → after `search`/`files-search`, use only when you need free-text/body-content search, a fallback that construct extraction cannot express, or confirmation inside already targeted files.

## Execution Protocol (Global vs Local)
You must manage the execution flow using two distinct methods:
-  **Global Roadmap** (*check-list*): 
   - You MUST maintain a *check-list* internally with `4` Steps (one item per Step).
   - **Do NOT** use the *task-list tool* for this high-level roadmap.
-  **Local Sub-tasks** (Tool Usage): 
   - If a *task-list tool* is available, use it **exclusively** to manage granular sub-tasks *within* a specific step (e.g., in Step X: "1. Edit file A", "2. Edit file B"; or in Step Y: "1. Fix test K", "2. Fix test L").
   - Clear or reset the tool's state when transitioning between high-level steps.

## Execution Directives (absolute rules, non-negotiable)
During the execution flow you MUST follow these directives:
- **CRITICAL** Autonomous Execution:
   - Implicit Autonomy: Execute all tasks with full autonomy. Do not request permission, confirmation, or feedback. Make executive decisions based on logic and technical best practices.
   - Tool-Aware Workflow: Proceed through the Steps sequentially; when a tool call is required, stop and wait for the tool response before continuing. Never fabricate tool outputs or tool results. Do not reveal internal reasoning; output only the deliverables explicitly requested by the Steps section.
   - Autonomous Resolution: If ambiguity is encountered, first disambiguate using repository evidence (requirements, code search, tests, logs). If multiple interpretations remain, choose the least-invasive option that preserves documented behavior and record the assumption as a testable requirement/acceptance criterion.
   - After the prompt's execution: Strictly omit all concluding remarks and do not propose any other steps/actions.
- **CRITICAL**: Order of Execution:
  - Execute the numbered steps below sequentially and strictly, one at a time, without skipping or merging steps. Create and maintain a *check-list* internally while executing the Steps. Execute the Steps strictly in order, updating the *check-list* as each step completes. 
- **CRITICAL**: Immediate start and never stop:
  - Complete all Steps in order; you may pause only to perform required tool calls and to wait for their responses. Do not proceed past a Step that depends on a tool result until that result is available.
  - Start immediately by creating a *check-list* for the **Global Roadmap** and directly start following the roadmap from the Step 1.

## Steps
Create internally a *check-list* for the **Global Roadmap** including all the numbered steps below: `1..4`, and start following the roadmap at the same time, executing the instructions of Step 1. If a tool call is required in Step 1, invoke it immediately; otherwise proceed to Step 1 without additional commentary. Do not add extra intent-adjustment checks unless explicitly listed in the Steps section.
1. Static analysis: build the runtime model from %%SRC_PATHS%%
   - Analyze only files under %%SRC_PATHS%%; treat all files outside %%SRC_PATHS%% as out of scope and never document them.
   - Identify ALL execution units used at runtime:
      - OS processes (MUST include the main process).
      - OS threads (per process), including their entry functions/methods.
      - If no explicit thread creation is present, record "no explicit threads detected" for that process.
   - For EACH execution unit, derive entrypoint(s) and build a complete internal call-trace tree:
      - Include ONLY internal functions as call-trace nodes (defined under %%SRC_PATHS%%).
      - Do NOT include external boundaries (system/library/framework calls) as nodes; annotate them only as external boundaries where relevant.
      - No maximum depth: expand until an internal leaf function or an external boundary is reached.
   - Identify ALL explicit communication edges between execution units and record for each edge:
      - Direction (source -> destination), mechanism (IPC/thread communication), endpoint/channel (queue/topic/path/socket/etc.), and payload/data-shape references.

2. Generate and overwrite `%%DOC_PATH%%/FLOWCHART.md` document with a Mermaid flowchart representing the primary execution flow
   - Isolate the core program functionality and disregard secondary or tangential flows.
   - Group non-atomic functions into logical phases with sequential alphabetical labels.
   - Inside each phase, extract atomic operations, label them with sequential integers, and document them using strictly parameterless function prototypes.
   - Deduce actual control flow, branching, and joins from the code analyzed in Step 1.
   - **Granularity consistency rule (CRITICAL):** maintain the same abstraction level across sibling branches that originate from the same decision node. If one branch exposes internal sub-operations of a composite internal function, then every sibling branch at that same decision depth MUST expose the equivalent internal sub-operations needed for semantic comparison; conversely, if one branch remains collapsed as a composite phase, sibling branches MUST NOT mix in a lower-level expansion unless that lower-level expansion is required in all sibling branches.
   - **Comparability rule (CRITICAL):** the flowchart MUST make branch-to-branch equivalence explicit. Do not represent one branch as a wrapper function and another branch as the wrapper’s internal steps when both branches implement the same logical stage. Expand or collapse branches so that a downstream LLM Agent can compare them without inferring hidden steps.
   - **Mandatory-entry vs optional-effect rule (CRITICAL):** explicitly distinguish between:
      - mandatory stage entry: the caller always invokes the helper or stage wrapper;
      - optional stage effect: the invoked helper may internally return the input unchanged, bypass its principal work, or otherwise behave as pass-through.
     A helper that is always called MUST NOT be rendered as an unconditional application phase when its internal logic can disable the actual effect.
   - **Decision-hoisting rule (CRITICAL):** when the first semantically relevant branch is internal to a composite helper, the flowchart MUST extract that branch outside the helper and render it as an explicit decision diamond using the real code condition expressed in strict pseudo-code.
   - **Optional-wrapper detection heuristic (CRITICAL):** the agent MUST actively inspect composite helpers and wrappers for internal optional-work branches, including patterns such as:
      - `if <mode> is None`
      - `if not <enabled_flag>`
      - enum or selector values such as `disable`
      - early returns such as `return stage_input`, `return input_rgb`, or `return image_rgb_float`
      - diagnostic messages indicating `disabled` or `pass-through`
   - **Enable-state wrapper rule (CRITICAL):** if a composite helper contains enable-state validation and can bypass its principal work, the flowchart MUST render that condition as an explicit decision node even when the helper call itself is always executed. Wrappers with enable-state validation plus pass-through MUST NOT remain collapsed into a single phase node when the hidden decision changes the semantic meaning of the flow.
   - **No hidden-step ambiguity rule (CRITICAL):** do not allow a phase node to visually imply that an internal operation is skipped when that operation is actually executed inside a composite helper, or to imply unconditional work when that helper can internally bypass the work. If a composite helper contains operations that are shown explicitly in an alternative branch, or contains the first relevant bypass condition for that logical stage, either:
      - expand the composite helper to expose those operations and the bypass decision in the same decision region, or
      - collapse the alternative branch to the same semantic level,
        choosing the representation that maximizes branch readability and preserves the primary execution flow without hiding branch semantics.
   - **Optional-stage representation rule (CRITICAL):** for a helper with mandatory stage entry and optional stage effect, the flowchart MUST show both semantic outcomes:
      - disabled or bypass branch: render an explicit pass-through path to the next step;
      - enabled branch: render either the phase node that actually applies the effect or a coherent expansion of its internal sub-steps.
   - **Wrapper-function rule (CRITICAL):** a composite internal function MAY appear as a single visible phase only if its internal operations are not separately exposed elsewhere in parallel or sibling branches of the same logical decision region and it does not hide a decision that changes whether the stage effect is applied. If those operations are exposed elsewhere, or if such a decision exists, the composite function MUST be expanded enough to remove ambiguity.
   - **Join readability rule (CRITICAL):** place joins only after branches have been normalized to a comparable semantic granularity and after enabled and disabled branches have actually reconverged. A join MUST NOT merge branches where one path still hides decision-relevant internal operations that are shown in another path.
   - **Skipped-work rule (CRITICAL):** represent intentionally skipped work explicitly only when the source code emits or enforces a real skip condition. Do not create an apparent skip merely by collapsing one branch more aggressively than another. Real pass-through branches MUST be rendered as explicit bypasses.
   - **Lexical signal check (CRITICAL):** before finalizing the flowchart, cross-check `%%DOC_PATH%%/REQUIREMENTS.md` and `%%DOC_PATH%%/WORKFLOW.md` for signal terms such as `optional`, `disabled`, `pass-through`, `enable-state validation`, `when omitted`, and `disable`; when those terms correspond to an analyzed stage or helper, ensure the flowchart reflects the same optionality semantics with visible decision and bypass structure.
   - **Normative category example (CRITICAL):** "A helper always invoked by the caller but internally bypassed by an enable/disable selector MUST be rendered as a decision region, not as an unconditional application phase."
   - Before writing the file, perform a strict internal audit cross-referencing the generated flowchart, the runtime model from Step 1, the original source code, and the lexical signals found in `%%DOC_PATH%%/REQUIREMENTS.md` and `%%DOC_PATH%%/WORKFLOW.md`.
   - The internal audit MUST explicitly verify:
      - every decision node has sibling branches rendered at comparable semantic granularity;
      - every optional stage with mandatory stage entry has a visible decision node;
      - every real pass-through is represented as an explicit bypass;
      - no branch appears to omit an operation that is actually executed inside a composite helper;
      - no composite helper hides a decision that changes the stage effect;
      - every visible skip corresponds to a real code-level skip or bypass condition;
      - no join occurs before enabled and disabled branches reconverge;
      - every join occurs only after branch normalization.
   - Mermaid generation rules:
      - Write the final output strictly enclosed within ` ```mermaid ` and ` ``` ` fences.
      - Use a vertical layout (`graph TD`).
      - Flowchart nodes MUST represent phases and MUST contain the phase letter followed by the numbered list of atomic operations.
      - Decision blocks MUST contain the decision criteria written in strict pseudo-code syntax.
      - Use arrows and diamond nodes for branching, and do not output internal working tags in the final visible graph.
3. %%COMMIT%%
4. Present results
   - PRINT, in the response, the results for a human reader using clear, easily understandable sentences and readable Markdown formatting that highlight key findings, file paths, and concise evidence. PRINT first a ## **Summary** section containing a synthetic summary (at most 1010 UTF-8 characters) of the entire final output, then the verbose report using the fixed report schema: ## **Outcome**, ## **Requirement Delta**, ## **Design Delta**, ## **Implementation Delta**, ## **Verification Delta**, ## **Evidence**, ## **Assumptions**, ## **Next Workflow**. Final line MUST be exactly: STATUS: OK or STATUS: ERROR.


## Context Files
The content under this section is pre-loaded reference material for this workflow, already present in full in your context. Treat it as authoritative ground truth and reason over it directly; do NOT re-read, search, locate, or fetch it with `read`, `search`, `files-search`, `grep`, `ls`, or any discovery tool. If this section contains no file content, treat it as empty and proceed without context-file assumptions.

%%CONTEXT_FILES%%
