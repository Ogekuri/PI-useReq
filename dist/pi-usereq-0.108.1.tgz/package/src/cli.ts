#!/usr/bin/env node
/**
 * @file
 * @brief Implements the standalone pi-usereq command-line entry point.
 * @details Parses CLI flags, resolves project configuration, dispatches tool-runner operations, and converts thrown `ReqError` instances into process-style stdout, stderr, and exit codes. Runtime is dominated by the selected subcommand. Side effects include stdout/stderr writes and any filesystem or git operations performed by delegated commands.
 */

import process from "node:process";
import { ReqError } from "./core/errors.js";
import {
  createStaticCheckLanguageConfig,
  loadConfig,
  normalizeConfigPaths,
  saveConfig,
  type UseReqConfig,
} from "./core/config.js";
import {
  loadAndRepairConfig,
  resolveProjectBase,
  runCompress,
  runFilesCompress,
  runFilesSearch,
  runFilesSummarize,
  runFilesStaticCheck,
  runFilesTokens,
  runSearch,
  runProjectStaticCheck,
  runSummarize,
  runTokens,
} from "./core/tool-runner.js";
import {
  isConfigCliInvocation,
  runConfigCli,
} from "./core/config-cli.js";
import {
  buildStaticCheckEntryIdentity,
  parseEnableStaticCheck,
  runStaticCheck,
  validateStaticCheckEntry,
} from "./core/static-check.js";
import {
  parsePackageManagerCommand,
  parsePackageManagerForceFlag,
  parsePackageManagerHelpTopic,
  parsePackageManagerUpgradeChannel,
  resolvePackageManagerInstalledVersion,
  runPackageManagerManagementCommand,
} from "./core/package-manager.js";

/**
 * @brief Represents the parsed CLI flag state for one invocation.
 * @details The interface captures every supported command and option in a normalized shape consumed by `main`. It is compile-time only and introduces no runtime cost.
 */
interface ParsedArgs {
  base?: string;
  here?: boolean;
  verbose?: boolean;
  enableLineNumbers?: boolean;
  enableStaticCheck?: string[];
  filesTokens?: string[];
  filesSummarize?: string[];
  filesCompress?: string[];
  filesSearch?: string[];
  summarize?: boolean;
  compress?: boolean;
  search?: [string, string];
  tokens?: boolean;
  filesStaticCheck?: string[];
  staticCheck?: boolean;
  testStaticCheck?: string[];
}

/**
 * @brief Parses raw CLI tokens into a normalized argument object.
 * @details Performs a single left-to-right scan, supports options with variable-length value tails, and records only the last occurrence of scalar flags. Runtime is O(n) in argument count. No external state is mutated.
 * @param[in] argv {string[]} Raw CLI arguments excluding the executable and script path.
 * @return {ParsedArgs} Parsed flag object.
 */
function parseArgs(argv: string[]): ParsedArgs {
  const parsed: ParsedArgs = {};
  const takeUntilOption = (start: number): [string[], number] => {
    const values: string[] = [];
    let index = start;
    while (index < argv.length && !argv[index]!.startsWith("--")) {
      values.push(argv[index]!);
      index += 1;
    }
    return [values, index];
  };

  let index = 0;
  while (index < argv.length) {
    const token = argv[index]!;
    switch (token) {
      case "--base":
        parsed.base = argv[index + 1];
        index += 2;
        break;
      case "--here":
        parsed.here = true;
        index += 1;
        break;
      case "--verbose":
        parsed.verbose = true;
        index += 1;
        break;
      case "--enable-line-numbers":
        parsed.enableLineNumbers = true;
        index += 1;
        break;
      case "--enable-static-check":
        parsed.enableStaticCheck = [...(parsed.enableStaticCheck ?? []), argv[index + 1] ?? ""];
        index += 2;
        break;
      case "--files-tokens": {
        const [values, next] = takeUntilOption(index + 1);
        parsed.filesTokens = values;
        index = next;
        break;
      }
      case "--files-summarize": {
        const [values, next] = takeUntilOption(index + 1);
        parsed.filesSummarize = values;
        index = next;
        break;
      }
      case "--files-compress": {
        const [values, next] = takeUntilOption(index + 1);
        parsed.filesCompress = values;
        index = next;
        break;
      }
      case "--files-find": {
        const [values, next] = takeUntilOption(index + 1);
        parsed.filesSearch = values;
        index = next;
        break;
      }
      case "--summarize":
        parsed.summarize = true;
        index += 1;
        break;
      case "--compress":
        parsed.compress = true;
        index += 1;
        break;
      case "--find":
        parsed.search = [argv[index + 1]!, argv[index + 2]!];
        index += 3;
        break;
      case "--tokens":
        parsed.tokens = true;
        index += 1;
        break;
      case "--files-static-check": {
        const [values, next] = takeUntilOption(index + 1);
        parsed.filesStaticCheck = values;
        index = next;
        break;
      }
      case "--static-check":
        parsed.staticCheck = true;
        index += 1;
        break;
      case "--test-static-check":
        parsed.testStaticCheck = argv.slice(index + 1);
        index = argv.length;
        break;
      default:
        index += 1;
        break;
    }
  }
  return parsed;
}

/**
 * @brief Writes text to stdout when non-empty.
 * @details Avoids emitting zero-length writes so callers can compose result output safely. Runtime is O(n) in text length. Side effect: writes to `process.stdout`.
 * @param[in] text {string} Text to emit.
 * @return {void} No return value.
 */
function writeStdout(text: string): void {
  if (text) process.stdout.write(text);
}

/**
 * @brief Writes text to stderr and ensures a trailing newline.
 * @details Skips empty input, appends a newline when necessary, and emits the final text to `process.stderr`. Runtime is O(n) in text length. Side effect: writes to `process.stderr`.
 * @param[in] text {string} Text to emit.
 * @return {void} No return value.
 */
function writeStderr(text: string): void {
  if (!text) return;
  process.stderr.write(text.endsWith("\n") ? text : `${text}\n`);
}

/**
 * @brief Emits a tool result object to process streams.
 * @details Writes stdout first, then stderr, and returns the embedded exit code without modification. Runtime is O(n) in total emitted text size. Side effects are stdout/stderr writes.
 * @param[in] result {{ stdout: string; stderr: string; code: number }} Command result payload.
 * @return {number} Exit code to propagate from the invoked command.
 */
function writeResult(result: { stdout: string; stderr: string; code: number }): number {
  writeStdout(result.stdout);
  writeStderr(result.stderr);
  return result.code;
}

/**
 * @brief Loads mutable project config state without persisting runtime path metadata.
 * @details Resolves the project base, loads existing config or defaults, normalizes persisted directory fields into project-relative form, and returns the in-memory pair used by CLI mutations. Runtime is dominated by config I/O. Side effects are limited to config reads.
 * @param[in] projectBase {string} Candidate project root path.
 * @return {{ base: string; config: UseReqConfig }} Validated project base and normalized in-memory config.
 * @satisfies REQ-035, REQ-146
 */
function loadMutableProjectConfig(projectBase: string): { base: string; config: UseReqConfig } {
  const base = resolveProjectBase(projectBase);
  const config = normalizeConfigPaths(base, loadConfig(base));
  return { base, config };
}

/**
 * @brief Applies repeatable `--enable-static-check` specifications to project config.
 * @details Parses each specification, validates command-backed entries before persistence, appends only non-duplicate identities in argument order, preserves existing per-language checker lists, forces each targeted language enable flag to `enable`, and writes the merged config once after all validations succeed. Runtime is O(s + e) plus PATH probing where s is spec count and e is existing entry count. Side effects include config writes.
 * @param[in] projectBase {string} Candidate project root path.
 * @param[in] specs {string[]} Raw `--enable-static-check` specifications in CLI order.
 * @return {UseReqConfig} Persisted merged project configuration.
 * @throws {ReqError} Throws when parsing or validation fails.
 * @satisfies REQ-035, REQ-036, REQ-037, REQ-253
 */
function applyEnableStaticCheckSpecs(projectBase: string, specs: string[]): UseReqConfig {
  const { base, config } = loadMutableProjectConfig(projectBase);
  const seen = new Set<string>();
  for (const [language, languageConfig] of Object.entries(config["static-check"] ?? {})) {
    for (const entry of languageConfig.checkers) {
      seen.add(buildStaticCheckEntryIdentity(language, entry));
    }
  }
  config["static-check"] ??= {};
  for (const spec of specs) {
    const [language, entry] = parseEnableStaticCheck(spec);
    validateStaticCheckEntry(entry);
    const identity = buildStaticCheckEntryIdentity(language, entry);
    if (seen.has(identity)) {
      continue;
    }
    config["static-check"][language] ??= createStaticCheckLanguageConfig([]);
    config["static-check"][language]!.enabled = "enable";
    config["static-check"][language]!.checkers.push(entry);
    seen.add(identity);
  }
  saveConfig(base, config);
  return config;
}

/**
 * @brief Executes one pi-usereq CLI invocation.
 * @details Dispatches package-management commands (`--help`, `--ver|--version`, `--upgrade [--dev|--develop] [--force]`, `--uninstall`) before standard flag parsing by scheduling the async management handler and assigning its exit code to `process.exitCode` on completion, mapping an empty argv to the `--help` command so a no-argument invocation prints the full help screen, then parses arguments, enforces mutually exclusive project-selection rules, normalizes persisted config when needed, dispatches the first matching command handler, and converts thrown `ReqError` instances into stream output plus numeric exit codes. Runtime is O(n) in argument count plus delegated command cost. Side effects include config normalization writes, stdout/stderr output, and management-command HTTP probes or package-manager child processes.
 * @param[in] argv {string[]} Raw CLI arguments. Defaults to `process.argv.slice(2)`.
 * @return {number} Process exit code for the invocation; `0` for dispatched management commands whose async completion assigns the final `process.exitCode`.
 * @throws {ReqError} Internally catches `ReqError` and returns its code; other errors are coerced into exit code `1` with stderr output.
 * @satisfies PRJ-009, DES-026, DES-027, DES-034, REQ-473, REQ-474, REQ-487, REQ-511, REQ-515, REQ-558
 */
export function main(argv = process.argv.slice(2)): number {
  try {
    const managementCommand = argv.length === 0 ? "--help" : parsePackageManagerCommand(argv);
    if (managementCommand !== undefined) {
      void runPackageManagerManagementCommand(managementCommand, {
        installedVersion: resolvePackageManagerInstalledVersion(),
        channel: parsePackageManagerUpgradeChannel(argv),
        force: parsePackageManagerForceFlag(argv),
        helpTopic: parsePackageManagerHelpTopic(argv),
      })
        .then((managementExitCode) => {
          process.exitCode = managementExitCode;
        })
        .catch((managementError: unknown) => {
          const managementMessage = managementError instanceof Error
            ? managementError.message
            : String(managementError);
          process.stderr.write(`${managementMessage}\n`);
          process.exitCode = 1;
        });
      return 0;
    }
    if (isConfigCliInvocation(argv)) {
      return runConfigCli(argv);
    }
    const args = parseArgs(argv);
    const hereOnlyProjectCommand = !!(
      args.summarize || args.compress || args.tokens || args.search || args.staticCheck
    );
    if (hereOnlyProjectCommand) {
      if (args.base) {
        throw new ReqError(
          "Error: --summarize, --compress, --tokens, --find, and --static-check do not allow --base; use --here.",
          1,
        );
      }
      args.here = true;
    }

    const projectBase = args.base ? args.base : process.cwd();
    let config: UseReqConfig;
    if (args.enableStaticCheck && args.enableStaticCheck.length > 0) {
      config = applyEnableStaticCheckSpecs(projectBase, args.enableStaticCheck);
    } else {
      if (args.here || args.base) {
        loadAndRepairConfig(projectBase);
      }
      const resolvedBase = resolveProjectBase(projectBase);
      config = normalizeConfigPaths(resolvedBase, loadConfig(resolvedBase));
    }

    if (args.filesTokens) return writeResult(runFilesTokens(args.filesTokens));
    if (args.filesSummarize) return writeResult(runFilesSummarize(args.filesSummarize, process.cwd(), args.verbose));
    if (args.filesCompress) return writeResult(runFilesCompress(args.filesCompress, process.cwd(), args.enableLineNumbers, args.verbose));
    if (args.filesSearch) return writeResult(runFilesSearch(args.filesSearch, args.enableLineNumbers, args.verbose));
    if (args.testStaticCheck) return runStaticCheck(args.testStaticCheck);
    if (args.filesStaticCheck) return writeResult(runFilesStaticCheck(args.filesStaticCheck, projectBase, config));
    if (args.summarize) return writeResult(runSummarize(projectBase, config, args.verbose));
    if (args.compress) return writeResult(runCompress(projectBase, config, args.enableLineNumbers, args.verbose));
    if (args.search) return writeResult(runSearch(projectBase, args.search[0], args.search[1], config, args.enableLineNumbers, args.verbose));
    if (args.tokens) return writeResult(runTokens(projectBase, config));
    if (args.staticCheck) return writeResult(runProjectStaticCheck(projectBase, config));
    return 0;
  } catch (error) {
    const err = error as ReqError & { stdout?: string; stderr?: string };
    writeStdout(err.stdout ?? "");
    writeStderr(err.stderr ?? err.message ?? String(error));
    return err.code ?? 1;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  process.exitCode = main();
}
