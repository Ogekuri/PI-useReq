/**
 * @file
 * @brief Provides token, size, and structure counting utilities for agent-oriented file payloads.
 * @details Wraps `js-tiktoken` encoding lookup, extracts per-file structural facts, and builds machine-oriented JSON payloads for token-centric tools. Runtime is linear in processed text size plus sort cost for derived ordering hints. Side effects are limited to filesystem reads in file-based helpers.
 */

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { detectLanguage as detectSourceLanguage } from "./compress.js";
import { parseDoxygenComment, type DoxygenFieldMap } from "./doxygen-parser.js";
import { ReqError } from "./errors.js";

/**
 * @brief Declares the tokenizer encoding used by token-count workflows.
 * @details Stores the canonical `js-tiktoken` encoding identifier reused by CLI and agent-tool token metrics. Access complexity is O(1). No side effects occur.
 */
export const TOKEN_COUNTER_ENCODING = "cl100k_base";

/**
 * @brief Enumerates supported token-payload scopes.
 * @details Distinguishes explicit-file requests from canonical-document requests while preserving one stable JSON contract. The alias is compile-time only and introduces no runtime cost.
 */
export type TokenToolScope = "explicit-files" | "canonical-docs";

/**
 * @brief Enumerates supported per-file token-entry statuses.
 * @details Separates counted files, read-time failures, and skipped inputs so downstream agents can branch without reparsing text diagnostics. The alias is compile-time only and introduces no runtime cost.
 */
export type TokenFileStatus = "counted" | "error" | "skipped";

/**
 * @brief Describes one per-file token metric record.
 * @details Stores canonical file identity plus numeric token, character, byte, and line metrics extracted from one readable file. Optional metadata remains isolated in dedicated fields so agents can access headings and Doxygen fields without reparsing monolithic text. The interface is compile-time only and introduces no runtime cost.
 */
export interface CountFileMetricsResult {
  file: string;
  tokens: number;
  chars: number;
  bytes: number;
  lines: number;
  startLineNumber: number;
  endLineNumber: number;
  fileExtension: string;
  languageName?: string;
  primaryHeadingText?: string;
  doxygenFileFields?: DoxygenFieldMap;
  error?: string;
}

/**
 * @brief Describes one file entry in the agent-oriented token payload.
 * @details Stores only the canonical identity, stable status, essential numeric metrics, and optional heading or Doxygen metadata needed for downstream reasoning. Derivable identity and filesystem-probe fields are intentionally omitted to reduce token cost. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolFileEntry {
  canonical_path: string;
  status: TokenFileStatus;
  line_count: number;
  primary_heading_text?: string;
  doxygen_file_fields?: DoxygenFieldMap;
  token_count: number;
  character_count: number;
  byte_count: number;
  error_message?: string;
}

/**
 * @brief Describes the request section of the agent-oriented token payload.
 * @details Captures tool identity, scope, path-resolution base, encoding, and requested path inventories so agents can reason about how metrics were selected. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolRequestSection {
  tool_name: string;
  scope: TokenToolScope;
  encoding_name: string;
  base_dir_path: string;
  requested_file_count: number;
  requested_input_paths: string[];
  requested_canonical_paths: string[];
  docs_dir_path?: string;
  canonical_doc_names?: string[];
}

/**
 * @brief Describes the summary section of the agent-oriented token payload.
 * @details Exposes only aggregate counts and totals that cannot be reconstructed cheaply from caller-known inputs. Derivable per-file averages are omitted to reduce token cost. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolSummarySection {
  processable_file_count: number;
  counted_file_count: number;
  error_file_count: number;
  skipped_file_count: number;
  total_token_count: number;
  total_character_count: number;
  total_byte_count: number;
  total_line_count: number;
}

/**
 * @brief Describes one skipped-input or read-error observation.
 * @details Preserves both the caller-provided path and the canonicalized path plus a stable machine-readable reason string. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolPathIssue {
  input_path: string;
  canonical_path: string;
  reason: string;
}

/**
 * @brief Describes the dominant counted file for one metric ordering.
 * @details Exposes the canonical path plus the numeric token metrics that justify why the file dominates the current context budget. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolDominantFileObservation {
  canonical_path: string;
  token_count: number;
  token_share: number;
}

/**
 * @brief Describes the source-observation subsection of the guidance payload.
 * @details Separates measured ordering facts and path issues from derived recommendations so agents can reason about raw observations independently. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolSourceObservationsSection {
  counted_paths_by_token_count_desc: string[];
  counted_paths_by_line_count_desc: string[];
  skipped_inputs: TokenToolPathIssue[];
  error_inputs: TokenToolPathIssue[];
  dominant_token_file?: TokenToolDominantFileObservation;
}

/**
 * @brief Describes one derived recommendation in the guidance payload.
 * @details Provides a stable recommendation kind, the basis metric used to derive it, and the ordered path list the agent can follow directly. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolRecommendation {
  kind: string;
  basis_metric_name: "token_count" | "line_count";
  ordered_paths: string[];
}

/**
 * @brief Describes one actionable next-step hint in the guidance payload.
 * @details Supplies a stable hint kind, a focused ordered path subset, and the goal the agent can apply without reparsing surrounding prose. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolNextStepHint {
  kind: string;
  ordered_paths: string[];
  goal: string;
}

/**
 * @brief Describes the guidance section of the agent-oriented token payload.
 * @details Separates source observations, derived recommendations, and actionable next-step hints so downstream agents can choose between raw evidence and planning heuristics without reparsing mixed prose. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolGuidanceSection {
  source_observations: TokenToolSourceObservationsSection;
  derived_recommendations: TokenToolRecommendation[];
  actionable_next_steps: TokenToolNextStepHint[];
}

/**
 * @brief Describes the full agent-oriented token payload.
 * @details Exposes only aggregate numeric totals plus per-file metrics, omitting request echoes and derived guidance that can be inferred from tool registration or recomputed by the caller. The interface is compile-time only and introduces no runtime cost.
 */
export interface TokenToolPayload {
  summary: TokenToolSummarySection;
  files: TokenToolFileEntry[];
}

/**
 * @brief Describes the options required to build one agent-oriented token payload.
 * @details Supplies tool identity, scope, path base, requested paths, and optional canonical-doc metadata while keeping counting behavior configurable through a stable object contract. The interface is compile-time only and introduces no runtime cost.
 */
export interface BuildTokenToolPayloadOptions {
  toolName: string;
  scope: TokenToolScope;
  baseDir: string;
  requestedPaths: string[];
  docsDir?: string;
  canonicalDocNames?: string[];
  encodingName?: string;
}

type TokenCounterEncoding = {
  encode(content: string): ArrayLike<number>;
};

type JsTiktokenModule = {
  getEncoding(encodingName: string): TokenCounterEncoding;
};

const require = createRequire(import.meta.url);

function defaultJsTiktokenModuleLoader(): JsTiktokenModule {
  return require("js-tiktoken") as JsTiktokenModule;
}

let jsTiktokenModuleLoader: () => JsTiktokenModule = defaultJsTiktokenModuleLoader;

/**
 * @brief Describes the process-scoped tokenizer state persisted across extension rebinds.
 * @details Stores the per-encoding shared encoders on `globalThis` because pi rebinds extension modules for `/new`, `/resume`, `/fork`, and `/reload`, while the hosting process persists across those operations, so session rebinds reuse already parsed encoders instead of re-parsing the bundled BPE ranks. The interface is compile-time only and introduces no runtime cost.
 */
interface ProcessScopedTokenCounterStore {
  readonly cachedTokenCounterEncodings: Map<string, TokenCounterEncoding>;
}

/**
 * @brief Returns the process-scoped tokenizer encoding cache.
 * @details Lazily initializes one `globalThis` record so session rebinds never re-trigger the heavy encoder construction. Runtime is O(1). Side effect: initializes process-scoped state on first access.
 * @return {ProcessScopedTokenCounterStore} Mutable process-scoped tokenizer store.
 */
function getProcessScopedTokenCounterStore(): ProcessScopedTokenCounterStore {
  const globalScope = globalThis as typeof globalThis & { __piUsereqTokenCounterStore?: ProcessScopedTokenCounterStore };
  if (!globalScope.__piUsereqTokenCounterStore) {
    globalScope.__piUsereqTokenCounterStore = { cachedTokenCounterEncodings: new Map<string, TokenCounterEncoding>() };
  }
  return globalScope.__piUsereqTokenCounterStore;
}

/**
 * @brief Resolves one shared tokenizer encoding for a `TokenCounter` construction.
 * @details Checks the process-scoped per-encoding cache first and constructs the `js-tiktoken` encoding only on the first request per encoding name, so repeated `TokenCounter` construction across the `files-tokens` runner, canonical-doc counting, and context-file measurement reuses one parsed encoder instead of re-parsing the bundled BPE ranks each time. Runtime is O(1) after the first construction for the encoding and dominated by the single deferred `getEncoding` construction otherwise. Side effect: mutates the process-scoped encoding cache on first resolution per encoding name.
 * @param[in] encodingName {string} `js-tiktoken` encoding identifier.
 * @return {TokenCounterEncoding} Cached or newly constructed tokenizer encoding.
 * @throws {ReqError} Propagates the deterministic unavailable-dependency failure when `js-tiktoken` cannot be loaded.
 */
function resolveTokenCounterEncoding(encodingName: string): TokenCounterEncoding {
  const encodings = getProcessScopedTokenCounterStore().cachedTokenCounterEncodings;
  const cachedEncoding = encodings.get(encodingName);
  if (cachedEncoding) {
    return cachedEncoding;
  }
  const encoding = loadJsTiktokenModule().getEncoding(encodingName);
  encodings.set(encodingName, encoding);
  return encoding;
}

/**
 * @brief Overrides the `js-tiktoken` loader for tests.
 * @details Enables deterministic dependency-failure tests without mutating repository dependencies on disk. Clears the process-scoped encoding cache so every loader swap observes fresh module behavior instead of encoders constructed by the previous loader. Runtime is O(e) in cached encoding count. Side effects are limited to module-local test state and cache reset.
 * @param[in] loader {(() => JsTiktokenModule) | undefined} Replacement loader, or `undefined` to restore the default loader.
 * @return {void} No return value.
 */
export function setJsTiktokenModuleLoaderForTests(loader?: () => JsTiktokenModule): void {
  jsTiktokenModuleLoader = loader ?? defaultJsTiktokenModuleLoader;
  getProcessScopedTokenCounterStore().cachedTokenCounterEncodings.clear();
}

/**
 * @brief Pre-warms the shared tokenizer encoder during idle time.
 * @details Schedules one `setImmediate` task that resolves the shared encoding through the process-scoped cache, so the one-time `require("js-tiktoken")` plus bundled BPE-rank parse never executes inside a synchronous menu or preflight critical path. The task is best-effort: loader and encoding failures are swallowed because real failures still surface deterministically at measurement time. Runtime is O(1) for scheduling plus the deferred one-time construction cost. Side effect: schedules one process task and mutates the process-scoped encoding cache when the construction succeeds.
 * @param[in] encodingName {string} `js-tiktoken` encoding identifier. Defaults to `cl100k_base`.
 * @return {void} No return value.
 */
export function prewarmTokenCounterEncoder(encodingName = TOKEN_COUNTER_ENCODING): void {
  setImmediate(() => {
    try {
      resolveTokenCounterEncoding(encodingName);
    } catch {
      // Best-effort pre-warm: dependency failures surface unchanged at measurement time.
    }
  });
}

/**
 * @brief Loads the `js-tiktoken` module on demand.
 * @details Defers dependency resolution until token counting is requested so extension registration can succeed even when the optional runtime dependency has not yet been installed. Runtime is O(1) plus module resolution cost. Side effects are limited to Node module loading.
 * @return {JsTiktokenModule} Loaded tokenizer module.
 * @throws {ReqError} Throws when `js-tiktoken` is unavailable.
 */
function loadJsTiktokenModule(): JsTiktokenModule {
  try {
    const module = jsTiktokenModuleLoader();
    if (!module || typeof module.getEncoding !== "function") {
      throw new ReqError("Error: token-count dependency 'js-tiktoken' is unavailable. Run `npm ci` in the PI-useReq repository.", 1);
    }
    return module;
  } catch (error) {
    if (error instanceof ReqError) {
      throw error;
    }
    const message = error instanceof Error ? error.message : String(error);
    if (/Cannot find (module|package) 'js-tiktoken'|ERR_MODULE_NOT_FOUND/.test(message)) {
      throw new ReqError("Error: token-count dependency 'js-tiktoken' is not installed. Run `npm ci` in the PI-useReq repository.", 1);
    }
    throw error;
  }
}

/**
 * @brief Encapsulates one tokenizer instance for repeated token counting.
 * @details Resolves the process-scoped shared encoder for the requested encoding so multiple documents and multiple counter instances are counted without repeated encoding construction; the first construction per encoding name parses the BPE ranks once and every later `TokenCounter` reuses it through the module-local cache. Counting cost is O(n) in content length. The class mutates only instance state during construction.
 */
export class TokenCounter {
  /**
   * @brief Stores the tokenizer implementation used for subsequent counts.
   * @details Holds the cached encoder resolved through the per-encoding process cache. Access complexity is O(1); construction is O(1) after the first resolution for the encoding name.
   */
  private encoding: TokenCounterEncoding;

  /**
   * @brief Initializes a token counter for one encoding family.
   * @details Resolves the shared cached tokenizer for the encoding name, constructing the underlying `js-tiktoken` encoding at most once per encoding name per process so repeated constructions from token tools and context-file measurement are constant-time cache hits. Side effects are limited to instance initialization plus the optional first-time encoding cache mutation.
   * @param[in] encodingName {string} `js-tiktoken` encoding identifier. Defaults to `cl100k_base`.
   * @return {TokenCounter} New token counter instance.
   */
  constructor(encodingName = TOKEN_COUNTER_ENCODING) {
    this.encoding = resolveTokenCounterEncoding(encodingName);
  }

  /**
   * @brief Counts tokenizer tokens for one content string.
   * @details Encodes the provided text with the cached tokenizer and returns the token sequence length. Returns `0` when encoding throws, which prevents counting failures from aborting higher-level workflows. Time complexity is O(n). No external state is mutated.
   * @param[in] content {string} Text to tokenize.
   * @return {number} Token count, or `0` when encoding fails.
   */
  countTokens(content: string): number {
    try {
      return this.encoding.encode(content).length;
    } catch {
      return 0;
    }
  }

  /**
   * @brief Counts UTF-16 code-unit characters for one string.
   * @details Returns JavaScript string length directly without normalization. Time complexity is O(1) under engine-maintained length metadata. No side effects occur.
   * @param[in] content {string} Text to measure.
   * @return {number} Raw character count.
   */
  static countChars(content: string): number {
    return content.length;
  }
}

/**
 * @brief Converts one filesystem path into the canonical token-payload path form.
 * @details Emits a slash-normalized relative path when the target is under the supplied base directory; otherwise emits a slash-normalized absolute path. Runtime is O(p) in path length. No external state is mutated.
 * @param[in] filePath {string} Candidate absolute or relative filesystem path.
 * @param[in] baseDir {string} Reference directory used for relative canonicalization.
 * @return {string} Canonicalized path string.
 */
function canonicalizeTokenPath(filePath: string, baseDir: string): string {
  const absolutePath = path.resolve(filePath);
  const absoluteBaseDir = path.resolve(baseDir);
  const relativePath = path.relative(absoluteBaseDir, absolutePath).split(path.sep).join("/");
  if (relativePath !== "" && !relativePath.startsWith("../") && relativePath !== "..") {
    return relativePath;
  }
  return absolutePath.split(path.sep).join("/");
}

/**
 * @brief Counts logical lines in one text payload.
 * @details Counts newline separators while treating a trailing newline as line termination instead of an extra empty logical line. Runtime is O(n) in text length. No side effects occur.
 * @param[in] content {string} Text payload.
 * @return {number} Logical line count; `0` for empty content.
 */
function countLines(content: string): number {
  if (content.length === 0) {
    return 0;
  }
  const newlineCount = content.match(/\r\n|\r|\n/g)?.length ?? 0;
  return /(?:\r\n|\r|\n)$/.test(content) ? newlineCount : newlineCount + 1;
}

/**
 * @brief Strips YAML front matter from markdown content before heading extraction.
 * @details Removes the first `--- ... ---` block only when it appears at the file start so heading detection can operate on semantic markdown content instead of metadata. Runtime is O(n) in content length. No side effects occur.
 * @param[in] content {string} Markdown payload.
 * @return {string} Markdown body without the leading front matter block.
 */
function stripMarkdownFrontMatter(content: string): string {
  const frontMatterMatch = content.match(/^---\r?\n[\s\S]*?\r?\n---\r?(?:\n|$)/);
  return frontMatterMatch ? content.slice(frontMatterMatch[0].length) : content;
}

/**
 * @brief Extracts the first level-one markdown heading when present.
 * @details Restricts extraction to markdown-like files, skips YAML front matter, and returns the first `# ` heading payload without surrounding whitespace. Runtime is O(n) in content length. No side effects occur.
 * @param[in] content {string} File content.
 * @param[in] filePath {string} Source path used for extension-based markdown detection.
 * @return {string | undefined} First heading text, or `undefined` when absent or the file is not markdown-like.
 */
function extractPrimaryHeadingText(content: string, filePath: string): string | undefined {
  const extension = path.extname(filePath).toLowerCase();
  if (![".md", ".markdown", ".mdx"].includes(extension)) {
    return undefined;
  }
  const headingMatch = stripMarkdownFrontMatter(content).match(/^#\s+(.+?)\s*$/m);
  return headingMatch?.[1]?.trim() || undefined;
}

/**
 * @brief Infers a file language label optimized for agent payloads.
 * @details Reuses source-language detection when available, normalizes markdown extensions explicitly, and falls back to the lowercase extension name without the leading dot. Runtime is O(1). No side effects occur.
 * @param[in] filePath {string} File path whose extension should be classified.
 * @return {string | undefined} Normalized language label, or `undefined` when the path has no usable extension.
 */
function inferLanguageName(filePath: string): string | undefined {
  const extension = path.extname(filePath).toLowerCase();
  if ([".md", ".markdown"].includes(extension)) {
    return "markdown";
  }
  if (extension === ".mdx") {
    return "mdx";
  }
  return detectSourceLanguage(filePath) ?? (extension ? extension.slice(1) : undefined);
}

/**
 * @brief Extracts leading Doxygen file fields when present.
 * @details Tests common leading-comment syntaxes, normalizes an optional shebang away before matching, and returns the first non-empty parsed Doxygen map. Runtime is O(n) in comment length. No side effects occur.
 * @param[in] content {string} File content.
 * @return {DoxygenFieldMap | undefined} Parsed Doxygen field map, or `undefined` when no supported file-level fields are present.
 */
function extractLeadingDoxygenFields(content: string): DoxygenFieldMap | undefined {
  const normalizedContent = content.replace(/^#![^\n]*\n/, "");
  const candidates = [
    normalizedContent.match(/^\s*(\/\*\*[\s\S]*?\*\/|\/\*![\s\S]*?\*\/)/)?.[1],
    normalizedContent.match(/^(?:\s*\/\/\/?!?[^\n]*(?:\n|$))+/)?.[0],
    normalizedContent.match(/^(?:\s*#(?:\s|$)[^\n]*(?:\n|$))+/)?.[0],
    normalizedContent.match(/^\s*(?:"""[\s\S]*?"""|'''[\s\S]*?''')/)?.[0],
  ];
  for (const candidate of candidates) {
    if (!candidate) {
      continue;
    }
    const fields = parseDoxygenComment(candidate);
    if (Object.keys(fields).length > 0) {
      return fields;
    }
  }
  return undefined;
}

/**
 * @brief Probes one requested path before token counting.
 * @details Resolves whether the target exists and is a regular file while capturing a stable skip reason for missing or non-file inputs. Runtime is dominated by one filesystem stat. Side effects are limited to filesystem reads.
 * @param[in] absolutePath {string} Absolute path to inspect.
 * @return {{ exists: boolean; isFile: boolean; reason?: string }} Path probe result.
 */
function probeRequestedPath(absolutePath: string): { exists: boolean; isFile: boolean; reason?: string } {
  if (!fs.existsSync(absolutePath)) {
    return { exists: false, isFile: false, reason: "not found" };
  }
  try {
    const isFile = fs.statSync(absolutePath).isFile();
    return isFile ? { exists: true, isFile: true } : { exists: true, isFile: false, reason: "not a file" };
  } catch (error) {
    return {
      exists: true,
      isFile: false,
      reason: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * @brief Builds one rich per-file metrics record from readable content.
 * @details Combines token, character, byte, and line counts with file-extension, inferred-language, heading, and Doxygen metadata extraction so agents can consume direct-access facts without reparsing the raw file. Runtime is O(n) in content length. No external state is mutated.
 * @param[in] filePath {string} Absolute or project-local file path.
 * @param[in] content {string} UTF-8 file content.
 * @param[in] counter {TokenCounter} Reused token counter instance.
 * @return {CountFileMetricsResult} Structured per-file metrics record.
 */
function buildCountFileMetricsResult(filePath: string, content: string, counter: TokenCounter): CountFileMetricsResult {
  const lineCount = countLines(content);
  return {
    file: filePath,
    tokens: counter.countTokens(content),
    chars: TokenCounter.countChars(content),
    bytes: Buffer.byteLength(content, "utf8"),
    lines: lineCount,
    startLineNumber: lineCount > 0 ? 1 : 0,
    endLineNumber: lineCount,
    fileExtension: path.extname(filePath).toLowerCase(),
    languageName: inferLanguageName(filePath),
    primaryHeadingText: extractPrimaryHeadingText(content, filePath),
    doxygenFileFields: extractLeadingDoxygenFields(content),
  };
}

/**
 * @brief Counts only tokenizer tokens and characters for one in-memory content string.
 * @details Lean variant of the former full-metrics counter used by context-file sizing: resolves the process-cached shared `TokenCounter` encoder, tokenizes the supplied text once, and pairs the result with the raw character length while skipping UTF-8 byte sizing and the logical-line regex allocation. Token and character semantics are bit-identical to the full metrics contract. Runtime is O(n) after the one-time per-encoding encoder construction. No filesystem I/O occurs.
 * @param[in] content {string} Text payload to measure.
 * @param[in] encodingName {string} Tokenizer identifier. Defaults to `cl100k_base`.
 * @return {{ tokens: number; chars: number }} Token estimate and character count for the supplied content.
 */
export function countTextTokensAndChars(content: string, encodingName = TOKEN_COUNTER_ENCODING): {
  tokens: number;
  chars: number;
} {
  const counter = new TokenCounter(encodingName);
  return {
    tokens: counter.countTokens(content),
    chars: TokenCounter.countChars(content),
  };
}

/**
 * @brief Describes one stat-signed full-metrics cache entry.
 * @details Pairs one computed `CountFileMetricsResult` with the `mtimeMs` plus `size` filesystem signature observed at computation time so later invocations can reuse the record through one stat call. The interface is compile-time only and introduces no runtime cost.
 */
interface FileMetricsCacheEntry {
  readonly statSignature: string;
  readonly result: CountFileMetricsResult;
}

/**
 * @brief Bounds the process-scoped per-file metrics cache.
 * @details Explicit-file and canonical-doc token requests measure bounded path sets per invocation, so unbounded caching would accumulate stale entries in long-lived pi hosts. Exceeding the bound clears the cache completely, which only costs one re-measurement per live path. Lookup complexity is O(1).
 */
const FILE_METRICS_CACHE_LIMIT = 128;

/**
 * @brief Describes the process-scoped per-file metrics state persisted across extension rebinds.
 * @details Stores the stat-signed full-metric records on `globalThis` because pi rebinds extension modules for `/new`, `/resume`, `/fork`, and `/reload`, while the hosting process persists across those operations, so repeated `files-tokens` and canonical-doc `tokens` invocations reuse already encoded documents instead of re-encoding unchanged content. The interface is compile-time only and introduces no runtime cost.
 */
interface ProcessScopedFileMetricsStore {
  readonly statSignedMetrics: Map<string, FileMetricsCacheEntry>;
}

/**
 * @brief Returns the process-scoped per-file metrics cache.
 * @details Lazily initializes one `globalThis` record so session rebinds never re-trigger the heavy per-file encode path. Runtime is O(1). Side effect: initializes process-scoped state on first access.
 * @return {ProcessScopedFileMetricsStore} Mutable process-scoped metrics store.
 */
function getProcessScopedFileMetricsStore(): ProcessScopedFileMetricsStore {
  const globalScope = globalThis as typeof globalThis & { __piUsereqFileMetricsStore?: ProcessScopedFileMetricsStore };
  if (!globalScope.__piUsereqFileMetricsStore) {
    globalScope.__piUsereqFileMetricsStore = { statSignedMetrics: new Map<string, FileMetricsCacheEntry>() };
  }
  return globalScope.__piUsereqFileMetricsStore;
}

/**
 * @brief Counts tokens, characters, bytes, and lines for multiple files.
 * @details Reuses a single `TokenCounter`, reuses stat-signed cached metric records for unchanged files through one stat call per path, reads changed files as UTF-8, and returns per-file metrics plus direct-access metadata such as heading and Doxygen file fields. Read failures are captured as error strings instead of aborting the entire batch, and failed targets are never cached. Runtime is O(F + S) on first measurement per content revision and O(F) in stat calls per unchanged remeasure. Side effects are limited to filesystem reads and process-scoped cache mutation.
 * @param[in] filePaths {string[]} File paths to measure.
 * @param[in] encodingName {string} Tokenizer identifier. Defaults to `cl100k_base`.
 * @return {CountFileMetricsResult[]} Per-file metrics and optional read errors.
 * @satisfies REQ-010, REQ-070, REQ-073
 */
export function countFilesMetrics(filePaths: string[], encodingName = TOKEN_COUNTER_ENCODING): CountFileMetricsResult[] {
  const counter = new TokenCounter(encodingName);
  const metricsCache = getProcessScopedFileMetricsStore().statSignedMetrics;
  return filePaths.map((filePath) => {
    let statSignature: string | undefined;
    try {
      const stat = fs.statSync(filePath);
      if (stat.isFile()) {
        statSignature = `${stat.mtimeMs}:${stat.size}`;
        const cachedEntry = metricsCache.get(filePath);
        if (cachedEntry && cachedEntry.statSignature === statSignature) {
          return { ...cachedEntry.result };
        }
      }
    } catch {
      statSignature = undefined;
    }
    try {
      const content = fs.readFileSync(filePath, "utf8");
      const result = buildCountFileMetricsResult(filePath, content, counter);
      if (statSignature !== undefined) {
        if (metricsCache.size >= FILE_METRICS_CACHE_LIMIT) {
          metricsCache.clear();
        }
        metricsCache.set(filePath, { statSignature, result });
      }
      return result;
    } catch (error) {
      return {
        file: filePath,
        tokens: 0,
        chars: 0,
        bytes: 0,
        lines: 0,
        startLineNumber: 0,
        endLineNumber: 0,
        fileExtension: path.extname(filePath).toLowerCase(),
        languageName: inferLanguageName(filePath),
        error: error instanceof Error ? error.message : String(error),
      };
    }
  });
}

/**
 * @brief Builds the agent-oriented JSON payload for token-centric tools.
 * @details Validates requested paths against the filesystem, counts token metrics for processable files, preserves caller order in the file table, and emits direct-access file facts such as sizes, headings, and optional Doxygen file fields while omitting request echoes and derived guidance. Runtime is O(F + S). Side effects are limited to filesystem reads.
 * @param[in] options {BuildTokenToolPayloadOptions} Payload-construction options.
 * @return {TokenToolPayload} Structured token payload ordered as summary then files.
 * @satisfies REQ-010, REQ-017, REQ-069, REQ-070, REQ-071, REQ-073, REQ-074, REQ-075
 */
export function buildTokenToolPayload(options: BuildTokenToolPayloadOptions): TokenToolPayload {
  const baseDir = path.resolve(options.baseDir);
  const encodingName = options.encodingName ?? TOKEN_COUNTER_ENCODING;
  const requestedEntries = options.requestedPaths.map((inputPath, index) => {
    const absolutePath = path.resolve(baseDir, inputPath);
    const pathProbe = probeRequestedPath(absolutePath);
    return {
      requestIndex: index + 1,
      absolutePath,
      canonicalPath: canonicalizeTokenPath(absolutePath, baseDir),
      pathProbe,
    };
  });
  const readableEntries = requestedEntries.filter((entry) => entry.pathProbe.isFile);
  const measuredResults = countFilesMetrics(readableEntries.map((entry) => entry.absolutePath), encodingName);
  const measuredByRequestIndex = new Map<number, CountFileMetricsResult>();
  readableEntries.forEach((entry, index) => {
    measuredByRequestIndex.set(entry.requestIndex, measuredResults[index]!);
  });
  const files: TokenToolFileEntry[] = requestedEntries.map((entry) => {
    const measured = measuredByRequestIndex.get(entry.requestIndex);
    if (!entry.pathProbe.isFile) {
      return {
        canonical_path: entry.canonicalPath,
        status: "skipped",
        line_count: 0,
        token_count: 0,
        character_count: 0,
        byte_count: 0,
        error_message: entry.pathProbe.reason ?? "not a file",
      };
    }
    const status: TokenFileStatus = measured?.error ? "error" : "counted";
    return {
      canonical_path: entry.canonicalPath,
      status,
      line_count: measured?.lines ?? 0,
      primary_heading_text: measured?.primaryHeadingText,
      doxygen_file_fields: measured?.doxygenFileFields,
      token_count: measured?.tokens ?? 0,
      character_count: measured?.chars ?? 0,
      byte_count: measured?.bytes ?? 0,
      error_message: measured?.error,
    };
  });
  const totalTokenCount = files
    .filter((entry) => entry.status === "counted")
    .reduce((sum, entry) => sum + entry.token_count, 0);
  const totalCharacterCount = files
    .filter((entry) => entry.status === "counted")
    .reduce((sum, entry) => sum + entry.character_count, 0);
  const totalByteCount = files
    .filter((entry) => entry.status === "counted")
    .reduce((sum, entry) => sum + entry.byte_count, 0);
  const totalLineCount = files
    .filter((entry) => entry.status === "counted")
    .reduce((sum, entry) => sum + entry.line_count, 0);
  const countedFileCount = files.filter((entry) => entry.status === "counted").length;
  const errorFileCount = files.filter((entry) => entry.status === "error").length;
  const skippedFileCount = files.filter((entry) => entry.status === "skipped").length;
  return {
    summary: {
      processable_file_count: countedFileCount + errorFileCount,
      counted_file_count: countedFileCount,
      error_file_count: errorFileCount,
      skipped_file_count: skippedFileCount,
      total_token_count: totalTokenCount,
      total_character_count: totalCharacterCount,
      total_byte_count: totalByteCount,
      total_line_count: totalLineCount,
    },
    files,
  };
}

/**
 * @brief Formats per-file token metrics as a human-readable summary block.
 * @details Aggregates totals, emits one status line per file, and appends a summary footer containing file, token, and character counts. Runtime is O(n). No external state is mutated.
 * @param[in] results {CountFileMetricsResult[]} Per-file metric records.
 * @return {string} Multiline summary suitable for CLI or editor output.
 */
export function formatPackSummary(results: CountFileMetricsResult[]): string {
  const lines: string[] = [];
  let totalTokens = 0;
  let totalChars = 0;
  const totalFiles = results.length;

  for (const result of results) {
    const fileName = path.basename(result.file);
    totalTokens += result.tokens;
    totalChars += result.chars;
    if (result.error) {
      lines.push(`  ❌ ${fileName}: ERROR - ${result.error}`);
    } else {
      lines.push(`  📄 ${fileName}: ${result.tokens.toLocaleString()} tokens, ${result.chars.toLocaleString()} chars`);
    }
  }

  lines.push("");
  lines.push("📊 Pack Summary:");
  lines.push("────────────────");
  lines.push(`  Total Files: ${totalFiles} files`);
  lines.push(` Total Tokens: ${totalTokens.toLocaleString()} tokens`);
  lines.push(`  Total Chars: ${totalChars.toLocaleString()} chars`);
  return lines.join("\n");
}
