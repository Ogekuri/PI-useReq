/**
 * @file
 * @brief Renders bundled pi-usereq prompts for the current project context.
 * @details Applies placeholder substitution, legacy tool-name rewrites, and conditional pi.dev governance guidance before prompt text is sent to the agent. Runtime is linear in prompt size plus replacement count. Side effects are limited to filesystem reads used for the coding-agent-docs directory check and bundled prompt loading.
 */

import fs from "node:fs";
import path from "node:path";
import {
  buildPromptReplacementPaths,
  DEFAULT_DOCS_DIR,
  DEFAULT_STATIC_CHECK_LANGUAGES,
  resolveEffectiveGitWorktreeEnabled,
  type UseReqConfig,
} from "./config.js";
import {
  comparePiUsereqStartupToolNames,
  type PiUsereqStartupToolName,
} from "./pi-usereq-tools.js";
import { computeContextOccupancyFacts, formatContextFileSize, sumEnabledContextFileTokens, type ContextFileSizeFacts } from "./context-file-size.js";
import { formatRuntimePathForDisplay, normalizeRelativeDirContract } from "./path-context.js";
import type {
  PromptCommandExecutionPlan,
  PromptCommandName,
} from "./prompt-command-runtime.js";
import { getPromptRequiredDocs } from "./prompt-command-runtime.js";
import { readBundledInstruction, readBundledPrompt } from "./resources.js";

/**
 * @brief Defines regex rewrites from legacy CLI spellings to internal tool names.
 * @details The ordered replacement table converts historical `req --...` references into names exposed by the extension runtime. Application cost is O(p*r) where p is pattern count and r is prompt length.
 */
const TOOL_REFERENCE_REPLACEMENTS: Array<[RegExp, string]> = [
  [/`req --find`/g, "`search` tool"],
  [/`req --files-find`/g, "`files-search` tool"],
  [/`req --compress`/g, "`compress` tool"],
  [/`req --tokens`/g, "`tokens` tool"],
  [/`req --static-check`/g, "`static-check` tool"],
  [/`req --files-static-check`/g, "`files-static-check` tool"],
  [/\breq --find\b/g, "search tool"],
  [/\breq --files-find\b/g, "files-search tool"],
  [/\breq --compress\b/g, "compress tool"],
  [/\breq --tokens\b/g, "tokens tool"],
  [/\breq --static-check\b/g, "static-check tool"],
  [/\breq --files-static-check\b/g, "files-static-check tool"],
];

/**
 * @brief Lists prompt names that may require pi.dev manifest governance rules.
 * @details Only prompts that inspect or mutate source code receive the conditional governance block. Membership checks are O(1) through the set representation.
 */
const PI_DEV_AWARE_PROMPT_NAMES = new Set<string>([
  "analyze",
  "change",
  "check",
  "cover",
  "create",
  "fix",
  "implement",
  "new",
  "recreate",
  "refactor",
]);
/**
 * @brief Stores the repository-relative optional pi.dev manifest path used in prompt guidance.
 * @details The constant lets rendered prompts cite the authoritative documentation manifest when present with a deterministic path. The governance block is not gated on this file; it is an optional contract source. Lookup complexity is O(1).
 */
const PI_DEV_MANIFEST_PROMPT_PATH = "docs/pi.dev/agent-document-manifest.json";
/**
 * @brief Stores the repository-relative base directory for pi.dev documentation.
 * @details Prompt guidance uses this path when instructing agents how to resolve manifest references. Lookup complexity is O(1).
 */
const PI_DEV_DOCS_PROMPT_PATH = "docs/pi.dev";
/**
 * @brief Stores the repository-relative base directory for pi.dev coding-agent documentation.
 * @details Prompt guidance cites this directory when defining the authoritative extension-to-client interface contract. Lookup complexity is O(1).
 */
const PI_DEV_CODING_AGENT_DOCS_PROMPT_PATH = `${PI_DEV_DOCS_PROMPT_PATH}/coding-agent-docs`;
/**
 * @brief Stores the repository-relative pi client source path used for interface validation guidance.
 * @details Prompt guidance cites this directory when requiring read-only validation against the pi client implementation. Lookup complexity is O(1).
 */
const PI_DEV_SOURCE_PROMPT_PATH = "pi.dev-src/pi-mono";
/**
 * @brief Stores the repository-relative root directory of the pi CLI client sources.
 * @details Prompt guidance cites this directory when declaring the permanently read-only pi CLI client reference and source-of-truth mandates for new implementations, source-code modifications, and bug fixes. Lookup complexity is O(1).
 */
const PI_DEV_SOURCE_ROOT_PROMPT_PATH = "pi.dev-src";
/**
 * @brief Defines the injected pi.dev governance guidance block.
 * @details The block requires read-only handling for documentation and pi client sources, mandatory read-only pi CLI client reference usage plus source-of-truth handling for new implementations, source-code modifications, and bug fixes, coding-agent-document review, coding-agent-document compliance, optional manifest-referenced document handling, and pi client source validation for ambiguous or bug-fix interface work. Construction happens once at module load. Access complexity is O(1).
 * @satisfies CTN-017, CTN-023, CTN-024, REQ-033, REQ-034, REQ-108, REQ-273, REQ-274, REQ-275, REQ-378
 */
const PI_DEV_CONFORMANCE_BLOCK = [
  "- Treat every path under `docs/` as read-only; do NOT modify "
    + "any documentation file, including those under `docs/pi.dev/`.",
  "- Treat every path under `pi.dev-src/` as read-only; do NOT modify "
    + `\`${PI_DEV_SOURCE_PROMPT_PATH}\` or any other pi client source.`,
  `- Every file under \`${PI_DEV_SOURCE_ROOT_PROMPT_PATH}/\` is a pi CLI client `
    + "source: it MAY and MUST be used as read-only reference material "
    + "during analysis, implementation, verification, and bug fixing.",
  `- Treat \`${PI_DEV_SOURCE_ROOT_PROMPT_PATH}/\` as the source-of-truth (SoT) `
    + "for new implementations, source-code modifications, and bug fixes; "
    + "derive pi-client-facing behavior from it without modifying it "
    + "in any way.",
  "- If the task creates or modifies software that interfaces with the "
    + `pi.dev CLI, review \`${PI_DEV_CODING_AGENT_DOCS_PROMPT_PATH}/\` `
    + "before analysis, implementation, verification, or bug fixing.",
  `- Treat \`${PI_DEV_CODING_AGENT_DOCS_PROMPT_PATH}/\` as the `
    + "authoritative read-only interface contract; new or modified "
    + "pi.dev CLI integrations MUST comply with the APIs they describe.",
  `- If \`${PI_DEV_CODING_AGENT_DOCS_PROMPT_PATH}/\` guidance is `
    + "ambiguous for extension-to-pi-client interface behavior, validate "
    + `the produced source code by analyzing \`${PI_DEV_SOURCE_PROMPT_PATH}\`.`,
  "- For bug fixes or problem resolution influenced by extension-to-pi-client "
    + "interface implementations, validate the produced source code by "
    + `analyzing \`${PI_DEV_SOURCE_PROMPT_PATH}\`.`,
  `- If \`${PI_DEV_MANIFEST_PROMPT_PATH}\` exists under \`${PI_DEV_DOCS_PROMPT_PATH}/\`, `
    + "treat every document path it references as part of the read-only "
    + "interface contract.",
].join("\n");

/**
 * @brief Builds the conditional pi.dev governance block for one rendered prompt.
 * @details Emits the coding-agent-document-driven governance rules only when the selected bundled prompt can analyze or mutate source code and the project root contains the `docs/pi.dev/coding-agent-docs/` directory; the manifest file is optional and its absence does not suppress the block. The emitted rules declare `pi.dev-src/` the permanently read-only pi CLI client reference and source-of-truth for new implementations, source-code modifications, and bug fixes. Time complexity O(1). No filesystem writes.
 * @param[in] promptName {string} Bundled prompt identifier.
 * @param[in] projectBase {string} Absolute project root used for coding-agent-docs directory existence checks.
 * @return {string} Markdown bullet block or the empty string when injection is not applicable.
 * @satisfies CTN-023, CTN-024, REQ-032, REQ-033, REQ-034, REQ-108, REQ-273, REQ-274, REQ-275, REQ-378
 */
function buildPiDevConformanceBlock(promptName: string, projectBase: string): string {
  if (!PI_DEV_AWARE_PROMPT_NAMES.has(promptName)) {
    return "";
  }
  const codingAgentDocsPath = path.join(projectBase, PI_DEV_CODING_AGENT_DOCS_PROMPT_PATH);
  if (!fs.existsSync(codingAgentDocsPath) || !fs.statSync(codingAgentDocsPath).isDirectory()) {
    return "";
  }
  return PI_DEV_CONFORMANCE_BLOCK;
}

/**
 * @brief Injects the pi.dev governance block into the prompt behavior section.
 * @details Inserts the block immediately after the `## Behavior` heading so downstream agents evaluate the rule before workflow steps. Leaves prompts unchanged when no behavior section exists or the block is already present. Time complexity O(n).
 * @param[in] text {string} Prompt markdown after placeholder replacement.
 * @param[in] promptName {string} Bundled prompt identifier.
 * @param[in] projectBase {string} Absolute project root used for coding-agent-docs directory existence checks.
 * @return {string} Prompt markdown with zero or one injected conformance block.
 * @satisfies REQ-032, REQ-033, REQ-034, REQ-108, REQ-273, REQ-274, REQ-275, REQ-378
 */
function injectPiDevConformanceBlock(text: string, promptName: string, projectBase: string): string {
  const block = buildPiDevConformanceBlock(promptName, projectBase);
  const behaviorHeading = "## Behavior\n";
  if (!block || !text.includes(behaviorHeading) || text.includes(block)) {
    return text;
  }
  return text.replace(behaviorHeading, `${behaviorHeading}${block}\n`);
}

/**
 * @brief Defines the ordered context-file injection descriptors used by `%%CONTEXT_FILES%%`.
 * @details Each entry binds the configured flag key to its canonical document file name so the renderer can iterate the documented `REQUIREMENTS.md`, `REFERENCES.md`, `WORKFLOW.md` order in one stable vector. Lookup complexity is O(1).
 * @satisfies REQ-329
 */
const CONTEXT_FILE_DESCRIPTORS: ReadonlyArray<{ flagKey: "context-files-requirements" | "context-files-references" | "context-files-workflow"; fileName: string }> = [
  { flagKey: "context-files-requirements", fileName: "REQUIREMENTS.md" },
  { flagKey: "context-files-references", fileName: "REFERENCES.md" },
  { flagKey: "context-files-workflow", fileName: "WORKFLOW.md" },
];

/**
 * @brief Builds the markdown block that replaces the `%%CONTEXT_FILES%%` prompt token.
 * @details Iterates the documented `REQUIREMENTS.md`, `REFERENCES.md`, `WORKFLOW.md` order, skips disabled flags and missing files without error, and renders each remaining file as a file-name heading, an HTML `<file name="<docs-dir>/<filename>">` reference with `%%DOC_PATH%%` pre-substituted, and the raw file content inside four-backtick `markdown` fences. Runtime is O(n) in aggregate context-file size. Side effects are limited to filesystem reads.
 * @param[in] projectBase {string} Absolute project root used to resolve the configured docs directory.
 * @param[in] config {UseReqConfig} Effective project configuration supplying the docs directory and context-file flags.
 * @return {string} Rendered markdown block, or the empty string when no enabled context file exists.
 * @satisfies REQ-329, REQ-330, REQ-331, REQ-332
 */
function buildContextFilesBlock(projectBase: string, config: UseReqConfig): string {
  const normalizedDocsDir = normalizeRelativeDirContract(config["docs-dir"]) || DEFAULT_DOCS_DIR;
  const sections: string[] = [];
  for (const { flagKey, fileName } of CONTEXT_FILE_DESCRIPTORS) {
    if (!config[flagKey]) {
      continue;
    }
    const filePath = path.join(projectBase, normalizedDocsDir, fileName);
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      continue;
    }
    const content = fs.readFileSync(filePath, "utf8");
    sections.push(
      `### ${fileName}\n\n<file name="${normalizedDocsDir}/${fileName}">\n\`\`\`\`markdown\n${content}\n\`\`\`\``,
    );
  }
  return sections.join("\n\n");
}

/**
 * @brief Rewrites bundled prompt tool references from legacy `req --...` syntax to internal tool names.
 * @details Applies deterministic global regex replacements so prompt text matches the extension-registered tool surface instead of the standalone CLI spelling. Time complexity O(p*r) where p is pattern count and r is prompt length.
 * @param[in] text {string} Prompt markdown before tool-reference normalization.
 * @return {string} Prompt markdown with internal tool names.
 * @satisfies REQ-003
 */
export function adaptPromptForInternalTools(text: string): string {
  let updated = text;
  for (const [pattern, replacement] of TOOL_REFERENCE_REPLACEMENTS) {
    updated = updated.replace(pattern, replacement);
  }
  return updated;
}

/**
 * @brief Applies literal placeholder replacements to bundled prompt markdown.
 * @details Replaces every placeholder token using split/join semantics so all occurrences are updated without regex escaping. Time complexity O(t*n) where t is replacement count and n is prompt length.
 * @param[in] text {string} Prompt markdown containing placeholder tokens.
 * @param[in] replacements {Record<string, string>} Token-to-value map.
 * @return {string} Prompt markdown with all placeholder tokens expanded.
 * @satisfies REQ-002
 */
export function applyReplacements(text: string, replacements: Record<string, string>): string {
  let updated = text;
  for (const [token, replacement] of Object.entries(replacements)) {
    updated = updated.split(token).join(replacement);
  }
  return updated;
}

/**
 * @brief Builds the prompt-command execution block injected at prompt start.
 * @details Serializes the already-completed repository validation, prompt-specific required-doc validation, worktree routing decision, and extension-owned lifecycle responsibilities so downstream agents do not repeat command-side orchestration. Time complexity is O(d) in required-doc count. No external state is mutated.
 * @param[in] promptName {PromptCommandName} Bundled prompt identifier.
 * @param[in] executionPlan {PromptCommandExecutionPlan} Prepared command execution plan.
 * @return {string} Markdown block or the empty string when runtime execution metadata is unavailable.
 * @satisfies REQ-200, REQ-201, REQ-202, REQ-206, REQ-207, REQ-208, REQ-209
 */
function buildPromptExecutionBlock(
  promptName: PromptCommandName,
  executionPlan: PromptCommandExecutionPlan | undefined,
): string {
  if (!executionPlan) {
    return "";
  }
  const requiredDocs = getPromptRequiredDocs(promptName);
  const requiredDocText = requiredDocs.length === 0
    ? "No canonical-doc precheck is required for this prompt."
    : requiredDocs.map((requirement) => requirement.fileName).join(", ");
  const preparedContextPath = formatRuntimePathForDisplay(executionPlan.contextPath);
  const worktreeLine = executionPlan.worktreeDir
    ? `3. Worktree routing already passed: created worktree-dir \`${executionPlan.worktreeDir}\` and prepared context-path \`${preparedContextPath}\`.`
    : `3. Worktree routing already passed: worktree orchestration is disabled and context-path remains \`${preparedContextPath}\`.`;
  return [
    "## Extension-Orchestrated Runtime",
    "1. Slash-command-owned git repository validation already passed before prompt dispatch.",
    `2. Prompt-specific required-doc validation already passed: ${requiredDocText}`,
    worktreeLine,
    "4. The extension owns prompt-end worktree merge and fork-session retention. Do NOT repeat repository validation, canonical-doc validation, worktree creation, or merge inside this workflow.",
  ].join("\n");
}

/**
 * @brief Injects the prompt-command execution block near the start of the rendered prompt.
 * @details Inserts the execution block immediately after the first level-1 heading so downstream agents evaluate extension-owned orchestration before workflow steps. Leaves prompts unchanged when no execution block is provided or when the block is already present. Time complexity O(n).
 * @param[in] text {string} Prompt markdown after placeholder replacement.
 * @param[in] promptName {PromptCommandName} Bundled prompt identifier.
 * @param[in] executionPlan {PromptCommandExecutionPlan | undefined} Prepared execution plan.
 * @return {string} Prompt markdown with zero or one injected execution block.
 */
function injectPromptExecutionBlock(
  text: string,
  promptName: PromptCommandName,
  executionPlan: PromptCommandExecutionPlan | undefined,
): string {
  const block = buildPromptExecutionBlock(promptName, executionPlan);
  const headingMatch = text.match(/^# .*$/m);
  if (!block || !headingMatch || text.includes(block)) {
    return text;
  }
  return text.replace(headingMatch[0], `${headingMatch[0]}\n\n${block}`);
}

/**
 * @brief Builds prompt-specific runtime placeholder replacements.
 * @details Merges shared path substitutions with prompt-scoped runtime values for `%%ARGS%%` and `%%PROMPT%%`. Time complexity is O(g log g + s) due to delegated path replacement building, where g is guideline count and s is source-directory count. Side effects are limited to filesystem reads delegated to shared path-context helpers.
 * @param[in] promptName {string} Bundled prompt identifier without the `req-` prefix.
 * @param[in] args {string} Raw user-supplied prompt arguments.
 * @param[in] projectBase {string} Absolute project root used for placeholder resolution.
 * @param[in] config {UseReqConfig} Effective project configuration used for path substitutions.
 * @return {Record<string, string>} Prompt-specific placeholder-to-value map.
 * @satisfies REQ-002, REQ-211
 */
function buildPromptReplacements(
  promptName: string,
  args: string,
  projectBase: string,
  contextPath: string,
  config: UseReqConfig,
): Record<string, string> {
  return {
    ...buildPromptReplacementPaths(projectBase, contextPath, config),
    "%%ARGS%%": args,
    "%%PROMPT%%": promptName,
  };
}

/**
 * @brief Renders the bundled git instruction injected through `%%COMMIT%%`.
 * @details Selects `resources/instructions/git_commit.md` when automatic git commit is enabled and `resources/instructions/git_read-only.md` otherwise, then applies the same runtime placeholder substitutions used by bundled prompts before returning the rendered markdown. Time complexity is O(n + g log g + s) where n is instruction size, g is guideline count, and s is source-directory count. Side effects are limited to filesystem reads.
 * @param[in] promptName {string} Bundled prompt identifier without the `req-` prefix.
 * @param[in] args {string} Raw user-supplied prompt arguments.
 * @param[in] projectBase {string} Absolute project root used for placeholder resolution.
 * @param[in] config {UseReqConfig} Effective project configuration used for path substitutions.
 * @return {string} Rendered bundled git instruction selected for the current automatic-commit mode.
 * @satisfies REQ-211, REQ-213, REQ-214
 */
function renderBundledCommitInstruction(
  promptName: string,
  args: string,
  projectBase: string,
  contextPath: string,
  config: UseReqConfig,
): string {
  const instruction = readBundledInstruction(
    config.AUTO_GIT_COMMIT === "enable" ? "git_commit" : "git_read-only",
  );
  return applyReplacements(
    instruction,
    buildPromptReplacements(promptName, args, projectBase, contextPath, config),
  );
}

/**
 * @brief Renders a bundled prompt for the current project context.
 * @details Loads the bundled markdown template, expands configuration-derived placeholders, injects extension-owned execution guidance plus conditional pi.dev governance guidance, expands the optional bundled commit instruction, and rewrites legacy tool references to internal names. Time complexity O(n) relative to prompt size plus delegated commit-instruction rendering. No tracked files are modified.
 * @param[in] promptName {string} Bundled prompt identifier.
 * @param[in] args {string} Raw user-supplied prompt arguments.
 * @param[in] projectBase {string} Absolute project root used for placeholder and manifest resolution.
 * @param[in] config {UseReqConfig} Effective project configuration used for path substitutions.
 * @param[in] executionPlan {PromptCommandExecutionPlan | undefined} Optional prompt-command execution plan used for injected runtime guidance.
 * @return {string} Fully rendered prompt markdown ready for `pi.sendUserMessage(...)`.
 * @satisfies REQ-002, REQ-003, REQ-032, REQ-033, REQ-034, REQ-108, REQ-200, REQ-201, REQ-202, REQ-206, REQ-207, REQ-208, REQ-209, REQ-211, REQ-213, REQ-214, REQ-273, REQ-274, REQ-275, REQ-378, REQ-329, REQ-330, REQ-331, REQ-332
 */
export function renderPrompt(
  promptName: string,
  args: string,
  projectBase: string,
  config: UseReqConfig,
  executionPlan?: PromptCommandExecutionPlan,
): string {
  const contextPath = executionPlan?.contextPath ?? projectBase;
  const prompt = readBundledPrompt(promptName);
  const replacements = {
    ...buildPromptReplacements(promptName, args, projectBase, contextPath, config),
    "%%COMMIT%%": renderBundledCommitInstruction(
      promptName,
      args,
      projectBase,
      contextPath,
      config,
    ),
  };
  const rendered = applyReplacements(prompt, replacements);
  const withExecutionBlock = injectPromptExecutionBlock(
    rendered,
    promptName as PromptCommandName,
    executionPlan,
  );
  const withPiDevConformance = injectPiDevConformanceBlock(
    withExecutionBlock,
    promptName,
    projectBase,
  );
  const adapted = adaptPromptForInternalTools(withPiDevConformance);
  const contextFilesBlock = buildContextFilesBlock(projectBase, config);
  if (contextFilesBlock) {
    return adapted.split("%%CONTEXT_FILES%%").join(contextFilesBlock);
  }
  return adapted.split("%%CONTEXT_FILES%%").join("");
}

/**
 * @brief Defines the custom-message type used for pi-usereq prompt-command screen summaries and hidden LLM prompt delivery.
 * @details The constant is reused as the `customType` for both the `display:true` command invocation summary and the `display:false` hidden rendered prompt so the TUI renders only the summary while the full prompt reaches the LLM agent through the same custom-message channel. Access complexity is O(1).
 * @satisfies DES-016, REQ-334
 */
export const PROMPT_COMMAND_SUMMARY_CUSTOM_TYPE = "pi-usereq-prompt-command";

/**
 * @brief Builds the on-screen command invocation summary for one bundled prompt-backed `req-<prompt>` command.
 * @details Renders the command name without the `req-` prefix in uppercase, the user request arguments, and the active configuration fields (`docs-dir`, `src-dir`, `tests-dir`, enabled context files, `AUTO_GIT_COMMIT`, effective `GIT_WORKTREE_ENABLED`, `GIT_WORKTREE_PREFIX`, enabled static-check languages, and `enabled-tools`) so the TUI shows only a compact summary while the full rendered prompt is delivered hidden to the LLM agent. When measured context-file size facts are supplied, every enabled existing context file in the `context files` field is rendered as `name(<chars>c/<tokens>t)`; when the enabled existing token total contributes tokens, the field additionally appends the `[<percent>% context]` occupancy suffix against the selected model max input context (or `[<percent>%/1.0M* context]` with the documented fallback); without facts, or for enabled missing files, the plain `name` form is rendered. Static-check languages are emitted in canonical `DEFAULT_STATIC_CHECK_LANGUAGES` order; enabled tools are emitted in documented menu order via `comparePiUsereqStartupToolNames`. The `context files`, `static code checks`, and `enabled tools` fields render the literal `none` placeholder whenever their respective enabled-item list is empty so the summary never shows a blank value. Sections are emitted in the order `Command:`, `Configuration:` with its bullet list, then `User's Request:`, each separated by one blank line. Runtime is O(l + t log t) where l is language count and t is enabled-tool count. No external state is mutated.
 * @param[in] promptName {string} Bundled prompt name without the `req-` prefix.
 * @param[in] args {string} User request arguments passed to the slash command.
 * @param[in] config {UseReqConfig} Effective project configuration supplying directory, git, static-check, and tool fields.
 * @param[in] contextFileSizes {Record<string, ContextFileSizeFacts> | undefined} Optional measured context-file size facts keyed by canonical file name, consumed for `context files` size suffixes.
 * @param[in] maxContextTokens {number | undefined} Selected model max input context tokens consumed by the occupancy suffix; undefined selects the documented 1,000,000-token fallback.
 * @return {string} Multi-line command invocation summary text.
 * @satisfies REQ-335, REQ-336, REQ-337, REQ-338, REQ-353, REQ-377, REQ-402, REQ-403, REQ-404, REQ-407
 */
export function renderPromptCommandSummary(
  promptName: string,
  args: string,
  config: UseReqConfig,
  contextFileSizes?: Record<string, ContextFileSizeFacts>,
  maxContextTokens?: number | undefined,
): string {
  const contextSegments = CONTEXT_FILE_DESCRIPTORS
    .filter((descriptor) => config[descriptor.flagKey])
    .map((descriptor) => {
      const baseName = descriptor.fileName.replace(/\.md$/, "").toLowerCase();
      const facts = contextFileSizes?.[descriptor.fileName];
      return facts?.exists ? `${baseName}(${formatContextFileSize(facts)})` : baseName;
    })
    .join(", ");
  const totalContextTokens = contextFileSizes ? sumEnabledContextFileTokens(config, contextFileSizes) : 0;
  const contextFiles = (contextSegments || "none")
    + (contextSegments && totalContextTokens > 0
      ? ` ${computeContextOccupancyFacts(totalContextTokens, maxContextTokens).suffix}`
      : "");
  const enabledLanguages = DEFAULT_STATIC_CHECK_LANGUAGES
    .filter((language) => config["static-check"][language]?.enabled === "enable")
    .join(", ") || "none";
  const enabledTools = ([...config["enabled-tools"]]
    .sort((left, right) =>
      comparePiUsereqStartupToolNames(
        left as PiUsereqStartupToolName,
        right as PiUsereqStartupToolName,
      ))
    .join(", ") || "none");
  const effectiveWorktree = resolveEffectiveGitWorktreeEnabled(
    config.AUTO_GIT_COMMIT,
    config.GIT_WORKTREE_ENABLED,
  );
  const lines: string[] = [
    `Command: ${promptName.toUpperCase()}`,
    "",
    "Configuration:",
    `- document dir:        ${config["docs-dir"]}`,
    `- source-code dirs:    ${config["src-dir"].join(", ")}`,
    `- unit tests dir:      ${config["tests-dir"]}`,
    `- context files:       ${contextFiles}`,
    `- auto git commit:     ${config.AUTO_GIT_COMMIT}`,
    `- git worktree:        ${effectiveWorktree}`,
    `- worktree prefix:     ${config.GIT_WORKTREE_PREFIX}`,
    `- static code checks:  ${enabledLanguages}`,
    `- enabled tools:       ${enabledTools}`,
    "",
    `User's Request: ${args}`,
  ];
  return lines.join("\n");
}
