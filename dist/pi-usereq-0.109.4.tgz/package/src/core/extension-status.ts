/**
 * @file
 * @brief Tracks pi-usereq extension status state and renders status-bar telemetry.
 * @details Centralizes hook interception, context-usage snapshots, active-branch lookup, run timing, and deterministic status-bar formatting for the pi-usereq extension. Runtime
 * is O(1) per event plus interval-driven re-renders while a prompt remains
 * active. Side effects are limited to in-memory state mutation and interval
 * scheduling through exported controller helpers.
 */

import type {
  AgentEndEvent,
  ContextUsage,
  ExtensionContext,
  ThemeColor,
} from "@earendil-works/pi-coding-agent";
import type { UseReqConfig } from "./config.js";
import type { PiNotifyOutcome, PiNotifySoundLevel } from "./pi-notify.js";
import type { PromptCommandExecutionPlan, PromptCommandStatusMarker } from "./prompt-command-runtime.js";
import {
  readPersistedPromptCommandTerminalState,
  restorePersistedPromptCommandRuntimeStateForSession,
  writePersistedPromptCommandRuntimeState,
} from "./prompt-command-state.js";
import { getInstallationPackageMetadata } from "./path-context.js";
import { resolveRuntimeGitBranchName } from "./runtime-project-paths.js";

/**
 * @brief Enumerates the CLI-supported theme tokens consumed by status rendering.
 * @details Restricts the status formatter to documented pi theme tokens so the
 * status bar remains compatible with the active CLI theme schema. Compile-time
 * only and introduces no runtime cost.
 */
type StatusForegroundColor = Extract<
  ThemeColor,
  "accent" | "warning" | "dim" | "error"
>;

/**
 * @brief Describes the raw theme capabilities required for status rendering.
 * @details Accepts the `ctx.ui.theme` foreground renderer used by the
 * single-line footer. Compile-time only and introduces no runtime cost.
 */
interface RawStatusTheme {
  fg: (color: StatusForegroundColor, text: string) => string;
}

/**
 * @brief Describes the normalized theme adapter used by status formatters.
 * @details Exposes deterministic label, value, foreground, and separator
 * renderers so status text generation stays independent from the raw theme API.
 * Compile-time only and introduces no runtime cost.
 */
interface StatusThemeAdapter {
  label: (fieldName: string) => string;
  value: (text: string) => string;
  colorize: (color: StatusForegroundColor, text: string) => string;
  separator: string;
}

/**
 * @brief Lists every pi lifecycle hook intercepted by pi-usereq status logic.
 * @details Preserves the canonical user-requested registration order so the
 * extension can install wrappers for all supported resource, session, agent,
 * model, tool, bash, and input hooks. Access complexity is O(1).
 */
export const PI_USEREQ_STATUS_HOOK_NAMES = [
  "resources_discover",
  "session_start",
  "session_before_switch",
  "session_before_fork",
  "session_before_compact",
  "session_compact",
  "session_shutdown",
  "session_before_tree",
  "session_tree",
  "context",
  "before_provider_request",
  "after_provider_response",
  "before_agent_start",
  "agent_start",
  "agent_end",
  "agent_settled",
  "turn_start",
  "turn_end",
  "message_start",
  "message_update",
  "message_end",
  "tool_execution_start",
  "tool_execution_update",
  "tool_execution_end",
  "model_select",
  "tool_call",
  "tool_result",
  "user_bash",
  "input",
] as const;

/**
 * @brief Represents one hook name handled by the pi-usereq status controller.
 * @details Narrows hook registration and event-update calls to the canonical
 * intercepted-hook set. Compile-time only and introduces no runtime cost.
 */
export type PiUsereqStatusHookName = (typeof PI_USEREQ_STATUS_HOOK_NAMES)[number];

/**
 * @brief Describes one prompt request tracked across extension command delivery and runtime execution.
 * @details Reuses the prepared prompt-command execution plan so status rendering and prompt-end side effects can recover the original project base, active execution base, and optional worktree metadata for the current prompt run. The alias is compile-time only and introduces no runtime cost.
 */
export type PiUsereqPromptRequest = PromptCommandExecutionPlan;

/**
 * @brief Represents one prompt-orchestration workflow state displayed in the status bar.
 * @details Narrows workflow tracking to the documented `idle`, `checking`, `running`, `merging`, `done`, `warning`, and `error` states reused by prompt-command gating, prompt-end orchestration, and status rendering. Compile-time only and introduces no runtime cost.
 */
export type PiUsereqWorkflowState = "idle" | "checking" | "running" | "merging" | "done" | "warning" | "error";

/**
 * @brief Stores the mutable runtime facts displayed by the status bar.
 * @details Persists the prompt-orchestration workflow state, the active orchestration request token, the latest context-usage snapshot, the active run start timestamp, the flag marking that the in-flight or most recently ended agent run belongs to the active prompt request, the duration of the most recently ended run recorded even when aborted, the most recent normally completed run duration, the accumulated duration of all normally completed runs, the in-memory runtime sound level, prompt-request metadata carried from command dispatch into the next runtime execution, and the deferred terminal finalization outcome plus inspected status marker recorded at intermediate `agent_end` events and consumed at orchestration termination. Runtime state is mutated in-place by controller helpers. Compile-time only and introduces no runtime cost.
 */
export interface PiUsereqStatusState {
  workflowState: PiUsereqWorkflowState;
  workflowRequest: string | undefined;
  contextUsage: ContextUsage | undefined;
  runStartTimeMs: number | undefined;
  activeRunBelongsToPrompt: boolean;
  endedRunDurationMs: number | undefined;
  lastRunDurationMs: number | undefined;
  totalRunDurationMs: number | undefined;
  runtimeSoundLevel: PiNotifySoundLevel | undefined;
  pendingPromptRequest: PiUsereqPromptRequest | undefined;
  activePromptRequest: PiUsereqPromptRequest | undefined;
  pendingFinalizationOutcome: PiNotifyOutcome | undefined;
  pendingFinalizationStatusMarker: PromptCommandStatusMarker | undefined;
  agentSettledEventSupported: boolean | undefined;
}

/**
 * @brief Stores the controller state required for event-driven status updates.
 * @details Keeps the mutable status snapshot, the current configuration, the
 * latest extension context used for rendering, and the interval handle used
 * for live elapsed-time refreshes. Compile-time only and introduces no runtime
 * cost.
 */
export interface PiUsereqStatusController {
  config: UseReqConfig | undefined;
  latestContext: ExtensionContext | undefined;
  state: PiUsereqStatusState;
  tickHandle: ReturnType<typeof setInterval> | undefined;
}

/**
 * @brief Stores the process-scoped elapsed-timer snapshot reused across session replacement.
 * @details Preserves the latest completed duration, accumulated completed runtime, and the in-flight run record (start timestamp plus prompt-ownership flag) so `/new`, `/resume`, and `/fork` can restore elapsed counters after the extension runtime is rebound, and so a terminal hook on a replacement runtime can recover the ended run's own duration and prompt association when the in-memory run timer was cleared mid-run. Compile-time only and introduces no runtime cost.
 */
interface PiUsereqStatusPersistenceStore {
  lastRunDurationMs: number | undefined;
  totalRunDurationMs: number | undefined;
  activeRunStartMs: number | undefined;
  activeRunBelongsToPrompt: boolean;
}

/**
 * @brief Defines the global property name used for elapsed-timer persistence.
 * @details The property lives on `globalThis` so prompt counters can survive extension-runtime replacement within the same pi process while remaining internal to pi-usereq. Access complexity is O(1).
 */
const PI_USEREQ_STATUS_PERSISTENCE_KEY = "__piUsereqStatusPersistenceStore";

/**
 * @brief Returns the process-scoped elapsed-timer persistence store.
 * @details Lazily initializes one internal `globalThis` record because pi rebinds extension modules for `/new`, `/resume`, `/fork`, and `/reload`, but the hosting process persists across those operations. Runtime is O(1). Side effect: initializes internal process-scoped state on first access.
 * @return {PiUsereqStatusPersistenceStore} Mutable persistence record.
 * @note Design rationale: required to preserve elapsed counters across session replacement without writing session-global menu state into project configuration.
 */
function getPiUsereqStatusPersistenceStore(): PiUsereqStatusPersistenceStore {
  const globalState = globalThis as typeof globalThis & {
    __piUsereqStatusPersistenceStore?: PiUsereqStatusPersistenceStore;
  };
  globalState[PI_USEREQ_STATUS_PERSISTENCE_KEY] ??= {
    lastRunDurationMs: undefined,
    totalRunDurationMs: undefined,
    activeRunStartMs: undefined,
    activeRunBelongsToPrompt: false,
  };
  return globalState[PI_USEREQ_STATUS_PERSISTENCE_KEY]!;
}

/**
 * @brief Restores persisted elapsed counters into one mutable status snapshot.
 * @details Copies the process-scoped last-run and accumulated completed durations into the supplied controller state so rebinding events can continue showing prior counters. Runtime is O(1). Side effect: mutates `state`.
 * @param[in,out] state {PiUsereqStatusState} Mutable status state.
 * @return {void} No return value.
 */
function restorePersistedElapsedState(state: PiUsereqStatusState): void {
  const store = getPiUsereqStatusPersistenceStore();
  state.lastRunDurationMs = store.lastRunDurationMs;
  state.totalRunDurationMs = store.totalRunDurationMs;
}

/**
 * @brief Persists elapsed counters from one mutable status snapshot.
 * @details Copies the current last-run and accumulated completed durations into the process-scoped store so later extension instances can restore them after session replacement. Runtime is O(1). Side effect: mutates internal process-scoped state.
 * @param[in] state {PiUsereqStatusState} Mutable status state snapshot.
 * @return {void} No return value.
 */
function persistElapsedState(state: PiUsereqStatusState): void {
  const store = getPiUsereqStatusPersistenceStore();
  store.lastRunDurationMs = state.lastRunDurationMs;
  store.totalRunDurationMs = state.totalRunDurationMs;
}

/**
 * @brief Persists the in-flight run record into the process-scoped elapsed store.
 * @details Mirrors the active run start timestamp plus its prompt-ownership flag onto `globalThis` so a terminal hook on a replacement extension instance can recover the exact run identity and time reference after the in-memory timer was cleared mid-run by session replacement or fault-injected state loss. The record is written only at `agent_start` and cleared at the run's terminal hook or an elapsed-state reset, so it is never inherited by a different run. Runtime is O(1). Side effect: mutates process-scoped state.
 * @param[in] state {PiUsereqStatusState} Controller state carrying the in-flight run facts.
 * @return {void} No return value.
 * @satisfies REQ-123, REQ-187
 */
function persistActiveRunState(state: PiUsereqStatusState): void {
  const store = getPiUsereqStatusPersistenceStore();
  store.activeRunStartMs = state.runStartTimeMs;
  store.activeRunBelongsToPrompt = state.activeRunBelongsToPrompt;
}

/**
 * @brief Reads the process-scoped in-flight run record.
 * @details Returns the persisted run start timestamp plus prompt-ownership flag only while a run is genuinely in flight, and `undefined` once the run's terminal hook cleared the record, so a late or duplicate terminal event can never borrow another run's timing or association. Runtime is O(1). No external state is mutated.
 * @return {{ startMs: number; belongsToPrompt: boolean } | undefined} Persisted in-flight run record when available.
 * @satisfies REQ-187
 */
function readPersistedActiveRunState(): { startMs: number; belongsToPrompt: boolean } | undefined {
  const store = getPiUsereqStatusPersistenceStore();
  return typeof store.activeRunStartMs === "number"
    ? { startMs: store.activeRunStartMs, belongsToPrompt: store.activeRunBelongsToPrompt === true }
    : undefined;
}

/**
 * @brief Clears the process-scoped in-flight run record.
 * @details Removes the persisted run start timestamp and prompt-ownership flag after a terminal hook or an elapsed-state reset so later terminal events without their own `agent_start` can never recover stale timing. Runtime is O(1). Side effect: mutates process-scoped state.
 * @return {void} No return value.
 * @satisfies REQ-187
 */
function clearPersistedActiveRunState(): void {
  const store = getPiUsereqStatusPersistenceStore();
  store.activeRunStartMs = undefined;
  store.activeRunBelongsToPrompt = false;
}

/**
 * @brief Mirrors one controller prompt state into the process-scoped persistence store.
 * @details Persists the current workflow state, the active orchestration request token, plus the pending and active prompt execution plans so prompt orchestration can survive session replacement. Runtime is O(1). Side effect: mutates process-scoped prompt-command persistence state.
 * @param[in] state {PiUsereqStatusState} Current controller state snapshot.
 * @return {void} No return value.
 */
function persistPromptCommandState(state: PiUsereqStatusState): void {
  writePersistedPromptCommandRuntimeState({
    workflowState: state.workflowState,
    workflowRequest: state.workflowRequest,
    pendingPromptRequest: state.pendingPromptRequest,
    activePromptRequest: state.activePromptRequest,
  });
}

/**
 * @brief Detects whether `session_shutdown` must preserve prompt-command state.
 * @details Keeps both the in-memory controller prompt state and the process-scoped prompt execution plan intact while pi switches from the original session into the forked execution session, because the old extension instance can keep running the initiating command handler after `session_shutdown` fires and before the replacement session fully takes over. Runtime is O(1). No external state is mutated.
 * @param[in] state {PiUsereqStatusState} Controller state before shutdown mutation.
 * @return {boolean} `true` when prompt-command state must survive the shutdown event.
 * @satisfies REQ-278
 */
export function shouldPreservePromptCommandStateOnShutdown(state: PiUsereqStatusState): boolean {
  return state.workflowState !== "idle"
    && (state.pendingPromptRequest !== undefined || state.activePromptRequest !== undefined);
}

/**
 * @brief Restores prompt-command persistence into one fresh controller when the active session matches.
 * @details Rehydrates workflow state, the active request token, and pending or active prompt execution plans only when the current session file targets the persisted execution session created for prompt orchestration. Runtime is O(1). Side effect: mutates `state` when persisted prompt state is available.
 * @param[in,out] state {PiUsereqStatusState} Mutable controller state.
 * @param[in] sessionFile {string | undefined} Current active session file.
 * @return {void} No return value.
 */
function restorePersistedPromptCommandState(
  state: PiUsereqStatusState,
  sessionFile: string | undefined,
): void {
  const persistedState = restorePersistedPromptCommandRuntimeStateForSession(sessionFile);
  if (persistedState === undefined) {
    return;
  }
  state.workflowState = persistedState.workflowState;
  state.workflowRequest = persistedState.workflowRequest;
  state.pendingPromptRequest = persistedState.pendingPromptRequest;
  state.activePromptRequest = persistedState.activePromptRequest;
}

/**
 * @brief Resolves the active session file exposed by one extension context.
 * @details Reads the session-manager session-file getter when available so prompt-command persistence can be resynchronized on every lifecycle hook after session replacement. Runtime is O(1). No external state is mutated.
 * @param[in] ctx {ExtensionContext} Active extension context.
 * @return {string | undefined} Current session file when available.
 */
function getContextSessionFile(ctx: ExtensionContext): string | undefined {
  return typeof ctx.sessionManager?.getSessionFile === "function"
    ? ctx.sessionManager.getSessionFile()
    : undefined;
}

/**
 * @brief Detects stale extension-context access after session replacement.
 * @details Matches the guarded pi runtime error emitted when one invalidated extension context, command context, or replacement-session context is accessed after session replacement or reload. Runtime is O(n) in message length only when an error is supplied. No external state is mutated.
 * @param[in] error {unknown} Candidate thrown value.
 * @return {boolean} `true` when the value matches the stale-extension-context runtime error.
 * @satisfies REQ-280
 */
export function isStaleExtensionContextError(error: unknown): boolean {
  return error instanceof Error
    && /stale after session replacement or reload/i.test(error.message);
}

/**
 * @brief Resets the in-memory and persisted elapsed counters.
 * @details Clears both completed-duration fields plus the in-flight run timer, run-ownership flag, and ended-run duration in the supplied state, mirrors the cleared counters into the process-scoped store, and clears the persisted in-flight run record. Runtime is O(1). Side effects include mutable state reset and process-scoped persistence update.
 * @param[in,out] state {PiUsereqStatusState} Mutable status state.
 * @return {void} No return value.
 * @satisfies REQ-217
 */
function resetElapsedState(state: PiUsereqStatusState): void {
  state.lastRunDurationMs = undefined;
  state.totalRunDurationMs = undefined;
  state.runStartTimeMs = undefined;
  state.activeRunBelongsToPrompt = false;
  state.endedRunDurationMs = undefined;
  persistElapsedState(state);
  clearPersistedActiveRunState();
}

/**
 * @brief Detects whether a `session_start` event must reset elapsed counters.
 * @details Treats `startup` and `reload` as hard-reset boundaries while preserving counters for `new`, `resume`, and `fork`. Runtime is O(1). No external state is mutated.
 * @param[in] event {unknown} Session-start payload.
 * @return {boolean} `true` when elapsed counters must reset.
 * @satisfies REQ-217
 */
function shouldResetElapsedStateOnSessionStart(event: unknown): boolean {
  const reason = (event as { reason?: unknown }).reason;
  return reason === "startup" || reason === "reload";
}

/**
 * @brief Detects whether a `session_start` event must reset the workflow state to `idle`.
 * @details Treats `startup` and `reload` as workflow-reset boundaries so prompt-orchestration state never leaks across boot or extension reload, while non-reset session-start reasons preserve the persisted terminal orchestration outcome. Runtime is O(1). No external state is mutated.
 * @param[in] event {unknown} Session-start payload.
 * @return {boolean} `true` when workflow state must reset to `idle`.
 * @satisfies REQ-009, REQ-221, REQ-633
 */
function shouldResetWorkflowStateOnSessionStart(event: unknown): boolean {
  const reason = (event as { reason?: unknown }).reason;
  return reason === "startup" || reason === "reload";
}

/**
 * @brief Tests whether one workflow state admits a new orchestration.
 * @details Accepts the request-less bootstrap `idle` state and the successful terminal `done` state, so a subsequent orchestration can transition `done` into `running` without an intervening reset while `warning` and `error` keep requiring an explicit `/req-reset`. Runtime is O(1). No external state is mutated.
 * @param[in] workflowState {PiUsereqWorkflowState} Candidate workflow state.
 * @return {boolean} `true` when a new orchestration may start from the supplied state.
 * @satisfies REQ-635
 */
export function isPiUsereqWorkflowStartable(workflowState: PiUsereqWorkflowState): boolean {
  return workflowState === "idle" || workflowState === "done";
}

/**
 * @brief Builds the normalized theme adapter used by pi-usereq status formatters.
 * @details Precomputes label, value, foreground, and separator renderers so
 * status formatting remains stable across real TUI themes and deterministic
 * test doubles. Runtime is O(1). No external state is mutated.
 * @param[in] theme {RawStatusTheme} Raw theme implementation from `ctx.ui.theme`.
 * @return {StatusThemeAdapter} Normalized status-theme adapter.
 */
function createStatusThemeAdapter(theme: RawStatusTheme): StatusThemeAdapter {
  const colorize = (color: StatusForegroundColor, text: string): string =>
    theme.fg(color, text);
  return {
    label: (fieldName: string): string => colorize("accent", `${fieldName}:`),
    value: (text: string): string => colorize("warning", text),
    colorize,
    separator: colorize("dim", " • "),
  };
}

/**
 * @brief Prefixes the rendered status-bar `branch` field value.
 * @details Prepends the documented `⎇` symbol plus one trailing space to the active git branch name so the field renders as `branch:⎇ <branch>` while the field label and theme token split stay unchanged. Access complexity is O(1). No external state is mutated.
 * @satisfies REQ-121
 */
const PI_USEREQ_STATUS_BRANCH_PREFIX = "⎇ ";

/**
 * @brief Resolves the active git branch value rendered in the status bar.
 * @details Reads the current branch from the active context working directory on every status render so worktree switches and restored base-session renders expose the latest branch immediately. The returned token stays prefix-free because the documented `⎇ ` display prefix is applied by `buildPiUsereqStatusText(...)`. Runtime is dominated by git execution when the working directory belongs to a repository. Side effects include subprocess creation.
 * @param[in] ctx {ExtensionContext} Active extension context.
 * @return {string} Active branch name or `unknown` when unavailable.
 * @satisfies REQ-121, REQ-283
 */
function resolveStatusBranchValue(ctx: ExtensionContext): string {
  return resolveRuntimeGitBranchName(ctx.cwd);
}

/**
 * @brief Normalizes one raw context-usage snapshot.
 * @details Preserves the runtime token and context-window counts, derives a
 * percentage when the runtime omits it, clamps negative percentages to `0`,
 * and preserves overflow above `100` for footer rendering. Runtime is O(1). No
 * external state is mutated.
 * @param[in] contextUsage {ContextUsage | undefined} Raw runtime snapshot.
 * @return {ContextUsage | undefined} Normalized snapshot.
 */
function normalizeContextUsage(
  contextUsage: ContextUsage | undefined,
): ContextUsage | undefined {
  if (!contextUsage) {
    return undefined;
  }
  const derivedPercent = contextUsage.percent ?? (
    contextUsage.tokens === null || contextUsage.contextWindow <= 0
      ? null
      : (contextUsage.tokens / contextUsage.contextWindow) * 100
  );
  return {
    ...contextUsage,
    percent: derivedPercent === null
      ? null
      : Math.max(0, derivedPercent),
  };
}

/**
 * @brief Resolves the selected model max input context tokens from one normalized context-usage snapshot.
 * @details Accepts only finite positive `contextWindow` numbers so missing, non-numeric, and non-positive runtime values degrade to `undefined`, which every context-occupancy consumer treats as the documented unknown basis. Runtime is O(1). No external state is mutated.
 * @param[in] contextUsage {ContextUsage | undefined} Normalized context-usage snapshot from the status controller state.
 * @return {number | undefined} Selected model max input context tokens, or undefined when unknown.
 * @satisfies REQ-401
 */
export function resolveModelContextWindowTokens(
  contextUsage: ContextUsage | undefined,
): number | undefined {
  const contextWindow = contextUsage?.contextWindow;
  return typeof contextWindow === "number" && Number.isFinite(contextWindow) && contextWindow > 0
    ? contextWindow
    : undefined;
}

/**
 * @brief Refreshes the stored context-usage snapshot from the active extension context.
 * @details Calls `ctx.getContextUsage()` on every intercepted event so the
 * controller retains the newest context-usage facts available from the pi
 * runtime. Runtime is O(1). Side effect: mutates `state.contextUsage`.
 * @param[in,out] state {PiUsereqStatusState} Mutable status state.
 * @param[in] ctx {ExtensionContext} Active extension context.
 * @return {void} No return value.
 * @satisfies REQ-118, REQ-119
 */
function refreshContextUsage(
  state: PiUsereqStatusState,
  ctx: ExtensionContext,
): void {
  state.contextUsage = normalizeContextUsage(ctx.getContextUsage());
}

/**
 * @brief Resolves the icon text for one normalized context-usage snapshot.
 * @details Maps context usage to one fixed-width icon band so footer rendering remains compact and deterministic across the documented `0`, `>0-<25`, `>=25-<50`, `>=50-<75`, and `>=75` percent bands. Unavailable usage degrades to the `0%` icon. Runtime is O(1). No external state is mutated.
 * @param[in] contextUsage {ContextUsage | undefined} Normalized context snapshot.
 * @return {string} Fixed-width gauge icon text.
 * @satisfies REQ-122, REQ-284
 */
function resolveContextUsageIconText(
  contextUsage: ContextUsage | undefined,
): string {
  const percent = contextUsage?.percent;
  if (percent === undefined || percent === null || percent <= 0) {
    return "▕_▏";
  }
  if (percent < 25) {
    return "▕▂▏";
  }
  if (percent < 50) {
    return "▕▄▏";
  }
  if (percent < 75) {
    return "▕▆▏";
  }
  return "▕█▏";
}

/**
 * @brief Formats one icon-based context-usage gauge.
 * @details Renders the documented gauge icon with the same non-error status-value theme token used by `status` below `90%`, switches to theme `error` for `>=90%`, and enables terminal blink only for `>=100%`. Runtime is O(1). No external state is mutated.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @param[in] contextUsage {ContextUsage | undefined} Normalized context snapshot.
 * @return {string} Rendered fixed-width gauge icon.
 * @satisfies REQ-122, REQ-126, REQ-127, REQ-128, REQ-233, REQ-284
 */
function formatContextUsageBar(
  theme: StatusThemeAdapter,
  contextUsage: ContextUsage | undefined,
): string {
  const percent = contextUsage?.percent ?? 0;
  if (percent >= 100) {
    return theme.colorize("error", "\u001b[5m▕█▏\u001b[25m");
  }
  if (percent >= 90) {
    return theme.colorize("error", "▕█▏");
  }
  return theme.value(resolveContextUsageIconText(contextUsage));
}

/**
 * @brief Formats one elapsed-duration value as `M:SS`.
 * @details Floors the input to whole seconds, keeps minutes unbounded above 59,
 * and zero-pads seconds to two digits. Runtime is O(1). No external state is
 * mutated.
 * @param[in] durationMs {number} Duration in milliseconds.
 * @return {string} Duration rendered as `M:SS`.
 * @satisfies REQ-125
 */
function formatStatusDuration(durationMs: number): string {
  const totalSeconds = Math.max(0, Math.floor(durationMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

/**
 * @brief Formats one optional completed-duration value.
 * @details Returns the canonical unset placeholder `--:--` until the supplied
 * timer receives a normally completed prompt duration, then delegates to
 * `formatStatusDuration(...)`. Runtime is O(1). No external state is mutated.
 * @param[in] durationMs {number | undefined} Optional completed-duration value.
 * @return {string} Rendered duration or unset placeholder.
 * @satisfies REQ-124
 */
function formatCompletedStatusDuration(
  durationMs: number | undefined,
): string {
  return durationMs === undefined ? "--:--" : formatStatusDuration(durationMs);
}

/**
 * @brief Formats the consolidated `elapsed` status-bar value.
 * @details Emits the active prompt segment `⏱︎ <active>`, the latest normally
 * completed segment `⚑ <last>`, and the accumulated successful-runtime segment
 * `⌛︎<total>` with fixed spacing. Runtime is O(1). No external state is
 * mutated.
 * @param[in] state {PiUsereqStatusState} Mutable status state snapshot.
 * @param[in] nowMs {number} Current wall-clock time in milliseconds.
 * @return {string} Consolidated `elapsed` field value.
 * @satisfies REQ-123, REQ-124, REQ-125, REQ-159
 */
function formatElapsedStatusValue(
  state: PiUsereqStatusState,
  nowMs: number,
): string {
  const activeText = state.runStartTimeMs === undefined
    ? "--:--"
    : formatStatusDuration(nowMs - state.runStartTimeMs);
  const lastText = formatCompletedStatusDuration(state.lastRunDurationMs);
  const totalText = formatCompletedStatusDuration(state.totalRunDurationMs);
  return `⏱︎ ${activeText} ⚑ ${lastText} ⌛︎${totalText}`;
}

/**
 * @brief Formats one standard status-bar field.
 * @details Renders the field label in accent color and the value in warning
 * color. Runtime is O(n) in combined text length. No external state is mutated.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @param[in] fieldName {string} Field label emitted before the colon.
 * @param[in] value {string} Unstyled field value.
 * @return {string} Rendered status-field fragment.
 */
function formatStatusField(
  theme: StatusThemeAdapter,
  fieldName: string,
  value: string,
): string {
  return `${theme.label(fieldName)}${theme.value(value)}`;
}

/**
 * @brief Formats one pre-rendered status-bar field value.
 * @details Preserves the accent-colored field label while allowing callers to
 * provide a custom styled value such as the context-usage bar. Runtime is O(n)
 * in combined text length. No external state is mutated.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @param[in] fieldName {string} Field label emitted before the colon.
 * @param[in] renderedValue {string} Pre-rendered field value.
 * @return {string} Rendered status-field fragment.
 */
function formatRenderedStatusField(
  theme: StatusThemeAdapter,
  fieldName: string,
  renderedValue: string,
): string {
  return `${theme.label(fieldName)}${renderedValue}`;
}

/**
 * @brief Separates the request token from the workflow state inside the `status` field value.
 * @details Supplies the documented `➔` arrow joining `<request>` and `<state>` so every rendered `status` value shares one separator token. Access complexity is O(1). No external state is mutated.
 * @satisfies REQ-632
 */
const PI_USEREQ_STATUS_REQUEST_STATE_SEPARATOR = "➔";

/**
 * @brief Formats the rendered workflow-state value for the `status` field.
 * @details Uses the standard warning-colored value renderer for neutral states, emits a blinking `error`-colored value for `status:error`, and emits the identical blinking `error`-colored value for `status:warning` so orchestration warnings match the documented error styling. When an active orchestration request token exists, the value renders as `<request>➔<state>` joined by `PI_USEREQ_STATUS_REQUEST_STATE_SEPARATOR`; otherwise it renders the bare `<state>`, so the bootstrap `idle` state stays request-less while `done` renders through the non-error value convention. Runtime is O(n) in text length. No external state is mutated.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @param[in] workflowState {PiUsereqWorkflowState} Current workflow state.
 * @param[in] workflowRequest {string | undefined} Active orchestration request token without the `req-` prefix.
 * @return {string} Rendered workflow-state value.
 * @satisfies REQ-112, REQ-223, REQ-590, REQ-632, REQ-633, REQ-638
 */
function formatWorkflowStateValue(
  theme: StatusThemeAdapter,
  workflowState: PiUsereqWorkflowState,
  workflowRequest: string | undefined,
): string {
  const valueText = workflowRequest !== undefined
    ? `${workflowRequest}${PI_USEREQ_STATUS_REQUEST_STATE_SEPARATOR}${workflowState}`
    : workflowState;
  if (workflowState === "error" || workflowState === "warning") {
    return theme.colorize("error", `\u001b[5m${valueText}\u001b[25m`);
  }
  return theme.value(valueText);
}

/**
 * @brief Detects whether an agent run ended through abort semantics.
 * @details Treats any assistant message whose `stopReason` equals `aborted` as
 * an escape-triggered termination that must not overwrite the `last` timer.
 * Runtime is O(n) in message count. No external state is mutated.
 * @param[in] messages {AgentEndEvent["messages"]} Messages emitted by `agent_end`.
 * @return {boolean} `true` when the run ended in aborted state.
 * @satisfies REQ-125
 */
function didAgentEndAbort(messages: AgentEndEvent["messages"]): boolean {
  return messages.some((message) =>
    typeof message === "object"
      && message !== null
      && (message as { role?: unknown }).role === "assistant"
      && (message as { stopReason?: unknown }).stopReason === "aborted",
  );
}

/**
 * @brief Resolves the active runtime sound level used by status and notify flows.
 * @details Prefers the mutable runtime sound state, then falls back to the cached persisted boot value, and finally defaults to `none` before `session_start` loads configuration. Runtime is O(1). No external state is mutated.
 * @param[in] state {PiUsereqStatusState} Mutable status state snapshot.
 * @param[in] config {UseReqConfig | undefined} Cached project configuration.
 * @return {PiNotifySoundLevel} Active runtime sound level.
 * @satisfies REQ-180, REQ-285
 */
function resolvePiUsereqRuntimeSoundLevel(
  state: PiUsereqStatusState,
  config: UseReqConfig | undefined,
): PiNotifySoundLevel {
  return state.runtimeSoundLevel ?? config?.["notify-sound"] ?? "none";
}

/**
 * @brief Formats the runtime extension identity prefix for the status bar.
 * @details Reads cached installation package metadata and renders the package name plus `v<version>` using the same accent-label and warning-value token split used by standard non-error status fields. Runtime is O(n) in rendered text length. No external state is mutated.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @return {string} Rendered extension identity prefix.
 * @satisfies REQ-112, REQ-120
 */
function formatExtensionIdentityStatusField(
  theme: StatusThemeAdapter,
): string {
  const metadata = getInstallationPackageMetadata();
  return `${theme.label(metadata.name)}${theme.value(`v${metadata.version}`)}`;
}

/**
 * @brief Builds the full single-line pi-usereq status-bar payload.
 * @details Renders the runtime extension identity prefix before status, then renders status, branch, context, elapsed, and sound fields with dim bullet separators, workflow-state highlighting, the `⎇ `-prefixed branch value, the documented icon-based context gauge, and the active runtime sound level instead of the persisted boot value. Runtime is O(1). No external state is mutated.
 * @param[in] config {UseReqConfig} Effective project configuration.
 * @param[in] theme {StatusThemeAdapter} Normalized status theme.
 * @param[in] state {PiUsereqStatusState} Mutable status state snapshot.
 * @param[in] branchName {string} Active git branch name shown in the footer.
 * @param[in] nowMs {number} Current wall-clock time in milliseconds.
 * @return {string} Single-line status-bar text.
 * @satisfies REQ-109, REQ-112, REQ-120, REQ-121, REQ-123, REQ-124, REQ-125, REQ-126, REQ-127, REQ-128, REQ-156, REQ-159, REQ-180, REQ-222, REQ-223, REQ-233, REQ-283, REQ-284
 */
function buildPiUsereqStatusText(
  config: UseReqConfig,
  theme: StatusThemeAdapter,
  state: PiUsereqStatusState,
  branchName: string,
  nowMs: number,
): string {
  const elapsedText = formatElapsedStatusValue(state, nowMs);
  const soundText = resolvePiUsereqRuntimeSoundLevel(state, config);
  return [
    formatExtensionIdentityStatusField(theme),
    formatRenderedStatusField(
      theme,
      "status",
      formatWorkflowStateValue(theme, state.workflowState, state.workflowRequest),
    ),
    formatStatusField(theme, "branch", `${PI_USEREQ_STATUS_BRANCH_PREFIX}${branchName}`),
    formatRenderedStatusField(
      theme,
      "context",
      formatContextUsageBar(theme, state.contextUsage),
    ),
    formatStatusField(theme, "elapsed", elapsedText),
    formatStatusField(theme, "sound", soundText),
  ].join(theme.separator);
}

/**
 * @brief Stops the live elapsed-time ticker when it is active.
 * @details Clears the interval handle and resets the stored timer reference so
 * subsequent runs can reinitialize live status refreshes deterministically.
 * Runtime is O(1). Side effect: mutates `controller.tickHandle`.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @return {void} No return value.
 */
function stopStatusTicker(controller: PiUsereqStatusController): void {
  if (controller.tickHandle !== undefined) {
    clearInterval(controller.tickHandle);
    controller.tickHandle = undefined;
  }
}

/**
 * @brief Synchronizes the live elapsed-time ticker with the current run state.
 * @details Starts a 1-second render ticker while a run is active and stops the
 * ticker when the run returns to idle. Runtime is O(1). Side effects include
 * interval creation, interval disposal, and footer-status mutation on timer
 * ticks.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @return {void} No return value.
 * @satisfies REQ-123
 */
function syncPiUsereqStatusTicker(
  controller: PiUsereqStatusController,
): void {
  if (controller.state.runStartTimeMs === undefined) {
    stopStatusTicker(controller);
    return;
  }
  if (controller.tickHandle !== undefined) {
    return;
  }
  controller.tickHandle = setInterval(() => {
    if (!controller.latestContext || !controller.config) {
      return;
    }
    renderPiUsereqStatus(controller, controller.latestContext);
  }, 1000);
}

/**
 * @brief Creates an empty pi-usereq status controller.
 * @details Initializes the mutable status snapshot, including empty prompt-request tracking, an undefined active orchestration request token for the request-less bootstrap `idle` state, and an unset runtime sound level that later loads from persisted config during `session_start`, and starts with no config, no context, and no live ticker. Runtime is O(1). No external state is mutated.
 * @return {PiUsereqStatusController} New status controller.
 * @satisfies DES-010
 */
export function createPiUsereqStatusController(): PiUsereqStatusController {
  return {
    config: undefined,
    latestContext: undefined,
    state: {
      workflowState: "idle",
      workflowRequest: undefined,
      contextUsage: undefined,
      runStartTimeMs: undefined,
      activeRunBelongsToPrompt: false,
      endedRunDurationMs: undefined,
      lastRunDurationMs: undefined,
      totalRunDurationMs: undefined,
      runtimeSoundLevel: undefined,
      pendingPromptRequest: undefined,
      activePromptRequest: undefined,
      pendingFinalizationOutcome: undefined,
      pendingFinalizationStatusMarker: undefined,
      agentSettledEventSupported: undefined,
    },
    tickHandle: undefined,
  };
}

/**
 * @brief Stores the effective project configuration used by status rendering.
 * @details Replaces the controller's cached configuration so later status
 * renders reuse the latest docs, tests, source-path, and persisted pi-notify
 * values without reading from disk on every event, while leaving the active
 * runtime sound level in `controller.state`. Runtime is O(1). Side effect:
 * mutates `controller.config`.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] config {UseReqConfig} Effective project configuration.
 * @return {void} No return value.
 */
export function setPiUsereqStatusConfig(
  controller: PiUsereqStatusController,
  config: UseReqConfig,
): void {
  controller.config = config;
}

/**
 * @brief Returns the active runtime sound level tracked by the status controller.
 * @details Exposes the in-memory runtime sound state so shortcut handlers and prompt-end notification dispatch can stay decoupled from the persisted boot value stored in global configuration. Runtime is O(1). No external state is mutated.
 * @param[in] controller {PiUsereqStatusController} Mutable status controller.
 * @return {PiNotifySoundLevel} Active runtime sound level.
 * @satisfies REQ-180, REQ-285
 */
export function getPiUsereqRuntimeSoundLevel(
  controller: PiUsereqStatusController,
): PiNotifySoundLevel {
  return resolvePiUsereqRuntimeSoundLevel(controller.state, controller.config);
}

/**
 * @brief Stores one new runtime sound level and refreshes the status bar.
 * @details Mutates only the in-memory runtime sound state so shortcut-driven sound changes do not update persisted local or global configuration, then re-renders the footer when an active extension context is available. Runtime is O(1). Side effect: mutates `controller.state.runtimeSoundLevel` and may update `ctx.ui` status.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] runtimeSoundLevel {PiNotifySoundLevel} Next active runtime sound level.
 * @param[in] ctx {ExtensionContext | undefined} Optional active extension context.
 * @return {void} No return value.
 * @satisfies REQ-180, REQ-286, REQ-287
 */
export function setPiUsereqRuntimeSoundLevel(
  controller: PiUsereqStatusController,
  runtimeSoundLevel: PiNotifySoundLevel,
  ctx?: ExtensionContext,
): void {
  controller.state.runtimeSoundLevel = runtimeSoundLevel;
  const renderContext = ctx ?? controller.latestContext;
  if (renderContext) {
    renderPiUsereqStatus(controller, renderContext);
  }
}

/**
 * @brief Renders the current pi-usereq status bar into the active UI context.
 * @details Updates the controller's latest context pointer, refreshes the live `getContextUsage()` snapshot for direct render call sites that do not pass through `updateExtensionStatus(...)`, and writes the single-line status text only when configuration is available, including the runtime extension identity prefix, active branch field, documented icon-based context gauge, and active runtime sound level. When pi has already invalidated the supplied context after session replacement or reload, the helper clears the stale cached context and returns without surfacing the stale-instance exception. Runtime is O(1) plus git execution for branch refresh. Side effect: mutates `controller.state.contextUsage` and `ctx.ui` status when the context is still active.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] ctx {ExtensionContext} Active extension context.
 * @return {void} No return value.
 * @satisfies REQ-118, REQ-119, REQ-120, REQ-121, REQ-123, REQ-124, REQ-125, REQ-126, REQ-127, REQ-128, REQ-159, REQ-180, REQ-233, REQ-280, REQ-283, REQ-284
 */
export function renderPiUsereqStatus(
  controller: PiUsereqStatusController,
  ctx: ExtensionContext,
): void {
  controller.latestContext = ctx;
  if (!controller.config) {
    return;
  }
  try {
    refreshContextUsage(controller.state, ctx);
    const theme = createStatusThemeAdapter(ctx.ui.theme as RawStatusTheme);
    const branchName = resolveStatusBranchValue(ctx);
    ctx.ui.setStatus(
      "pi-usereq",
      buildPiUsereqStatusText(
        controller.config,
        theme,
        controller.state,
        branchName,
        Date.now(),
      ),
    );
  } catch (error) {
    if (isStaleExtensionContextError(error)) {
      if (controller.latestContext === ctx) {
        controller.latestContext = undefined;
      }
      return;
    }
    throw error;
  }
}

/**
 * @brief Transitions the prompt-orchestration workflow state and refreshes the status bar.
 * @details Mutates the tracked workflow state, preserves the latest extension context when available, and re-renders the single-line footer immediately so internal command transitions and pi lifecycle transitions stay visible to the user. Runtime is O(1). Side effect: mutates workflow state and may update `ctx.ui` status.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] workflowState {PiUsereqWorkflowState} Next workflow state.
 * @param[in] ctx {ExtensionContext | undefined} Optional active extension context.
 * @return {void} No return value.
 * @satisfies REQ-221, REQ-222, REQ-223
 */
export function setPiUsereqWorkflowState(
  controller: PiUsereqStatusController,
  workflowState: PiUsereqWorkflowState,
  ctx?: ExtensionContext,
): void {
  controller.state.workflowState = workflowState;
  persistPromptCommandState(controller.state);
  const renderContext = ctx ?? controller.latestContext;
  if (renderContext) {
    renderPiUsereqStatus(controller, renderContext);
  }
}

/**
 * @brief Stores the active orchestration request token and refreshes the status bar.
 * @details Records the processed slash-command name without the `req-` prefix in the process-scoped runtime state before the orchestration enters `checking` or `running`, then re-renders the single-line footer so the `<request>➔<state>` status value becomes visible immediately. Runtime is O(1). Side effect: mutates workflow request state and may update `ctx.ui` status.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] workflowRequest {string} Active request token without the `req-` prefix.
 * @param[in] ctx {ExtensionContext | undefined} Optional active extension context.
 * @return {void} No return value.
 * @satisfies REQ-630, REQ-631, REQ-637
 */
export function setPiUsereqWorkflowRequest(
  controller: PiUsereqStatusController,
  workflowRequest: string,
  ctx?: ExtensionContext,
): void {
  controller.state.workflowRequest = workflowRequest;
  persistPromptCommandState(controller.state);
  const renderContext = ctx ?? controller.latestContext;
  if (renderContext) {
    renderPiUsereqStatus(controller, renderContext);
  }
}

/**
 * @brief Updates mutable status state for one intercepted lifecycle hook.
 * @details Refreshes stored context usage on every hook, resets or restores persisted elapsed counters during `session_start`, loads the active runtime sound level from persisted config during `session_start`, restores persisted prompt-command metadata when the active session matches a forked execution session, restores the persisted terminal workflow state plus active request for non-reset `session_start` reasons and resets workflow state to `idle` only for `startup|reload`, resynchronizes metadata on later lifecycle hooks so post-switch workflow transitions performed by the initiating command handler become visible to the replacement-session runtime, clears the deferred terminal finalization outcome whenever session resets clear prompt-request metadata, starts run timing, records whether the in-flight run belongs to the active prompt request, and promotes the pending prompt-request metadata into the active run on `agent_start` while preserving an already-promoted active request across pi-host agent-run restarts such as overflow compact-and-retry recovery, persists the in-flight run record into the process-scoped store, captures each ended run's own duration on `agent_end` or `agent_settled` (recovering the run start and prompt association from the process-scoped record when the in-memory timer was cleared mid-run), accumulates successful runtime into `Σ` while keeping the ended-run duration separate from the completed counters, preserves in-memory prompt-command state plus process-scoped persistence across switch-triggered `session_shutdown`, keeps terminal `done|warning|error` states across shutdown while resetting only in-flight states, tolerates stale post-replacement render contexts, synchronizes the live ticker, and re-renders the status bar with the runtime extension identity prefix when configuration is available. Runtime is O(n) in `agent_end` message count and otherwise O(1). Side effects include in-memory state mutation, interval scheduling, process-scoped persistence mutation, and footer-status updates.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @param[in] hookName {PiUsereqStatusHookName} Intercepted hook name.
 * @param[in] event {unknown} Hook payload forwarded from the wrapper.
 * @param[in] ctx {ExtensionContext} Active extension context.
 * @return {void} No return value.
 * @satisfies REQ-009, REQ-117, REQ-118, REQ-119, REQ-123, REQ-124, REQ-125, REQ-159, REQ-169, REQ-187, REQ-217, REQ-221, REQ-278, REQ-279, REQ-280, REQ-285, REQ-421, REQ-461
 */
export function updateExtensionStatus(
  controller: PiUsereqStatusController,
  hookName: PiUsereqStatusHookName,
  event: unknown,
  ctx: ExtensionContext,
): void {
  controller.latestContext = ctx;
  refreshContextUsage(controller.state, ctx);
  const nowMs = Date.now();
  const currentSessionFile = getContextSessionFile(ctx);

  if (hookName === "session_start") {
    if (shouldResetElapsedStateOnSessionStart(event)) {
      resetElapsedState(controller.state);
    } else {
      restorePersistedElapsedState(controller.state);
    }
    controller.state.runtimeSoundLevel = controller.config?.["notify-sound"]
      ?? controller.state.runtimeSoundLevel
      ?? "none";
    const shouldResetWorkflowState = shouldResetWorkflowStateOnSessionStart(event);
    if (shouldResetWorkflowState) {
      controller.state.workflowState = "idle";
      controller.state.workflowRequest = undefined;
    } else {
      const terminalState = readPersistedPromptCommandTerminalState();
      if (terminalState !== undefined && controller.state.workflowState === "idle") {
        controller.state.workflowState = terminalState.workflowState;
        controller.state.workflowRequest = terminalState.workflowRequest;
      }
    }
    controller.state.runStartTimeMs = undefined;
    controller.state.activeRunBelongsToPrompt = false;
    if (shouldResetWorkflowState || controller.state.workflowState === "idle") {
      controller.state.pendingPromptRequest = undefined;
      controller.state.activePromptRequest = undefined;
      controller.state.pendingFinalizationOutcome = undefined;
      controller.state.pendingFinalizationStatusMarker = undefined;
    }
  }

  restorePersistedPromptCommandState(controller.state, currentSessionFile);
  const preservePromptCommandStateOnShutdown = hookName === "session_shutdown"
    && shouldPreservePromptCommandStateOnShutdown(controller.state);

  if (hookName === "agent_start") {
    controller.state.runStartTimeMs = nowMs;
    // Promote only when a pending request exists: the pi host restarts the agent run for
    // overflow compact-and-retry recovery (agent_end -> session_before_compact ->
    // session_compact -> agent_start -> retried provider request) while the originating
    // prompt-command orchestration stays in flight. Overwriting the already-promoted
    // active request with an undefined pending request would drop the run from controller
    // state and process-scoped persistence, silencing every retried before_provider_request
    // capture (REQ-421) and the later matched-success or matched-failure closure handling.
    const pendingPromptRequest = controller.state.pendingPromptRequest;
    if (pendingPromptRequest !== undefined) {
      controller.state.activePromptRequest = pendingPromptRequest;
      controller.state.pendingPromptRequest = undefined;
    }
    // The in-flight run belongs to the active prompt request when this start promoted a
    // pending request, or when an already-promoted request still owns an open prompt
    // workflow (`running`, or `merging` while matched-success finalization waits for
    // `agent_settled`). Error-retained requests park the workflow in `error` and must
    // never reclaim ownership of later unrelated agent runs.
    controller.state.activeRunBelongsToPrompt = pendingPromptRequest !== undefined
      || (controller.state.activePromptRequest !== undefined
        && (controller.state.activeRunBelongsToPrompt
          || controller.state.workflowState === "running"
          || controller.state.workflowState === "merging"));
    persistActiveRunState(controller.state);
  }

  if (hookName === "agent_end" || hookName === "agent_settled") {
    // Recover the run start and prompt association from the process-scoped run record when
    // the in-memory timer was cleared between `agent_start` and this terminal hook (mid-run
    // rebind or fault-injected state loss), so the ended run keeps its own duration instead
    // of inheriting a previous run's completed counters. The ownership flag travels with the
    // same record, so a recovered run can never borrow another run's prompt association.
    const persistedActiveRun = readPersistedActiveRunState();
    const runStartMs = controller.state.runStartTimeMs ?? persistedActiveRun?.startMs;
    const runBelongsToPrompt = controller.state.runStartTimeMs !== undefined
      ? controller.state.activeRunBelongsToPrompt
      : persistedActiveRun?.belongsToPrompt === true;
    if (runStartMs !== undefined) {
      const durationMs = Math.max(0, nowMs - runStartMs);
      const agentEndMessages = hookName === "agent_end"
        ? (event as AgentEndEvent).messages ?? []
        : [];
      if (!didAgentEndAbort(agentEndMessages)) {
        controller.state.lastRunDurationMs = durationMs;
        controller.state.totalRunDurationMs = controller.state.totalRunDurationMs === undefined
          ? durationMs
          : controller.state.totalRunDurationMs + durationMs;
      }
      // The ended run's own duration, recorded even for aborted runs and kept strictly
      // separate from the completed-run counters above.
      controller.state.endedRunDurationMs = durationMs;
    } else {
      // No recoverable start exists for this terminal event: mark the duration unknown so
      // downstream notification gates never substitute a previous run's duration or a
      // fabricated zero.
      controller.state.endedRunDurationMs = undefined;
    }
    controller.state.runStartTimeMs = undefined;
    // Retain the ended run's ownership flag for the post-update notification gate; the next
    // `agent_start` recomputes it for the next run.
    controller.state.activeRunBelongsToPrompt = runBelongsToPrompt;
    clearPersistedActiveRunState();
  }

  if (hookName === "session_shutdown") {
    controller.state.runStartTimeMs = undefined;
    controller.state.activeRunBelongsToPrompt = false;
    if (!preservePromptCommandStateOnShutdown) {
      controller.state.pendingPromptRequest = undefined;
      controller.state.activePromptRequest = undefined;
      controller.state.pendingFinalizationOutcome = undefined;
      controller.state.pendingFinalizationStatusMarker = undefined;
      if (
        controller.state.workflowState === "checking"
        || controller.state.workflowState === "running"
        || controller.state.workflowState === "merging"
      ) {
        controller.state.workflowState = "idle";
        controller.state.workflowRequest = undefined;
      }
    }
  }

  persistElapsedState(controller.state);
  if (!preservePromptCommandStateOnShutdown) {
    persistPromptCommandState(controller.state);
  }
  syncPiUsereqStatusTicker(controller);
  renderPiUsereqStatus(controller, ctx);
}

/**
 * @brief Disposes the pi-usereq status controller.
 * @details Stops the live ticker, clears the cached context pointer, and leaves
 * the last captured status snapshot available for inspection until the
 * controller object itself is discarded. Runtime is O(1). Side effects are
 * limited to interval disposal and in-memory state mutation.
 * @param[in,out] controller {PiUsereqStatusController} Mutable status controller.
 * @return {void} No return value.
 */
export function disposePiUsereqStatusController(
  controller: PiUsereqStatusController,
): void {
  stopStatusTicker(controller);
  controller.latestContext = undefined;
}
