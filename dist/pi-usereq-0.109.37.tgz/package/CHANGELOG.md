# Changelog

## [0.109.36](https://github.com/Ogekuri/PI-useReq/compare/v0.109.0..v0.109.36) - 2026-11-27
### ⛰️  Features
- Add new /req-print-result slash-command.
- Update prompts.
- Update prompts.
- Update prompts.
- Update prompt with json validator.
- Add json-validator agent tool with native TypeScript validation [useReq] *(json-validator)*
  Register the default-enabled configurable json-validator agent tool; Validate inline content plus UTF-8 files through native JSON.parse; Emit one monolithic markdown verdict with line/column diagnostics; Extend SRS with DES-044, REQ-701..REQ-709, TST-229..TST-231; Add core and registration test coverage; no new runtime dependency
- Update prompts.
- Update prompts.
- Add /req-continue-list printing full Next-Workflow list [useReq] *(next-workflow)*
  Add the dedicated req-continue-list slash command that prints the complete
  captured Next-Workflow entry list into the editor, rendering every command
  with its full untruncated input text and a deterministic placeholder for an
  empty array. The command performs only the printing operation: no UI
  notifications, no workflow-state transitions, no prompt dispatch, session
  switching, worktree operations, or array mutation, so it stays runnable from
  every workflow state. Extend REQUIREMENTS.md with DES-041, REQ-671..676,
  TST-222..224 plus evidence rows, update WORKFLOW.md call traces, regenerate
  REFERENCES.md, and add renderer plus extension-behavior unit tests.
- add /req-continue chain continuation with Next-Workflow capture [useReq] *(next-workflow)*
  Add src/core/next-workflow.ts: parse the ## **Next Workflow** section of the
  final agent output, capture pi-usereq commands plus the /req-continue
  exception into one process-scoped array, render the numbered retention list
  with first-20/last-10 input quotation, and resolve one-based ordinals.
  Capture at terminal completed agent_end before the retention notification
  and clear the array on startup|reload idle-reset bootstrap boundaries.
  Register /req-continue: reject the idle new state, empty arrays, and invalid
  ordinals without workflow-state transitions; delegate the selected entry
  through its registered handler exactly like a manual user invocation.
  Requirements DES-040, REQ-653..REQ-664, TST-215..TST-218 plus 10 new tests.
- Update prompts.

### 🐛  Bug Fixes
- clear stale settlement facts on recovery [useReq] *(orchestration)*
  Follow-up to the lost-settlement watchdog fix: the REQ-224 auto-recovery and the successful req-wtd recovery cleared the prompt-orchestration runtime state but left the execution-session-keyed finalization snapshot and the armed settlement watchdog in place, so a successor orchestration reusing the same execution session (REQ-826 flow) could adopt the stale terminal outcome through the watchdog or the settle rebind recovery and be wrongly parked in error.
  autoRecoverTerminalReqCommandState now also clears the finalization snapshot and disarms the settlement watchdog (REQ-224).; The req-wtd success recovery clears the same facts (REQ-820).; Oscillation determination: the reported implement/change status oscillation cannot occur after the watchdog fix because a stale orchestration is forced terminal (watchdog park or REQ-823 gate park), its render source freezes (REQ-803/REQ-804), and REQ-224 recovery clears the full persisted state before the successor records its request; the new regression test asserts no stale request render after the successor starts.; New reproducer: lost settlement facts never bleed into a successor reused-worktree orchestration (failed pre-fix on the surviving snapshot; suite green 174 passed / 0 failed; tsc and eslint clean; WORKFLOW.md and REFERENCES.md updated).
- park lost settlements in error via watchdog [useReq] *(orchestration)*
  Worktree-backed prompt orchestrations whose final-output JSON carries result error were deferred from agent_end to agent_settled; when the host never delivered agent_settled (or the settle handler aborted before the transition), the workflow stayed running forever with live elapsed timers and a retained worktree, as observed in /tmp/PI-useReq/GitHub-Template-Rust-work-20261126093532-req-implement-debug.json.
  Arm a one-shot settlement watchdog at the settle-deferred agent_end (REQ-463/REQ-464): every later agent_end of the same orchestration re-arms it, and on expiry it consumes the recorded or snapshot-recovered terminal facts, logs the settlement_watchdog closure event, parks the workflow in error, clears prompt-run ownership plus pending finalization state, retains the worktree for /req-wtd, and delivers the blocked-gate notification best-effort (REQ-209, REQ-587, REQ-803/REQ-804).; Reorder every blocked-outcome and closure-failure park (agent_end legacy path and agent_settled path) to transition the workflow state and clear pending state BEFORE the fallible UI notification, which is now best-effort, so a throwing or stale notification surface can never abort or revert the terminal park.; Extract adoptPersistedPromptFinalizationSnapshot(...) shared by agent_settled rebind recovery and the watchdog.; Add controller-owned settlementWatchdogHandle cleared on consumption and controller disposal.; Tests: two new extension-registration reproducers (lost settlement parks error; throwing notify delivery still parks error); suite green: 173 passed / 0 failed; tsc --noEmit and eslint clean; WORKFLOW.md and REFERENCES.md updated.
- keep installed launcher chain on source-checkout uninstall [useReq] *(bin-deploy)*
  Guard the ~/bin/pi-usereq removal with the executing-installation ownership check so --uninstall run from a source checkout (scripts/pi-usereq.sh) never de-registers the launcher chain of the installed pi-managed version.
  Isolate the package-manager and bin-deploy test modules behind a temporary HOME and inject launcher-remover doubles so npm test (pre-release-check stage 3) can no longer delete the developer-home ~/bin/pi-usereq link.
  Add the foreign-checkout reproducer test and refresh WORKFLOW.md plus REFERENCES.md.
- keep reusable session context and report printout on closure failure [useReq] *(prompt-orchestration)*
  Persist only command-capable contexts in activatePromptCommandExecution so the before_agent_start lifecycle re-verification of a reused-worktree run can no longer overwrite the dispatch command context, which made closure restoration fail with the ctx.switchSession() diagnostic after /req-continue recovery (REQ-276, REQ-279, REQ-826).
  Emit the context-retention notification with the parsed final-output report printout before every terminal closure-failure diagnostic, including worktree cleanup failures and non-worktree restoration failures, so REQ-712 report notifications and REQ-719 diagnostic ordering hold and /req-wtd no longer becomes the first surface that prints the report.
  Add two reproducer tests covering the lifecycle-context persistence guard and the retention-before-diagnostic ordering; regenerate WORKFLOW.md call traces and REFERENCES.md.
- derive reused debug-run prefix from worktree name [useReq] *(prompt-command-runtime)*
  REQ-798 debug prefixes nested the worktree prefix when a req-* command reused a retained generated worktree: project and branch resolved from the worktree root basename and its generated branch, both embedding GIT_WORKTREE_PREFIX, yielding <wt>-<wt>-<id> filenames under the prompt debug log path. Identity now derives from the retained worktree name minus the configured prefix at dispatch and in the prepare fallback (REQ-825/826). Adds a failing-first reproducer for TST-252 and refreshes WORKFLOW.md plus REFERENCES.md call-trace and symbol indexes.
- Fix .gitignore file.
- Update .gitignore file.
- Freeze result-error elapsed timers past orchestration end [useReq] *(extension-status)*
  A terminal result "error" park whose transition source state was not
  in-flight (rebound runtime restoring the in-flight elapsed record from
  the process-scoped store while its per-hook prompt-state restore adopted
  the persisted terminal transition) kept orchestrationStartMs set, so
  every later render advanced running/context/session timers and the
  hook-end persist kept the store in flight. Enforce the REQ-803/REQ-804
  terminal-freeze invariant in setPiUsereqWorkflowState and the non-
  session_start hook heal in updateExtensionStatus, and make the elapsed
  render snapshot treat terminal workflow states as closed. Add reproducer
  test; update WORKFLOW.md call traces and REFERENCES.md.
- Update .pi-usereq.json config file.
- Accept mandated pi-host version warning in session-start replay [useReq] *(debug-harness)*
  The session-start offline replay test required zero notifications, but REQ-457 mandates exactly one pi CLI host compatibility warning when the installed pi-coding-agent resolves below 1.6.0 (observed with a stale node_modules tree at 1.5.2 while package-lock.json pins 1.6.0). The assertion now derives the expected notification set from the installed SDK version through buildPiHostVersionWarningMessage and comparePiHostVersions and requires every other notification to stay absent per REQ-458. Verified under both 1.5.2 (reproducer now passes) and 1.6.0 trees; full suite 563/563. No source or requirements changes.
- Align render signature with pi-tui Component contract [useReq] *(settings-menu)*
  Return a mutable string[] copy from the settings-menu component render method so the strict tsc --noEmit pre-release gate passes against the released pi-tui ^1.6.0 Component.render(width): string[] declaration while remaining assignable to the newer read-only SoT contract. Runtime rendering output and the offline settings-menu bridge behavior are unchanged; references document regenerated.
- match render return type to pi-tui Component [useReq] *(settings-menu)*
  Narrow the settings-menu custom component render member from readonly
  string[] to string[] so it satisfies the pi-tui Component.render(width):
  string[] contract; strict tsc --noEmit (CTN-006) passes again and the
  pre-release gate stage 2 (REQ-491/REQ-492) is unblocked. Type-only fix,
  no runtime behavior change. Regenerate usereq/docs/REFERENCES.md.
- Restart context timer on new contexts after /new [useReq] *(extension-status)*
  REQ-805/REQ-806: the elapsed context_timer must restart from zero whenever an orchestration starts on a new, empty context (for example after /new). Record a one-shot empty-context reset fact at the /new session-start boundary, consume it at the next orchestration start, invalidate it when an orchestration closes, harden the empty-context probe (throw-safe, non-copying getEntryCount preferred) so unreadable session surfaces degrade to empty per contract, and cover both the plain /new flow and the misreporting-probe failure mode with reproducer tests.
- Freeze terminal-adopted elapsed timers and gate live ticker [useReq] *(extension-status)*
  Terminal workflow-state adoptions (resynchronize/session_start restore) now freeze stale in-flight elapsed records through freezeAdoptedTerminalOrchestrationElapsed (REQ-803, REQ-804).; The live elapsed ticker stops for any non-in-flight workflow state, so terminal-adopted controllers never keep ticking (REQ-808); REQ-809 record preservation is unchanged.; Add reproducer test covering both adoption surfaces; update the rebound-timer assertion.; Update WORKFLOW.md call traces; regenerate REFERENCES.md.
- freeze rebound elapsed timers at orchestration end [useReq] *(extension-status)*
  Adopt the process-scoped frozen timer facts into a replacement runtime whose in-memory in-flight orchestration start was closed by another instance, so the elapsed timers stop at the terminal transition instead of ticking past it and the accumulated durations stay intact for the next orchestration (REQ-803, REQ-804, REQ-808, REQ-159, REQ-809). Add one failing-then-passing reproducer test for the rebound-runtime timer freeze and resume, and realign the WORKFLOW.md call trace plus the regenerated REFERENCES.md.
- publish only settled agent reports [useReq] *(orchestration)*
- drop redundant ERROR: prefix from merge-failure diagnostic [useReq] *(core)*
  Remove the ERROR: severity prefix from the dynamic fast-forward merge-failure message in finalizePromptCommandMerge because the pi CLI error notification rendering already prepends Error:, so the surfaced line printed the redundant Error: ERROR: marker. The uniform REQ-667 hardcoded last line keeps its ERROR: prefix. Update the reproducer assertions in the worktree merge-failure closure test and regenerate REFERENCES.md mappings. Verification: npm test 557/557 pass; req-static-check clean.
- recover report text and settle state after rebind [useReq] *(final-output)*
  buildAgentFinalOutputInspectionText parses the latest text-bearing assistant message so a final-output JSON delivered before a thinking-only terminal message is captured and reported (REQ-653, REQ-654) while %%OUTPUT%% substitution and the merge gate keep the strict last-message contract (REQ-443, REQ-444, REQ-589).; hasAgentEndStopReason tolerates agent_end payloads without a messages array so outcome classification degrades to completed instead of throwing (REQ-444).; PersistedPromptCommandFinalizationSnapshot records the settle-deferred terminal facts keyed by the execution-session file so a rebound runtime recovers them at agent_settled and finalizes instead of leaving the workflow running (REQ-463, REQ-464).; tests/extension-registration.test.ts adds the thinking-only trailing assistant message reproducer, the missing messages array guard, and the rebind recovery suite.; WORKFLOW.md call-trace nodes and REFERENCES.md regenerated.
- refresh captured report and Next-Workflow on result error [useReq] *(orchestration)*
  Gate the agent_end final-output capture on the parse outcome instead of
  the merge-gate marker so workflow-mandated result "error" terminals
  refresh the process-scoped report store, Next-Workflow array, retained
  message, and /req-continue entries with the executed flow outcome
  instead of keeping the antecedent flow state; outputs without one valid
  final-output JSON never feed the capture (REQ-654, REQ-656, REQ-712).
- use repository commit format for sync commit [useReq] *(prompts-updater)*
  DEFECT: the script-generated commit (89a297a) used the bare subject
  'Update bundled prompts from v0.12.14 to v0.12.15', violating the
  repository commit-text format rule <TYPE>(<COMPONENT>): <DESCRIPTION>
  [useReq] documented by REQ-301's exact-message envelope pattern.
  FIX: commit_update() now creates the commit with subject
  'change(prompts): Update bundled prompts from <stored> to <resolved>
  [useReq]'; the REQ-754 mandated description core and both version
  numbers remain verbatim; Doxygen documentation updated.
- color inline code atomically over emphasis [useReq] *(agent-final-output)*
  The ANSI markdown colorizer let the italic-emphasis alternative pair
  emphasis-lookalike asterisks (e.g. the glob in prompts/*.md with the
  trailing asterisk of req-*) and consume the inline code spans between
  them, so enclosed backtick spans printed uncolored instead of code.
  Segment each line on inline code spans first and style every code span
  through the shared dispatcher; the link, bold, underline, and italic
  alternatives now run only on the remaining segments, restoring REQ-715
  inline-code coloring without changing any public interface.
  Adds two failing-first reproducer tests for the observed report line
  and the inline-code-atomicity guarantee; updates WORKFLOW.md call
  traces and regenerates REFERENCES.md.
- merge retention report into one ANSI notification [useReq] *(notify)*
  Compose the boxed ANSI report, Next-Workflow command table, intense-white
  retention sentence with intense-yellow percentage, and numbered list into
  one message via the new src/core/retention-notification.ts builders,
  satisfying REQ-712, REQ-713, REQ-716, REQ-717, REQ-720..REQ-725.
  Deliver the merged message through one notifyContextSafely info call so the
  pi TUI back-to-back status collapse can no longer overwrite the ANSI report
  printout with the plain-markdown duplicate that REQ-713 forbids.
  Keep result-error gate report emissions unchanged; update WORKFLOW.md call
  traces, regenerate REFERENCES.md, add tests/retention-notification.test.ts.
- Write no-source REFERENCES.md placeholder like req-references [useReq] *(references)*
  runReferences now probes hasAnalyzableSourceFiles before extraction and
  writes the exact NO_SOURCE_REFERENCES_PLACEHOLDER payload through
  writeNoSourcePlaceholderDocument when the configured src-dir git
  inventory holds no supported source file, returning the status-only
  success payload exactly like the /req-references command branch.
  Genuine source-discovery, generation, and write failures still surface
  error: diagnostics, preserving REQ-294/REQ-295/REQ-296 contracts.
  references tool registration guidelines document the no-source contract.; Add failing-first reproducer test and replace the empty-inventory tool
  error assertion with a real git discovery failure; full suite 547/547.
  Regenerate WORKFLOW.md call traces and REFERENCES.md.
- recover persisted terminal workflow state after rebind [useReq] *(status)*
  Add resynchronizePersistedTerminalWorkflowState to extension-status: a
  replacement runtime bound by switchSession during closure receives
  session_start while the persisted state is still non-terminal, so its
  one-shot terminal restore is skipped and the controller stays idle
  forever, making /req-continue reject a completed flow (REQ-660).
  Adopt the persisted terminal state at req-continue and prompt-command
  dispatch and on every non-session_start hook, keeping idle boundaries
  (bootstrap, /req-reset, startup|reload) non-resurrectable.
  Drop the captured Next-Workflow array on successful /req-reset so the
  idle boundary matches the bootstrap boundary (REQ-633, REQ-656).
  Add failing-first reproducer test, extend req-reset coverage, and
  refresh WORKFLOW.md plus REFERENCES.md.
- remove private manifest flag blocking npm publication [useReq] *(release)*
  Remove the package.json private field that made npm publish fail with EPRIVATE before provenance and public access were applied.; Add a release-workflow regression test asserting the manifest omits the private field.; Requirements: DES-025, REQ-140, TST-159.
- guard duplicate activation and repair launcher after upgrade [useReq] *(extension)*
  skip duplicate pi-usereq extension activation when another pi-managed\n  installation already owns registration in the same pi host process,\n  removing the per-tool extension conflict diagnostics\n- allow same-installation re-activation across /new, /resume, /fork, and\n  /reload session rebinds and release the claim on activation failure\n- repair the agent-bin pi-usereq launcher after every successful\n  same-source upgrade child so the management CLI never stays dangling\n- add reproducer tests plus WORKFLOW.md and REFERENCES.md updates

### 🚜  Changes
- Prune default-equal tools and static-check entries on save [useReq] *(config)*
  Add saveConfigWithDefaultPruning removing default-equal enabled-tools and static-check persisted entries.; Persist enabled-tools only when the selection differs from the documented defaults (REQ-831..REQ-834).; Remove restored-default static-check entries from local and global payloads (REQ-835..REQ-836).; Update requirements, runtime model, references, and persistence unit tests.
- Enable all configurable tools by default [useReq] *(tools)*
  Update REQ-064 so every configurable custom and embedded tool defaults to enabled.; Alias PI_USEREQ_DEFAULT_EMBEDDED_TOOL_NAMES to the full embedded inventory.; Derive the config-CLI enabled-tools fallbackDefault from the shared default tuple.; Align default-matrix unit tests with the updated requirement.
- Rename pi-prompts-update.sh to prompts-update.sh [useReq] *(scripts)*
  Rename scripts/pi-prompts-update.sh to scripts/prompts-update.sh and update
  the script @file header plus its temporary-directory prefix. Align
  REQUIREMENTS.md: DES-022 path, section 5.1 component description, project
  structure tree entry (alphabetical order preserved), and front-matter
  version bump to 0.0.182. WORKFLOW.md unchanged: the updater is a standalone
  bash process outside src/ and is not modeled as an execution unit.
  REFERENCES.md regenerated with no content change. No unit tests reference
  the renamed script; req-static-check reports no issues.
- Add security checker defaults and gosec scan-by-dir [useReq] *(static-check)*
  Add clang-tidy and flawfinder Command defaults for C/C++ and bandit for Python (REQ-250, REQ-251).
  Extend the scan-by-dir capability map with gosec -exclude-dir (REQ-695, REQ-698, REQ-830).
  Exclude staticcheck and cargo clippy: no checker-native directory-exclusion flag.
  Align default-config and persisted-checker test assertions (TST-078).
  Bump SRS to 0.0.181 with REQ-830, REQ-695 evidence, and Performance Notes.
- BREAKING CHANGE: raise minimum pi CLI host version to 1.6.1 and align peer ranges [useReq] *(pi-host-version)*
  Update MINIMUM_SUPPORTED_PI_HOST_VERSION to 1.6.1 to match the bundled read-only
  pi CLI source-of-truth update (v1.6.0 -> v1.6.1) and raise the three
  @earendil-works peer dependency ranges to ^1.6.1 in package.json and package-lock.json.
  Requirements: REQ-457/REQ-458 compatibility warning threshold moved to 1.6.1 and
  REQ-460 peer ranges updated in the SRS (bumped to 0.0.180). Impact analysis confirms
  the 1.6.1 extension-facing delta is additive-only (optional dialog blockedKind,
  optional BashExecutionMessage.fullOutputError, clarified after_provider_response
  error-response semantics); no slash-command orchestration or notification regression
  and no code adaptation required. Verified: tsc --noEmit clean, npm test 572/572.
- Update bundled read-only PI cli source code and docs from v1.6.0 to v1.6.1 [useReq] *(pi-cli-src-docs-update)*
- BREAKING CHANGE: replace req-reset with auto-recovery and retained-worktree reuse [useReq] *(core)*
  Remove the /req-reset slash command, module, registration, Next-Workflow
  eligibility, requirements (PRJ-008, DES-014, REQ-304..307, REQ-312..313,
  TST-105..107, TST-220) and tests without backward compatibility.
  Add REQ-224 auto-recovery: gated req-* commands clear persisted
  prompt-orchestration state and return to idle from terminal error or
  warning states before execution (REQ-823 keeps in-flight rejection;
  REQ-824 emits the info auto-reset notification).
  Add REQ-825..REQ-829 worktree reuse: prompt commands dispatched while
  the session anchors inside a retained generated worktree continue on it
  without creating a new worktree or forking a new execution session,
  validate the main repository, recover the base session through the
  parentSession link, and retain the reused worktree on command-side
  failure; successful closure keeps merging and deleting it.
  Rework orchestration-gate, wipe-placement, and result-error tests;
  add auto-recovery, reuse-closure, and reuse-failure coverage
  (TST-262..TST-267); update README, WORKFLOW.md, and REFERENCES.md.
- Update bundled prompts from v0.12.20 to v0.12.21 [useReq] *(prompts)*
- dispose only the resolved target worktree [useReq] *(req-wtd)*
  /req-wtd no longer sweeps every generated sibling worktree and branch:
  it resolves one target - the persisted prompt-orchestration worktree
  or the sibling worktree anchoring the live pi CLI session - and
  force-removes only that worktree plus its branch, with or without
  active changes, after restoring base-path and the main branch
  (PRJ-011, REQ-309..311, REQ-815, REQ-822, TST-259, TST-261).
  ensureReqWtdMainBranch is target-scoped; multi-worktree scoping,
  sibling preservation, and target-branch switch covered by updated
  and new tests.
- BREAKING CHANGE: make req-reset idle-only and add req-wtd disposal [useReq] *(commands)*
  /req-reset now only clears prompt-orchestration state and returns the
  orchestration to idle without worktree/branch deletion, session
  switching, or client relocation (REQ-304..REQ-307, REQ-312, REQ-313).
  New /req-wtd command inherits the removed operations: base-path
  restoration, main-branch switch, and forced worktree/branch disposal
  with or without active changes (PRJ-011, DES-048, REQ-815..REQ-821).
  Next-Workflow capture admits req-wtd; requirements SRS, workflow
  runtime model, references, and tests updated (TST-258..TST-261).
- Update bundled prompts from v0.12.19 to v0.12.20 [useReq] *(prompts)*
- return no-source success directive [useReq] *(static-check)*
  Add REQ-813/REQ-814: project static-check terminates with SUCCESS and the
  declared NO_SOURCE_STATIC_CHECK_RESULT system-directive payload, without
  dispatching any checker, when the fixture-filtered selection holds no
  supported source file. Declare the verbatim payload constant in
  src/core/source-presence.ts (DES-039) and return it from
  runProjectStaticCheck instead of failing with exit code 1. Update the CLI
  parity empty-repository scenario (TST-257) to assert exit 0 plus the
  verbatim payload stdout. Regenerate WORKFLOW.md call traces and
  REFERENCES.md evidence mappings.
- Update .galias.conf file. *(config)*
- BREAKING CHANGE: move debug configuration to global scope with enable defaults [useReq] *(config)*
  Move every DEBUG_* field (DEBUG_ENABLED, DEBUG_PROMPTS_ENABLED, DEBUG_PROMPTS_LOG_PATH, DEBUG_STATUS_CHANGES, DEBUG_WORKFLOW_EVENTS, DEBUG_TOOL_COMMANDS_ENABLED, DEBUG_LOG_ON_STATUS, DEBUG_ENABLED_TOOLS, DEBUG_ENABLED_PROMPTS) from the local project scope to the global configuration scope, satisfying updated CTN-013, CTN-019, REQ-236, REQ-426, REQ-413, and REQ-414.
  Flip persisted defaults to enable for DEBUG_PROMPTS_ENABLED, DEBUG_STATUS_CHANGES, DEBUG_WORKFLOW_EVENTS, and DEBUG_TOOL_COMMANDS_ENABLED while keeping the global DEBUG_ENABLED flag defaulted to disable (CTN-013, CTN-019, REQ-254, REQ-277, REQ-413, REQ-420).
  Fix the debug enable normalizers to accept the explicit disable value instead of collapsing it into the default, a latent defect surfaced by the new enable defaults, and align the configuration CLI schema Local/Global sections plus the settings-menu render signature with the pi-tui 1.6.0 Component contract.
  Update aligned unit tests for the new scope, defaults, and CLI tree shape; regenerate REFERENCES.md and refresh the WORKFLOW.md runtime model.
- Render Summary report body in intense white [useReq] *(agent-final-output)*
  Add REQ-811/REQ-812: style the final-output report Summary section body with the intense-white ANSI foreground while headings, fenced code, inline elements, other section bodies, and the Next-Workflow table keep their unchanged styling.
  Implement section tracking in colorizeAgentFinalOutputMarkdownText with per-token SGR composition for Summary quote spans and plain segments.
  Update ANSI-exact retention notification tests and add TST-256 coverage; regenerate WORKFLOW.md call traces and REFERENCES.md.
- Add debug mode.
- Raise minimum pi CLI to v1.6.0 [useReq] *(extension-compat)*
  Analyzed the pi CLI v1.5.2 to v1.6.0 update in read-only docs/pi.dev and pi.dev-src.
  Extension API surface is additive only (ExtensionRuntimeState.reportError); lifecycle
  event names and builtin tool inventory are unchanged. Adapted settings-menu component
  render to the new readonly string[] pi-tui Component contract. Raised
  MINIMUM_SUPPORTED_PI_HOST_VERSION to 1.6.0 and peer dependencies to ^1.6.0 with a
  synced lockfile. Updated REQ-457, REQ-458, REQ-460 and section 5.2 evidence.
  Verification: tsc --noEmit clean, req-static-check clean, npm test 562/562 passed.
- Update bundled read-only PI cli source code and docs from v1.5.2 to v1.6.0 [useReq] *(pi-cli-src-docs-update)*
- Update bundled prompts from v0.12.18 to v0.12.19 [useReq] *(prompts)*
- BREAKING CHANGE: refactor elapsed status bar into orchestration running/context/session timers [useReq] *(extension-status)*
  Replace per-agent-run elapsed counters with three orchestration timers:
  running_timer restarts per orchestration and freezes at terminal states,
  context_timer resets only on empty-context orchestration starts, and
  session_timer accumulates for the whole pi client process lifetime; all
  three tick concurrently through one shared 1-second update logic and
  persist across session replacement. Update REQ-123/124/125/159/187/217,
  add REQ-803..REQ-810 plus TST-255, and realign WORKFLOW.md, REFERENCES.md,
  and the status-bar and pushover timer tests.
- run-prefixed debug logs and persisted Debug flag [useReq] *(debug)*
  Debug files use the <project>-<branch>-<timestamp>-<command> run prefix shared with the worktree name (REQ-798..REQ-802).; DEBUG_ENABLED now persists in local configuration, default disable (REQ-236, REQ-426).; Removed the configurable JSON log filename; JSON entries append to <prefix>-<command>-debug.json under the prompts log path (REQ-237).; Added the read-only Generated log files description row to the Debug menu (REQ-801).; Updated REQUIREMENTS, WORKFLOW, REFERENCES, README, and unit tests.
- Print blocked-gate report and ERROR diagnostics without doubled Error prefix [useReq] *(orchestration)*
  REQ-796: deliver the blocked-gate terminal notification as one info-severity
  notification composing the ANSI report printout, one blank line, and the
  intense-red ERROR diagnostic, so the boxed report prints without the host
  "Error: " prefix and survives info-notification collapse.
  REQ-797: resolve error-severity notifications whose message opens with an
  ERROR:/Error: marker to info severity so the pi CLI never prints
  "Error: ERROR: ..." doubled markers.
  REQ-587/REQ-588/REQ-680/REQ-719 requirement wording updated; stale test
  severity assertions aligned; WORKFLOW.md call-traces and REFERENCES.md
  regenerated.
- Update bundled prompts from v0.12.16 to v0.12.18 [useReq] *(prompts)*
- BREAKING CHANGE: Always number extraction outputs and keep find excerpts as-is [useReq] *(compress-find)*
  REQ-012/REQ-083: compress and files-compress always prefix retained lines
  with original source line numbers; enableLineNumbers parameter removed.
  REQ-013/REQ-090/REQ-092: find and files-find emit as-is numbered excerpts
  keeping comments; extraction comment-stripping logic removed.
  REQ-039 removed: --enable-line-numbers CLI flag deleted; TST-012 updated.; Added TST-250/TST-251 plus tests/extraction-line-numbers.test.ts,
  regenerated attended-result fixtures, updated tool registrations and README.
- Render resolved user request in command summary header [useReq] *(prompts)*
  Render the bundled prompt-backed command invocation summary User's Request section as a standalone label line with the resolved user-request text on the immediately following line (REQ-795).
  Pass userRequest.requestText into renderPromptCommandSummary so the on-screen recap shows the effective %%ARGS%% content instead of the raw @ reference or inline input (REQ-792).
  Pin that covered user-request resolution completes before the command invocation summary render (REQ-794).
  Add REQ-794 and REQ-795, update REQ-792 plus its evidence row, and bump the SRS to 0.0.173.
  Update WORKFLOW.md call-trace notes for resolvePromptCommandUserRequest and renderPromptCommandSummary and regenerate REFERENCES.md.
  Align the tests/prompt-command-summary.test.ts format assertion; full suite passes 592/592.
- Update bundled prompts from v0.12.15 to v0.12.16 [useReq] *(prompts)*
- load %%ARGS%% user requests from @file references [useReq] *(prompt-args)*
  Add src/core/prompt-command-args.ts (DES-047): empty prompt-command input maps to the fixed no-request placeholder (REQ-782); '@' references load double-quoted, single-quoted, backslash-escaped, and plain-space paths with tilde expansion (REQ-783, REQ-784, REQ-787); syntax, missing-file, non-regular, binary, and empty-content failures raise deterministic ReqError causes (REQ-785, REQ-786, REQ-788, REQ-789, REQ-791); verbatim UTF-8 content substitutes %%ARGS%% (REQ-790); non-covered commands keep raw passthrough (REQ-793).; Wire the prompt-command handler to pass the resolved request text into execution preparation and rendered prompts while the invocation summary keeps raw input (REQ-781, REQ-792).; Add tests/prompt-command-args.test.ts covering TST-246..TST-249 and update REQUIREMENTS.md, WORKFLOW.md, and REFERENCES.md.
- Add 80-percent red alert styling to config-menu occupancy suffixes [useReq] *(context-file-size)*
  Add CONTEXT_OCCUPANCY_MENU_ALERT_THRESHOLD_PERCENT plus
  formatConfigMenuContextOccupancySuffix in src/core/context-file-size.ts:
  occupancy suffixes in the Context Files top-level summary and submenu rows
  wrap unchanged in intense-red ANSI when the displayed percentage exceeds 80.
  Expose the numeric displayed percentage in ContextOccupancyFacts; command
  summary and early-check diagnostics keep the plain suffix (REQ-770).
  Requirements DES-046, REQ-768..770, TST-241..242; new
  tests/context-occupancy-menu.test.ts (4/4); full suite 581/582 with the
  only failure pre-existing on HEAD (stale release-workflow allowlist
  assertion vs REQ-743). WORKFLOW.md and REFERENCES.md regenerated.
- reserve 5-column right margin in table width [useReq] *(next-workflow)*
  REQ-749 now derives the Next-Workflow Text column wrap target as the pi CLI
  terminal column count minus the other columns, row chrome, and a fixed
  5-display-column right margin, so at equal console width the Next-Workflow
  tables printed in the notification message and final-output render are
  5 display columns narrower while staying left-aligned.
  Implements the margin through new constant NEXT_WORKFLOW_TABLE_RIGHT_MARGIN_WIDTH
  consumed by resolveNextWorkflowTextColumnTargetWidth; the fixed minimum 35
  fallback and the table framing stay unchanged.
  Updates the wrap-target and terminal-width conformance unit tests to the
  margin-aware derivation and widens the fallback boundary coverage.
- italicize single-quote spans with nested ANSI composition [useReq] *(agent-final-output)*
  REQ-715 extended: single-quote-span elements join the ANSI colored markdown enumeration.; New REQ-763..REQ-767: italic single-quote spans, composed italic+code for nested inline code, apostrophe-boundary pairing, atomic protected spans, no non-code inline re-matching inside quotes.; AGENT_FINAL_OUTPUT_ANSI_PROTECTED_SPAN_PATTERN segments code and quote spans atomically; replaceAgentFinalOutputAnsiProtectedSpan and colorizeAgentFinalOutputQuotedSpan compose per-token SGR (ESC[3m text, ESC[3;36m code) so nested resets never end the italic region.; Shared colorizer applies the same styling to the Next-Workflow table (REQ-732).; WORKFLOW.md call-trace nodes updated; REFERENCES.md regenerated.; 4 new tests in tests/agent-final-output.test.ts; suite 15/15 pass; tsc and eslint clean.
- make parameterized dispatch orchestration-transparent [useReq] *(req-continue)*
  REQ-660 now mandates gate-free ordinal delegation from every workflow state: /req-continue applies no startability gate and performs no workflow-state transition or busy-state rejection of its own; the delegated command owns every gate, transition, and terminal outcome exactly like a manual user invocation (REQ-663, REQ-664). REQ-224 exempts parameterized req-continue from the busy-state rejection while delegated commands keep enforcing it. Persisted-terminal resynchronization is reframed as pre-delegation state observation for direct-invocation equivalence. Updated TST-218, evidence rows, WORKFLOW.md runtime model, and regenerated REFERENCES.md. Tests: req-continue suites 165/165 pass; full suite 573/574 with one pre-existing stale release-allowlist test contradicting CTN-021.
- Auto-update pi CLI refs/docs without confirmation and commit sync [useReq] *(pi-cli-update-src-docs)*
  REQ-388, REQ-389: print versions before the automatic gate and
  synchronize without user confirmation when the stored source
  version is unknown or strictly older than the latest pi CLI
  release under version-sorted ordering.
  REQ-757..REQ-762: exit 0 unchanged when not newer, abort outside a
  git work tree, stage only the synchronized targets plus markers,
  create exactly one change(pi-cli-src-docs-update) commit, skip it
  on an empty staged diff, and abort non-zero on commit failure.
  REQUIREMENTS.md: applied the requirement delta.
- restrict auto-update to strictly newer versions [useReq] *(prompts-updater)*
  REQUIREMENTS: REQ-398 now gates synchronization on the resolved latest
  version being strictly greater than the stored version; REQ-751 skip
  condition extended to versions lower than or equal to the stored one.
  SOURCE: is_update_eligible() adds a strict string-inequality guard
  before the sort -V sortedness check so equal versions skip the update;
  header and skip-log wording updated to 'equal to or older'/'not newer'.
- auto-update without confirmation and commit sync [useReq] *(prompts-updater)*
  REQUIREMENTS: REQ-397 prints versions before the gate decision; REQ-398
  now mandates automatic synchronization without confirmation; added
  REQ-751 (downgrade skip), REQ-752 (git work-tree probe), REQ-753
  (single current-branch commit), REQ-754 (commit subject format),
  REQ-755 (skip commit on empty staged diff), REQ-756 (fail on error).
  SOURCE: scripts/pi-prompts-update.sh replaces the Y/N confirmation
  with the sort -V version gate, adds is_update_eligible() and
  commit_update() staging only the synchronized directories plus the
  version marker, and updates all Doxygen documentation.
- Adapt Next-Workflow table width to CLI terminal [useReq] *(next-workflow)*
  Rewrite REQ-729: wrap the Text column at the effective target width and hard-break unbreakable words instead of widening the column for oversized tokens.; Add REQ-749 and REQ-750: derive the Text column wrap target from the pi CLI terminal column count (terminal minus fixed columns minus row chrome) with the fixed minimum 35-display-column fallback when stdout width is unavailable.; Implement resolveNextWorkflowTextColumnTargetWidth, readNextWorkflowTerminalColumns, display-width hard-breaking in next-workflow.ts with an optional terminalColumns parameter on formatNextWorkflowCommandTable.; Re-align tests/next-workflow.test.ts with the updated wrapping contract and add target-width plus terminal-conformance coverage.
- ship npm CHANGELOG.md and migrate pi CLI changelog keys [useReq] *(package-manager)*
  Add CHANGELOG.md to the npm files allowlist so the published tarball
  exposes the parser-compatible changelog for the pi CLI boot-time
  extension changelog show (CTN-021, REQ-743, TST-237).
  Best-effort migrate the pi CLI extensionChangelogVersions recorded
  value from the previous same-identity git-tagged settings key onto the
  new tag-pinned key after successful develop-channel upgrade children,
  preserving every other settings field and never changing the upgrade
  exit code or summary (DES-045, REQ-744..REQ-748, TST-238..TST-240).
- BREAKING CHANGE: remove req-continue-list slash command [useReq] *(next-workflow)*
  Remove the dedicated /req-continue-list command, its registration, description constant, and the numbered full-list renderer.
  Parameter-less /req-continue keeps printing the captured Next-Workflow table and the integer ordinal keeps dispatching the captured command (REQ-659..664, REQ-738..741).
  SRS: delete REQ-671..676, DES-041, and TST-222..224; update scope and next-workflow surface description.
  Docs: regenerate REFERENCES.md; prune the removed call-trace from WORKFLOW.md.
  Tests: remove the three obsolete req-continue-list tests; full suite passes 572/572.
- document default-enabled custom-tool inventory [useReq] *(core)*
  Add REQ-742: every configurable custom tool stays enabled by default until a persisted enabled-tools selection explicitly overrides the default. Bump SRS version 0.0.167 to 0.0.168 and append the REQ-742 evidence row. Link REQ-742 from the PI_USEREQ_DEFAULT_ENABLED_TOOL_NAMES and normalizeEnabledPiUsereqTools Doxygen contracts in src/core/pi-usereq-tools.ts. Regenerate REFERENCES.md from the updated source.
- require ordinal parameter and print Next-Workflow table without one [useReq] *(req-continue)*
  REQUIREMENTS.md: req-continue dispatch requires one integer ordinal
  (REQ-660..REQ-662); parameter-less invocation prints the Next-Workflow
  section table into the editor from every workflow state with no side
  effects (REQ-738..REQ-741, TST-235, TST-236).
  src: resolveNextWorkflowEntryIndex mandates the ordinal; the continue
  handler gains the parameter-less editor print branch (575 tests pass).
  tests: ordinal, registration, and delegation suites updated; new
  print-branch test added. WORKFLOW.md and REFERENCES.md regenerated.
- BREAKING CHANGE: Rename all agent tools with the req- prefix [useReq] *(tools)*
  Rename the twelve configurable agent tools (compress -> req-compress,
  references -> req-references, search -> req-search, static-check ->
  req-static-check, summarize -> req-summarize, tokens -> req-tokens,
  files-* -> req-files-*, result-json-validator -> req-result-json-validator)
  to avoid name collisions with embedded or third-party pi CLI tools.
  Update registration metadata and bundled agentic prompt descriptions,
  the menu-order req-files-* grouping, the debug --args converter, and
  registration tests. Requirements: REQ-735..REQ-737, TST-234 plus
  renamed tool identifiers across existing REQ/TST lines.
- render full-text table and tabular req-continue citations [useReq] *(next-workflow)*
  REQ-722..725/729..732: the ANSI-report Next-Workflow table now carries the full untruncated input text (whitespace-normalized) wrapped at whitespace boundaries into at most 35-display-column lines rendered as continuation physical rows with empty sibling cells, right-aligned one-based ordinals, the 'Next Workflow' column header, display-width-based column sizing, and the same section ANSI markdown colorizer applied to the table text.
  REQ-657/658/733/734: the numbered list after the retention line is replaced by the '/req-continue' command table ('Continue comand'/'Workflow'/'Text') carrying invokable '/req-continue <ordinal>' commands and only the first-20/' .. '/last-10 condensed citations with N/A placeholders.
  Tests updated for the new rendering contracts: 572 pass, 0 fail; tsc and eslint clean.
- BREAKING CHANGE: rename json-validator agent tool to result-json-validator [useReq] *(result-json-validator)*
  Renames the registered agent tool, its module (src/core/result-json-validator.ts), and its tool-scoped symbols to the new naming convention; requirements DES-044, REQ-064, REQ-701..709, TST-229..233 updated (version 0.0.166).
  Bundled prompt resources now instruct the agent to execute result-json-validator exclusively for validating the final agentic output JSON message and never for generic JSON artifacts; alphabetical toggle-order expectations updated (REQ-231); tests renamed and updated; workflow model and references regenerated.
- enforce final-output field contract in verdicts [useReq] *(json-validator)*
  json-validator verdicts validate every parsed record against the orchestration final-output mandatory-field contract (result ok|error, summary string, next_commands array) and render the contract verdict with per-field issue diagnostics (REQ-726..REQ-728).; json-validator registration text binds the tool exclusively to final-output JSON message validation and prohibits generic JSON validation (REQ-709, TST-233).; Shared isAgentFinalOutputResult export keeps one contract source; requirements, workflow model, references, and tests updated.
- box report titles and render next-workflow command table *(notify)*
  Render ANSI report section titles as rounded box frames sized from the label length, keeping intense-yellow styling (REQ-720, REQ-721).; Render the captured Next-Workflow commands as a dynamically sized rounded table with N./Command/Text columns, zero-padded ordinals, uppercase prefix-free commands, N/A placeholders, double-line header separator, and row separators (REQ-722, REQ-723, REQ-725).; Condense over-limit table texts with the ' .. ' separator via condenseNextWorkflowTableInputText (REQ-724).; Append the table to the ANSI report notification for every outcome (REQ-722).; SRS v0.0.164 adds REQ-720..REQ-725; WORKFLOW.md call traces and REFERENCES.md refreshed.
- color retention line and print terminal diagnostics last in red *(notify)*
  Render the complete Context retained. sentence with the percentage segment in intense white with the percentage in intense yellow ANSI (REQ-716, REQ-717).; Emit every terminal error/warning orchestration diagnostic in intense red through notifyTerminalOrchestrationDiagnostic (REQ-718).; Order terminal diagnostics after the report printout, the Next-Workflow list, and the context-percentage line; move the stash warning after the retention reminder (REQ-719).; Centralize ANSI SGR styling in the new src/core/ansi-style.ts module consumed by the report renderer.; SRS v0.0.163 adds REQ-716..REQ-719; WORKFLOW.md call traces and REFERENCES.md refreshed.
- print ANSI-colored final-output report for every prompt outcome *(agent-final-output)*
  Render markdown report notifications with ANSI escapes: intense-yellow ## **<Label>** headings plus colored links, fences, inline code, bold, italic, and underline elements (REQ-713..REQ-715).; Emit the report notification for every terminal outcome with a parsed final-output report, including result error gate closures at agent_end and agent_settled (REQ-712).; Persist pendingFinalizationReport so settle-time result error closures print the terminal run's report.; SRS v0.0.162 adds REQ-712..REQ-715; WORKFLOW.md call traces and REFERENCES.md refreshed.
- extract embedded final-output JSON at prompt closure [useReq] *(agent-final-output)*
  SRS 0.0.161: REQ-584 extracts one embedded JSON object; REQ-710/REQ-711 added.
  REQ-678 validates the extracted object; TST-225 covers wrapped and fenced cases.
  agent-final-output adds extractFinalOutputJsonObject with a string-aware balance scan.
  parseAgentFinalOutput strips prose plus markdown fences before JSON.parse.
  Object-free and multi-object outputs keep the JSON-contract diagnostic.
  tests/agent-final-output.test.ts extends TST-225 with the reproducer cases.
  WORKFLOW.md and REFERENCES.md updated for the changed symbols.
  Verified: static-check clean; npm test 563/563 passed.
- BREAKING CHANGE: add scan-by-dir recursive directory-scan execution [useReq] *(static-check)*
  Add optional boolean scan-by-dir flag to every static-check Command entry (REQ-694); Default scan-by-dir TRUE for cppcheck, ruff, eslint; FALSE otherwise (REQ-695, REQ-699); Execute scan-by-dir checkers once over src-dir plus tests-dir with checker-native
  fixture-root exclusion arguments; keep per-file dispatch for all other entries
  (REQ-696, REQ-697, REQ-698, REQ-700)
  Support scan-by-dir reads and writes through the configuration CLI boolean field; Update REQUIREMENTS/WORKFLOW/REFERENCES docs and default-config test expectations; Speeds project static-check on this repository from ~232s to ~5s
- Add --write-config default materialization command [useReq] *(config-cli)*
  Implement the zero-argument --write-config configuration CLI command
  (REQ-689..REQ-692) that materializes only absent schema parameter
  defaults into the local and global configuration files without ever
  overwriting persisted values, unknown keys, or file permissions.
  Make --set/--unset persistence absence-preserving (REQ-693): absent
  untouched parameters stay absent while requested mutations and
  scope-policy effects still persist; identical payloads skip the write.
  Add DES-043 plus TST-227/TST-228 with the new config CLI test suite
  and update the SRS, WORKFLOW runtime model, and REFERENCES index.
- BREAKING CHANGE: Parse final-output JSON gates and reports replacing fences [useReq] *(core)*
  Add src/core/agent-final-output.ts: single-JSON-object parse, mandatory result/summary/next_commands validation, markdown report rendering, process-scoped report capture (REQ-677-684, DES-042).; Gate worktree merge on the JSON result field replacing STATUS_OK keywords (REQ-584-589); park error with user-facing diagnostics for result error and invalid outputs (REQ-580/587/588).; Resolve %%OUTPUT%% from the JSON summary on command-notify and Pushover (REQ-469-472).; Capture Next-Workflow commands from the next_commands array (REQ-653-655); render report sections before the retention line (REQ-681).; Update tests: next-workflow, agent-final-output suite, extension-registration closures; bump SRS to 0.0.157.
- Parse STATUS_OK plus RESULT_SUMMARY and NEXT_WORKFLOW fences [useReq] *(core)*
  Replace the legacy STATUS: OK / STATUS: ERROR marker scans with the
  parseable STATUS_OK / STATUS_ERROR keywords in the worktree merge gate,
  retention notifications, requirements, and closure tests.
  Extract the Pushover %%OUTPUT%% channel exclusively from the closed
  ~~~RESULT_SUMMARY fence, dropping the Summary/Outcome heading slicing
  and its output-end fallback (REQ-510 removed).
  Capture Next-Workflow commands exclusively from blank-line-separated
  entries inside the ~~~NEXT_WORKFLOW fence, replacing the
  ## **Next Workflow** section plus ~~~text block parser.
  Update REQUIREMENTS/WORKFLOW/REFERENCES, source logic, and tests;
  static-check clean, npm test 539/539 passed.
- re-point pi CLI to retained worktree on merge failure [useReq] *(orchestration)*
  REQ-665..668: on fast-forward merge failure redirect the active session,
  process cwd, and context cwd back to the retained worktree, emit the
  retention notification with the numbered Next-Workflow list before the
  error output, terminate that output with the hardcoded uniform ERROR:
  merge-failure message, and keep the captured array unchanged.
  REQ-669: wipe the Next-Workflow array only immediately before dispatching
  a new agentic flow, after every slash-command pre-check succeeded, so
  failed pre-checks preserve the queued commands.
  REQ-660/REQ-670: /req-continue now dispatches from the idle state whenever
  the array holds commands and /req-reset preserves the array for recovery.
  REQ-365/REQ-656: retention and preservation contracts updated; evidence
  matrix, workflow model, references, and unit tests aligned (TST-083/218/219/220/221).
- resolve new/continue agentic flow at bootstrap and gate context-file injection [useReq] *(prompt-commands)*
- pad the status request arrow with surrounding spaces [useReq] *(status-bar)*
  REQ-632/TST-206 now require '<request> ➔ <state>' in the status field value.; PI_USEREQ_STATUS_REQUEST_STATE_SEPARATOR now renders ' ➔ ' instead of '➔'.; Refresh REQUIREMENTS, WORKFLOW, and REFERENCES for the padded separator.; Update status-bar expectations in the extension registration suite.
- BREAKING CHANGE: suppress command-notify, sound, and pushover for non-agentic commands [useReq] *(notifications)*
  Rewrite REQ-447 so completed or failed /req-references and /req-reset runs never dispatch command-notify, sound, or Pushover prompt-end effects, and drop the superseded REQ-448/REQ-449 output-line requirements.
  Remove the non-agentic notification dispatcher plus the req-reset outcome-line and command-report serializer helpers, update README notification documentation, and replace the report-pushing test with a no-dispatch test covering completed and failed non-agentic runs.
- BREAKING CHANGE: install the develop release tag and report pi-managed versions [useReq] *(package-manager)*
  Requirements: REQ-482/REQ-641 mandate the tag-pinned develop 'pi install' reconciliation child; REQ-527/REQ-646 drop extension force-reinstall claims; REQ-487/REQ-647/REQ-648 add pi-managed-first installed-version resolution; TST-211..TST-213 added.; Source: run the tag-pinned install child for same-source develop upgrades, remove PACKAGE_FORCED_UPGRADE_COMMAND and the develop update command builder, gate only the default-channel already-latest probe on --force, and resolve 'Current Installed' plus the completion summary from the pi-managed git then npm roots.; Tests: cover the unpinned develop-channel reconciliation path and pi-managed-first installed-version resolution.
- make npm ci toolchain provisioning opt-in via --install [useReq] *(pre-release-check)*
  Run one npm ci provisioning pass only when --install is supplied, before the pre-run inventory snapshot and stage 1, and drop npm ci from the numbered stage sequence (REQ-491, REQ-493, REQ-495, REQ-642, REQ-643).; Keep the default run free of provisioning so the gate reuses the existing node_modules tree and the snapshot diff baseline never sees provisioning churn (REQ-642, REQ-643).; Replace the --skip-install option and its usage text, update the tsc remediation hint, and add the opt-in ordering regression coverage (TST-210).
- pin develop-channel upgrades to the latest GitHub release tag [useReq] *(package-manager)*
  Resolve the develop-channel <tag> from the GitHub latest-release probe and abort with exit code 1 before any child when the probe fails (REQ-482, REQ-639, REQ-640).; Install and update the ref-pinned git:github.com/Ogekuri/PI-useReq@<tag> source, including the forced --force variant (REQ-527, REQ-613, REQ-641).; Add regression coverage for the tag-pinned install and the probe-failure abort, and update develop-channel assertions (TST-166, TST-176, TST-200, TST-208, TST-209).
- render status request arrow as ➔ [useReq] *(status-bar)*
  REQ-632/TST-206 now require '<request>➔<state>' in the status field value.; Join request and state with PI_USEREQ_STATUS_REQUEST_STATE_SEPARATOR.; Refresh REQUIREMENTS, WORKFLOW, and REFERENCES for the new arrow token.; Update status-bar assertions in the extension registration suite.
- prefix branch value with the ⎇ glyph [useReq] *(status-bar)*
  REQ-121/TST-095 now require the status-bar branch value to carry the '⎇ ' prefix.; Render the branch field as 'branch:⎇ <branch>' via PI_USEREQ_STATUS_BRANCH_PREFIX.; Refresh REQUIREMENTS, WORKFLOW (prefix-free resolution plus prefixed rendering), and REFERENCES.; Update status-bar branch assertions in extension-registration and debug harness tests.
- add done orchestration state and request-token status [useReq] *(workflow)*
  Persist the active slash-command request token in orchestration runtime state.; Render <request>►<state> in the status bar and keep idle request-less.; Add the done terminal state; successful non-reset runs end in done.; Restrict idle to bootstrap/reload and /req-reset, and allow done -> running.; Reject warning/error restarts until /req-reset; update requirements, workflow, references, and tests.
- homogenize Next Workflow generation guidance [useReq] *(prompts)*
  Add one homogeneous Next Workflow rule block to 14 bundled prompts.; Require a next step only when mandatory; forbid optional ones.; Enforce ~~~text fenced command blocks carrying the command prompt text.; Align analyze.md with the mandatory-only rule while keeping 4 commands.; Add REQ-624..REQ-628 and requirements evidence rows.
- write no-source placeholders for references and workflow [useReq] *(req-references)*
  Add git-inventory source detection plus declared no-source placeholder payloads in src/core/source-presence.ts.
  req-references now writes the EMPTY_REFERENCES system directive instead of failing reference extraction, and req-workflow writes the EMPTY_WORKFLOW directive instead of dispatching the agentic workflow.
  Update REQUIREMENTS.md (REQ-620..REQ-623, DES-039, TST-204..TST-205), WORKFLOW.md call traces, REFERENCES.md, and extension registration tests.

### 🎯  Cover Requirements
- add status-marker closure coverage [useReq] *(tests)*
  Add seven extension-registration tests covering STATUS: OK merge, STATUS: ERROR retention, markerless warning, text-less merge eligibility, dual-marker precedence, multi-run candidate overwrite, and final-message-only inspection.; Align the fake status-bar helper with blinking warning rendering (REQ-590).; Replace nonexistent Doxygen REQ-577..REQ-583 references with REQ-584..REQ-590 and refresh REFERENCES.md.

### ◀️  Revert
- Roll back branch to 5fdad9a0 (5fdad9a009d5fc7007003e76c4959feabaad0de6).

## [0.109.0](https://github.com/Ogekuri/PI-useReq/compare/v0.108.0..v0.109.0) - 2026-11-12
### 🐛  Bug Fixes
- publish prebuilt tarball via explicit local path [useReq] *(release-npm)*
  npm parses a bare 'dist/pi-usereq-<version>.tgz' argument as a hosted-git
  GitHub shorthand, so publication ran 'git ls-remote
  ssh://git@github.com/dist/pi-usereq-<version>.tgz.git' and failed with
  exit code 128.
  emit artifact_path with an explicit './' local-file prefix that npm
  resolves as a file tarball instead of a hosted git repository
  document the shorthand hazard at the artifact-resolution and publish steps; add a regression test pinning the local-file publication path
- repair launcher and version reporting after source switch [useReq] *(package-manager)*
  re-point the agent-bin pi-usereq launcher onto the freshly installed
  channel target root after a successful pi remove/pi install source
  switch, so the management CLI cannot remain a dangling symlink
  resolve the post-switch completion version from the target installation
  manifest instead of the deleted runtime installation that owned the
  running process, removing the false unchanged-version warning
  add a reproducer covering launcher repair and target-root version
  reporting, and update WORKFLOW.md plus regenerated REFERENCES.md
- make postinstall bootstrap dependency-free for git installs [useReq] *(package)*
  Add scripts/install-static-checkers.js plain-Node wrapper that defers bundled
  checker installation when node_modules/tsx is absent, so npm git-dependency
  preparation clones never abort with ERR_MODULE_NOT_FOUND: Cannot find package
  'tsx'. The wrapper delegates to scripts/install-static-checkers.ts whenever the
  dependency tree exists, preserving the best-effort exit-code-0 installer and
  allow-scripts approval behavior (DES-017, REQ-339).
  Point the postinstall script at the wrapper, ship it in the npm files allowlist,
  and align the allowScripts version pins with the resolved dependency versions
  (esbuild 0.27.2, protobufjs 7.6.6, @google/genai 2.21.0).
  Add a reproducer suite covering the dependency-free clone path and update the
  files allowlist assertion (PRJ-009, REQ-482, REQ-484, CTN-020).

### 🚜  Changes
- reconcile npm and git install sources before upgrade [useReq] *(package-manager)*
  identify installed npm-managed or git-managed package source before --upgrade; remove the identified package with pi remove before installing a different channel target; install the channel target with pi install and skip the already-latest gate on source switch; recognize npm, git, and project-scope .pi install trees for launcher deployment; update requirements, workflow runtime model, references, and unit tests
- clean dist before build and fail on stale tarballs [useReq] *(build)*
  Update REQ-568 to cover symbolic-link tarball entries and add REQ-607/REQ-608
  requiring the previous-build cleanup verification to abort with a non-zero
  exit code before dependency preparation, compilation, and packaging while
  naming the surviving dist/*.tgz path.
  scripts/build.sh: match regular files and symlinks in the previous-build
  tarball removal, add verify_previous_dist_clean(...) invoked at the end of
  clean_previous_build_artifacts(...), and refresh usage plus Doxygen docs.

## [0.108.0](https://github.com/Ogekuri/PI-useReq/compare/v0.107.0..v0.108.0) - 2026-11-12
### ⛰️  Features
- Update prompts.
- Update gitalias config.
- add scripts/clean.sh cleaning all build.sh artifacts [useReq] *(scripts)*
  Add a standalone bash cleanup script that removes the root-level
  dist/*.tgz release tarballs generated by scripts/build.sh, removes the
  dist/ directory itself only when emptied, and removes the node_modules/
  dependency tree only under the explicit --node-modules or --all opt-in.
  Requirements: add DES-036, REQ-591..REQ-596, TST-191, TST-192 and the
  related scope, component-model, tree, and evidence entries.
  Tests: add tests/clean-script.test.ts with sandboxed coverage of syntax,
  default cleanup, preservation rules, opt-in removal, option rejection,
  and artifact-free success.

### 🐛  Bug Fixes
- Restrict npm files allowlist to runtime artifacts [useReq] *(package)*
  Remove maintainer-only debug harness and tool-args converter from package.json files allowlist (CTN-021).; Align release-workflow allowlist assertion with the runtime-only file set (reproducer failed before fix).; Delete dead src/core/compress-payload.ts and src/core/find-payload.ts (zero runtime references).; Declare FindToolScope locally in src/index.ts, removing the type-only import of find-payload.ts.; Regenerate usereq/docs/REFERENCES.md with the references tool.
- Restrict npm tarball to runtime files and stop stages on first failure [useReq] *(build)*
  package.json: files allowlist narrowed to runtime entries; pi-prompts-version.txt excluded by negated pattern.; Removed unreferenced assets favicon.svg and Machine-alert-beep-sound-effect.mp3.; scripts/build.sh: stage failure detected by ERR trap instead of an if-condition (set -e was suspended inside if); find output piped instead of process-substituted so pipefail propagates.; tests/release-workflow.test.ts: reproducer for the files allowlist contract (REQ-573, CTN-021).

### 🚜  Changes
- package and validate release tarball in a temporary directory [useReq] *(pre-release-check)*
  Move release packaging and validation out of dist/ into a TMPDIR temporary build directory through npm pack --pack-destination.
  Perform no dist/ operation, make the gate independent from dist/ content, and remove the temporary build directory on every exit path.
  Update requirements REQ-491, REQ-496, REQ-572, REQ-574 and add REQ-604, REQ-605, REQ-606.
- remove pre-existing dist release artifacts and verify removal [useReq] *(pre-release-check)*
  Reuse the scripts/build.sh previous-build tarball removal in the pre-release gate bootstrap and verify that no dist/*.tgz artifact survived it.
  Add the same post-removal absence verification to scripts/build.sh and preserve non-tarball dist/ entries in both scripts.
  Update REQ-491, REQ-574, add REQ-604..REQ-608 plus TST-198/TST-199, and cover bootstrap removal, retention, and verification aborts with tests.
- commit dist artifact and drop dist presence mandates [useReq] *(requirements)*
- publish pre-built dist artifacts in GitHub workflow [useReq] *(release)*
  Make release job consume the tagged commit pre-built dist/*.tgz artifacts.; Publish the pre-built tarball directly with npm and OIDC provenance.; Upload dist/*.tgz to the GitHub Release and remove src/**/* assets.; Remove npm ci, npm test, npm run build, and private-flag edits.; Never invoke scripts/build.sh or scripts/pre-release-check.sh.; Update REQUIREMENTS.md and release-workflow tests.
- BREAKING CHANGE: integrate previous-build cleanup into build.sh [useReq] *(scripts)*
  Move dist/ previous-build cleanup from scripts/clean.sh into scripts/build.sh.; Remove every dist/*.tgz tarball for all present versions and empty dist/.; Delete scripts/clean.sh and its test suite.; Add post-build cleanup removing run-created temporary/intermediate entries.; Preserve node_modules/, pre-existing entries, and the verified tarball.; Update REQUIREMENTS.md and add tests/build-script.test.ts.
- Track dist/ release artifacts in git [useReq] *(dist)*
  .gitignore: add !dist/ and !dist/**/* re-inclusions; remove dist/*.tgz exclusion (REQ-575, REQ-576); scripts/pre-release-check.sh: keep dist/ tarballs on successful gates, remove them on failure or signal exits; skip dist/ in generic cleanup (REQ-496, REQ-498, REQ-574); tests/gitignore-dist.test.ts: add git check-ignore and gate syntax tests (TST-189, TST-190); usereq/docs/REQUIREMENTS.md: update REQ-496, REQ-498, REQ-574, REQ-575, REQ-576; add TST-189, TST-190; version 0.0.135
- gate worktree merge on STATUS markers [useReq] *(prompt-command)*
  Inspect the final agent output before worktree closure and require the exact
  STATUS: OK marker before merging and deleting the worktree. STATUS: ERROR parks
  the orchestration in error, while a missing marker parks it in the new
  blinking warning state; both retain the worktree for req-reset recovery.
  Adds the warning workflow state across status rendering, debug inventories and
  configuration, updates requirements, workflow, and references.
- add release build script and pre-release artifact gate [useReq] *(build)*
  add scripts/build.sh: toolchain gate, npm ci bootstrap, tsc --noEmit compile
  gate, stale dist/*.tgz pruning, npm pack into dist/, artifact verification
  extend scripts/pre-release-check.sh: six-stage gate with tarball validation
  (package.json, LICENSE, README.md, src/index.ts, scripts/pi-usereq.js) and
  inode-precise cleanup of run-generated dist tarballs on all exit paths
  .gitignore: keep inverse strategy, make dist/ traversable, ignore only
  generated /dist/*.tgz tarballs
  fix src/index.ts renderResult context typing for pi SDK ToolRenderContext; requirements: REQ-491 updated; add DES-035, REQ-564..REQ-576
- add schema-driven config CLI with deterministic tree rendering [useReq] *(config-cli)*
  Add --get, --set, --unset, --print, --info, and --print-raw over the existing local and global scopes.
  Add a strict canonical schema with typed parsing, validation, projection, and defaults derived from getDefaultConfig.; Add one shared recursive tree renderer plus a display-width table formatter used by both --print and --info.; Persist mutations atomically with same-directory temp files, fsync, rename, and permission preservation.; Add renderer golden tests, structural and table validators, command-behavior tests, and the Global detail-prefix regression.; Update REQUIREMENTS, WORKFLOW, and REFERENCES.
- run pi update on --upgrade and report real installed version [useReq] *(package-manager)*
  REQ-481/482/526/528: default and develop --upgrade channels now spawn
  'pi update <source>' so an installed package advances past its saved range
  REQ-484: completion summary resolves the updated version from re-read
  installation-owned package metadata instead of a registry re-probe
  REQ-531: non-forced upgrades warn on stderr when the installed version
  is unchanged after the child, without changing the exit code
  TST-165/166/177: package-manager test suite updated accordingly

### ◀️  Revert
- Roll back branch to 5d2567b9 (5d2567b9fc8d748f5f51aa4f35f3ae4ec7fe9d48).

## [0.107.0](https://github.com/Ogekuri/PI-useReq/compare/v0.106.0..v0.107.0) - 2026-11-10
### ⛰️  Features
- Update docs/pi.dev and pi.dev-src to PI Cli v1.5.2.
- Update prompts.

### 🚜  Changes
- require pi CLI v1.5.2 [useReq] *(core)*
  Align peer packages and lockfile with pi CLI v1.5.2.
  Use the v1.5.2 TypeBox schema module and update host compatibility checks.
- Align --ver/--version report labels to one version column [useReq] *(package-manager)*
  REQ-475/REQ-502: render the three report lines as 'Current Installed :',
  'Latest @ NPMjs    :' and 'Latest @ GitHub   :' (failed GitHub probe renders
  'Latest @ GitHub   : unknown (<reason>)').
  REQ-529: right-pad report labels to the fixed 18-character column so ':'
  separators and version numbers align vertically.
  Update package-manager suite expectations; suite passes 37/37, static-check clean.; REQUIREMENTS.md bumped to 0.0.129; WORKFLOW.md call trace and REFERENCES.md
  regenerated for the new report formatter.

## [0.106.0](https://github.com/Ogekuri/PI-useReq/compare/v0.105.0..v0.106.0) - 2026-11-09
### 🚜  Changes
- add --force upgrade reinstall support [useReq] *(package-manager)*
  Accept the auxiliary --force option on --upgrade and --upgrade --dev|--develop
  management argv shapes (two- and three-token forms, any order) per REQ-473,
  REQ-524, REQ-525; other shapes still fall through to standard parsing.
  Forced upgrades skip the already-latest registry gate and run the pi CLI
  force-reinstall update form (pi update npm:pi-usereq --force on the default
  channel, pi update git:github.com/Ogekuri/PI-useReq --force on the develop
  channel) forcing full package download and reinstallation (REQ-526, REQ-527).
  Non-forced upgrades keep the standard already-latest-gated pi install flow
  on both channels (REQ-528).
  Update PRJ-009 and DES-026 surfaces, WORKFLOW.md call traces, REFERENCES.md,
  and add 9 force-coverage unit tests (package-manager suite: 37 cases).
- upgrade via pi CLI manual install commands [useReq] *(package-manager)*
  REQ-481: default-channel --upgrade runs pi install npm:pi-usereq.; REQ-482: --dev/--develop runs pi install git:github.com/Ogekuri/PI-useReq
  without registry comparison or GitHub release probe.
  REQ-483 removed: the develop-channel GitHub-probe failure gate no longer
  exists; child exit codes and spawn-failure hints still propagate (REQ-485).
  Both channels resolve the completion summary through the follow-up npmjs
  manifest probe (REQ-484); --help rows document the pi CLI install forms.
  tests/package-manager.test.ts aligned to TST-165/TST-166; 464/464 pass.

## [0.105.0](https://github.com/Ogekuri/PI-useReq/compare/v0.104.0..v0.105.0) - 2026-11-09
### 🚜  Changes
- replace stale home-resource evidence with installation-owned facts [useReq] *(requirements)*
  Correct CTN-001/CTN-011/PRJ-005/REQ-009/TST-002 evidence rows in REQUIREMENTS.md; Remove stale home-resource synchronization wording from sections 5.1 and 7.1; Align WORKFLOW.md external boundary phrasing with installation-owned resources; Bump REQUIREMENTS.md document version to 0.0.126; No source-code changes; behavior verified by full test suite (465/465 pass)

## [0.104.0](https://github.com/Ogekuri/PI-useReq/compare/v0.103.0..v0.104.0) - 2026-11-09
### ⛰️  Features
- Update prompts.

### 🚜  Changes
- add conditional ~/bin pi-usereq launcher symlink layer [useReq] *(bin-deploy)*
  Deploy a best-effort ~/bin/pi-usereq symlink targeting the deployed
  pi agent-bin launcher during activation of pi-package installations,
  only when ~/bin already exists and the agent-bin launcher entry is a
  deployed symlink; idempotent, foreign-entry protected, never aborts
  activation (REQ-516..REQ-520, DES-031). --uninstall removes the
  ~/bin link before the agent-bin launcher removal and the global
  uninstall child while preserving the exit-code contract
  (REQ-521..REQ-523). Updates REQUIREMENTS.md, WORKFLOW.md, and
  REFERENCES.md.
- print full help when pi-usereq runs without arguments [useReq] *(cli)*
  Map empty argv to the --help management command so pi-usereq and scripts/pi-usereq.sh print the help screen with exit code 0 (REQ-515).; Keep standard flag parsing untouched for every non-empty argv shape (REQ-474).; Update REQUIREMENTS/WORKFLOW/REFERENCES documentation for the no-argument behavior.
- add pi-usereq --help management command [useReq] *(package-manager)*
  Add --help full help screen with usage header and fixed-order Management Commands rows (REQ-512, REQ-513).; Add --help <topic> single-row help for --upgrade/--dev/--develop/--uninstall/--ver/--version in either order (REQ-511, REQ-514).; Extend management argv detection and dispatch with --help (PRJ-009, DES-026, REQ-473).; Update REQUIREMENTS/WORKFLOW/REFERENCES documentation for the new command surface.

## [0.103.0](https://github.com/Ogekuri/PI-useReq/compare/v0.102.0..v0.103.0) - 2026-11-09
### ⛰️  Features
- Update prompt files.

### 🐛  Bug Fixes
- anchor launcher target and removal containment on package root [useReq] *(bin-deploy)*
  Deploy and remove launcher helpers resolved the npm package root from
  the source-root installation path, so the composed target pointed at
  <pkg>/src/scripts/pi-usereq.js and every real pi-package activation
  silently skipped deployment with launcher-missing (REQ-504), while
  uninstall containment would misclassify correctly placed launchers as
  foreign (REQ-508/REQ-509). Anchored target composition plus ownership
  containment on the package root and added a default-resolution
  reproducer covering the real npm package layout (TST-173, TST-174).

### 🚜  Changes
- extract Pushover message text from Summary report section [useReq] *(notify)*
  REQ-469 now slices the completed prompt-end Pushover %%OUTPUT%% as the
  trimmed text after the first '## **Summary**' heading and before the
  subsequent '## **Outcome**' heading; new REQ-510 extends the slice through
  the output end when no subsequent outcome heading exists, and REQ-470,
  REQ-471, and REQ-472 were updated to the renamed report schema.
  Head truncation at the 1024-character Pushover Message API limit
  (REQ-445/REQ-453) is preserved unchanged; WORKFLOW.md call traces and
  REFERENCES.md were regenerated for the updated extraction contract.

## [0.102.0](https://github.com/Ogekuri/PI-useReq/compare/v0.101.0..v0.102.0) - 2026-11-08
### ⛰️  Features
- Update prompts files.

### 🚜  Changes
- deploy PATH pi-usereq launcher for pi package installs [useReq] *(bin-deploy)*
  Add src/core/bin-deploy.ts: best-effort idempotent pi-usereq launcher symlink under ~/.pi/agent/bin during extension activation of pi-package installs (REQ-504..REQ-507, DES-030).; --uninstall removes only the installation-owned launcher link before spawning the global uninstall child, preserving its exit code (REQ-508, REQ-509).; Preserve npm bin contract (PRJ-009, DES-028, CTN-021) and scripts/pi-usereq.sh wrapper (REQ-488).; Add tests/bin-deploy.test.ts covering deploy idempotence, divergent-symlink replacement, foreign-entry preservation, layout gating, and uninstall removal (TST-173..TST-175).; Update REQUIREMENTS.md (v0.0.121), WORKFLOW.md call traces, and regenerated REFERENCES.md.; Verification: static-check clean; full npm test 464/464 passing.
- surface GitHub probe failure reason in version report [useReq] *(package-manager)*
  Capture the upstream GitHub error-response `message` field (e.g. API rate limit exceeded) as an optional `reason` on the failed GitHub probe outcome (REQ-503).; Render failed GitHub probes as `GitHub latest: unknown (<reason>)` in --ver/--version, keeping plain `unknown` when no upstream reason is extractable (REQ-502, REQ-476).; Update REQUIREMENTS.md (REQ-502/REQ-503), WORKFLOW.md call-trace nodes, and regenerate REFERENCES.md.; Verification: static-check clean; full npm test suite 459/459 passing.

## [0.101.0](https://github.com/Ogekuri/PI-useReq/compare/v0.100.0..v0.101.0) - 2026-11-08
### ⛰️  Features
- add pre-release-check.sh official release gate [useReq] *(scripts)*
  Adds scripts/pre-release-check.sh running, from the repository root, environment preflight with the Node>=24 engine gate, clean npm ci install, optional build (--if-present), strict tsc --noEmit, and the full npm test suite.
  Adds DES-029 and REQ-491..REQ-494: stop at first failing stage with per-stage banners, exit 0 only when all stages pass, --skip-install reuse, --help usage, unknown options rejected with exit 2.
  Verified: full gate exit 0 (459/459 tests), induced stage failure exits 1 without running later stages, caller-cwd independence, static-check clean.

### 🐛  Bug Fixes
- make session-start replay fixture host-checker independent [useReq] *(tests)*
  The replaySessionStart offline harness test asserted zero recorded notifications while the fixture kept default-enabled static-check languages, so hosts without cppcheck/clang-format (CI runners) legitimately emitted the REQ-341 missing-checker warning and failed the build. Disable every effective static-check language in the persisted fixture config so checker availability cannot reach recorded session-start notifications; product behavior and all other suites unchanged (459/459 pass).

### 🚜  Changes
- gate release assets and npm publish on tests [useReq] *(release-workflow)*
  Requirements: add REQ-499..499..501 — run the full npm test suite inside build-release after npm ci for every canonical tag, create the GitHub Release and upload release assets only on a passing test stage, and require both the origin/master gate and the passing test stage for npm publication; bump SRS version to 0.0.119.
  Workflow: .github/workflows/release-npm.yml gains a Run test suite step between Build if present and Remove private package flag; Publish package to npm now requires needs.check-branch.outputs.is_master == 'true' && success(); Create GitHub Release and upload assets requires success(); failing tests skip changelog, release-asset upload, and publication.
  Verification: tests/release-workflow.test.ts 10/10, full suite 459/459, static-check clean, parsed-YAML step-order and gate-condition checks OK.
- remove gate-created build artifacts on exit [useReq] *(pre-release-check)*
  Requirements: add REQ-495..498 covering the pre-run git inventory snapshot, removal of stage-created untracked/ignored entries (build outputs, intermediate files), cleanup on success/failure/signal exits with preserved stage exit codes, and node_modules plus pre-existing-entry safety limits; bump SRS version to 0.0.118.
  Implementation: scripts/pre-release-check.sh snapshots git status --porcelain --untracked-files=normal --ignored before stage 1 and routes EXIT/INT/TERM through a cleanup pass that rm -rf's every ??/!! entry absent from the pre-run snapshot, skipping node_modules and tracked-status entries while preserving the gate exit code.
  Verification: full gate passed (npm ci, type-check, 459/459 tests); created artifacts removed, pre-existing entries and node_modules kept; exit code preserved on the failure path.

## [0.100.0](https://github.com/Ogekuri/PI-useReq/compare/v0.99.0..v0.100.0) - 2026-11-08
### ⛰️  Features
- Update prompts.

### 🐛  Bug Fixes
- report manifest latest instead of installed version [useReq] *(package-manager)*
  Carry the resolved npmjs manifest latest version on the current
  classification outcome of probeLatestRegistryVersion instead of
  discarding it, so an installed version newer than the published
  latest still reports the published latest verbatim.
  Map both newer and current probe outcomes to the manifest latest in
  resolveRegistryProbeLatestVersionText, fixing --ver and --upgrade
  printing the installed version as npmjs latest (REQ-475, REQ-489).
  Add failing-first reproducer test for installed-newer-than-latest
  case and update current-outcome assertions with latestVersion.

### 🚜  Changes
- remove external Python oracle dependencies [useReq] *(tests)*
- resolve npmjs latest from the package manifest [useReq] *(package-manager)*
  Probe the npmjs package manifest document (registry packument backing
  npmjs.com/package/pi-usereq) instead of the /latest shorthand so --ver
  searches available versions per npm best practices (REQ-477).
  Resolve the npmjs latest version from dist-tags.latest with fallback
  to the highest semver-ordered versions entry and release-over-
  prerelease ordering (REQ-489, TST-171).
  Print the manifest latest version on default-channel --upgrade in the
  already-latest line and resolve the completion summary updated version
  as the latest npmjs version (REQ-480, REQ-484).
  Update tests, WORKFLOW call traces, and SRS to version 0.0.115.
- add version, upgrade, and uninstall commands [useReq] *(package-manager)*
  Add src/core/package-manager.ts implementing --ver|--version, --upgrade
  [--dev|--develop], and --uninstall with injectable npm-registry plus
  GitHub-releases probes and guarded child execution (PRJ-009, DES-026,
  REQ-473..REQ-487).
  Dispatch management commands from src/cli.ts main before flag parsing
  (DES-027, REQ-473, REQ-474).
  Distribute the pi-usereq npm bin launcher scripts/pi-usereq.js via
  package.json bin metadata plus .gitignore include (DES-028).
  Add scripts/pi-usereq.sh wrapper forwarding arguments to the local tsx
  CLI entry with a missing-dependency guard (REQ-488).
  Add tests/package-manager.test.ts covering parsing, probes, upgrade
  channels, uninstall, launcher, and wrapper (TST-163..TST-170).
- send completed Pushover output from Outcome marker only [useReq] *(pi-notify)*
  REQ-469..REQ-472: for completed prompt-end outcomes, the Pushover title and
  message channels substitute only the final-agent-output substring starting at
  the first '## **Outcome**' occurrence through the output end; outputs without
  the marker keep the previous full-output behavior, interrupted and failed
  outcomes keep the full raw output, and PI_NOTIFY_CMD substitution is
  unaffected. Implemented via resolvePiNotifyPushoverAgentOutput plus an
  optional Pushover-channel %%OUTPUT%% override in substitutePiNotifyTextTemplate;
  REQ-445 head truncation still composes after the slice. Requirements,
  WORKFLOW.md call traces, and REFERENCES.md updated accordingly.

### 📚  Documentation
- Update TODO.md file.

## [0.99.0](https://github.com/Ogekuri/PI-useReq/compare/v0.98.0..v0.99.0) - 2026-11-05
### 🐛  Bug Fixes
- restore strict tsc, hermetic archives, agent_settled scenarios [useReq] *(tests)*
  Fix 84 strict tsc errors under tests/: .js import specifiers, explicit
  callback parameter types, non-null guards, typed fake-tool state casts
  (CTN-006, TST-010); src/ stays clean.
  Align theme-menu assertion to the CTN-001 default docs-dir usereq/docs.; Emit agent_settled in the worktree-failure and pushover-suppression
  scenarios so terminal failure handling follows REQ-463/REQ-464.
  Isolate project/static-check archive config from default-seeded checkers
  (REQ-250/REQ-251/REQ-316) and disable C explicitly in the
  unconfigured-language parity case for hermetic expectations.
  Make tests/fixtures/fixture_typescript.ts compile without external
  packages; regenerate the 11 fixture-dependent attended archives.

## [0.98.0](https://github.com/Ogekuri/PI-useReq/compare/v0.97.0..v0.98.0) - 2026-11-05
### 🚜  Changes
- gate npm publish on master, keep GitHub Release for develop tags [useReq] *(release-workflow)*
  Remove job-level master gate from build-release so every canonical tag runs the release job; Gate only the 'Publish package to npm' step on is_master output from check-branch; Update check-branch messaging: develop-only tags create the GitHub Release without npm publication; Requirements: rework REQ-139, add REQ-467/REQ-468, update DES-011, TST-039, evidence matrix

### 📚  Documentation
- Update README.md file.

## [0.97.0](https://github.com/Ogekuri/PI-useReq/compare/v0.96.0..v0.97.0) - 2026-11-05
### 🚜  Changes
- BREAKING CHANGE: migrate runtime and workflow actions to Node.js 24 [useReq] *(package)*
  Raise package.json engines.node floor from >=22.19.0 to >=24.0.0 (CTN-027); Bump softprops/action-gh-release v2 (node20) to v3 (node24); inputs unchanged; Keep checkout@v5, setup-node@v5, changelog-builder@v6 (verified node24 upstream); Add CTN-030 plus TST-162; update TST-039/TST-160; README Node 24 requirement; Requirements 0.0.111; no Node20 transitional opt-outs present (test-enforced)

## [0.96.0](https://github.com/Ogekuri/PI-useReq/compare/v0.95.0..v0.96.0) - 2026-11-05
### 🚜  Changes
- add npm publication compliance metadata and prepublish test gate [useReq] *(package)*
  Add package.json description, keywords, GPL-3.0-only license, author,
  engines.node >=22.19.0, and prepublishOnly=npm test for npm best practices
  Requirements CTN-025..CTN-029, DES-025, TST-159..TST-161 (REQUIREMENTS 0.0.110); Tests: manifest/lockfile version identity, license+discoverability+engines,
  publish test gate without --ignore-scripts (release-workflow suite 9/9)
  Verification: static-check clean; all remaining failures reproduce on base

## [0.95.0](https://github.com/Ogekuri/PI-useReq/compare/v0.94.0..v0.95.0) - 2026-11-05
### 🚜  Changes
- Publish via npm OIDC trusted publishing without NPM_TOKEN [useReq] *(release-npm)*
  REQ-466 added: npm publication authenticates through OIDC trusted
  publishing with the id-token: write permission and configured
  registry-url, without npm token secrets.
  REQ-140 and TST-039 updated: provenance/public publishing keeps npm ci,
  private-flag removal, tag gating on origin/master, and changelog-driven
  GitHub Release creation unchanged.
  release-npm.yml drops NODE_AUTH_TOKEN from the publish step.; release-workflow tests assert id-token: write and absence of
  NODE_AUTH_TOKEN/secrets.NPM_TOKEN.

## [0.94.0](https://github.com/Ogekuri/PI-useReq/compare/v0.93.0..v0.94.0) - 2026-11-04
### 🐛  Bug Fixes
- Fix .gitignore file.

### 🚜  Changes
- Determine terminal prompt workflow outcome at agent_settled only [useReq] *(prompt-workflow-state)*
  Add REQ-461..REQ-465: keep workflow state running during agentic
  execution, never flip status:error for host-recovered intermediate agent
  errors, and determine the terminal outcome (interrupted/completed/failed)
  only at orchestration end. On hosts emitting agent_settled, agent_end now
  only records the terminal-outcome candidate for worktree-backed runs; the
  error park, retention notification, ownership clear, and merging transition
  moved to agent_settled. Legacy hosts keep the agent_end fallback. Update
  WORKFLOW.md and regenerate REFERENCES.md. Two existing tests encode the
  superseded error-park-at-agent_end timing and now mismatch by design.

## [0.93.0](https://github.com/Ogekuri/PI-useReq/compare/v0.92.0..v0.93.0) - 2026-11-02
### ⛰️  Features
- Add .pi-usereq.json config file.

### 🚜  Changes
- BREAKING CHANGE: default docs-dir to usereq/docs instead of pi-usereq/docs [useReq] *(config)*
  Update CTN-001 default docs-dir from pi-usereq/docs to usereq/docs in REQUIREMENTS.md (bump to 0.0.107) and its evidence row.; Change DEFAULT_DOCS_DIR in src/core/config.ts and the duplicated fallback literal in src/core/path-context.ts buildRuntimePathContext to usereq/docs.; Regenerate pi-usereq/docs/REFERENCES.md from the updated source surface.; No backward-compatibility or migration logic implemented per request.
- BREAKING CHANGE: default docs-dir to req/docs [useReq] *(config)*
  Update CTN-001 default documentation directory from pi-usereq/docs to req/docs without backward-compatibility logic. Align DEFAULT_DOCS_DIR in src/core/config.ts and the runtime path fallback in src/core/path-context.ts, refresh the SRS default and its evidence row plus front matter, and update the menu-theme test expectation to the new default.

### ◀️  Revert
- Roll back branch to 36ca1f34 (36ca1f3489a85f1c911865ed11e373a4a42c6465).

## [0.92.0](https://github.com/Ogekuri/PI-useReq/compare/v0.91.0..v0.92.0) - 2026-10-22
### ⛰️  Features
- Update PI-Cli docs/sources from v1.1.0 to v1.4.0.

### 🚜  Changes
- BREAKING CHANGE: target pi CLI v1.4.0 extension interfaces [useReq] *(pi-host)*
  Probe pi CLI host version at extension bootstrap via the SDK VERSION
  export (REQ-456) and emit one session_start WARNING notification when
  the detected version is below v1.4.0, staying functional on older hosts
  (REQ-457, REQ-458).
  Pass deliverAs:"followUp" on every sendUserMessage prompt-delivery
  fallback so busy pi v1.4.0 sessions queue the dispatched prompt
  (REQ-459).
  Bump @earendil-works/pi-coding-agent, pi-ai, and pi-tui peer
  dependencies to ^1.4.0 with no backward compatibility (REQ-460).
  Extend the sdk-smoke event-surface probe with the pi v1.4.0 events
  (agent_before_settle, provider_stream_event, context_with_system,
  cache_warming_decision, mcp_servers_change) per amended REQ-356.
  Update SRS (REQ-456..460), WORKFLOW.md call traces, and REFERENCES.md.

## [0.91.0](https://github.com/Ogekuri/PI-useReq/compare/v0.90.0..v0.91.0) - 2026-10-22
### 🐛  Bug Fixes
- use ended run's own duration for prompt-end effects [useReq] *(pi-notify)*
  Prompt-end command-notify and Pushover effects now resolve %%TIME%% from the
  ended run's own duration. updateExtensionStatus persists the in-flight run
  record (start timestamp plus prompt-ownership flag) at agent_start, recovers
  it at agent_end/agent_settled when the in-memory timer was cleared mid-run,
  and records the ended run's duration even for aborted runs, separate from the
  REQ-125/159 completed counters. The agent_end dispatch gates the prompt
  request on post-update run association, so pending-only, duplicate, and
  error-retained terminal events no longer notify with a previous run's
  duration; notification and closure share one post-update completion snapshot.
  Tests: strengthened timer-loss regression plus six defect-focused scenarios.

## [0.90.0](https://github.com/Ogekuri/PI-useReq/compare/v0.89.0..v0.90.0) - 2026-10-22
### 🐛  Bug Fixes
- re-read live prompt state for agent_end pushover delivery [useReq] *(pi-notify)*
  agent_end notify dispatch now falls back to the live post-update
  active-or-pending prompt request with the last captured run duration
  when the entry-gated notify request is undefined (stale entry snapshot
  or run-timer loss between agent_start and agent_end on long-lived hosts)
  restores REQ-166/REQ-184/REQ-186 prompt-end Pushover delivery carrying
  the real %%OUTPUT%% text extracted from the last assistant message
  add failing-then-passing reproducer test for mid-run run-timer loss; update WORKFLOW.md node role and regenerate REFERENCES.md

### 🚜  Changes
- enforce Pushover API title and field length limits [useReq] *(pi-notify)*
  Add REQ-453, REQ-454, and REQ-455 encoding the Pushover Message API
  interface limits, and head-truncate the substituted Pushover title at
  250 characters with the shared fixed truncation marker by generalizing
  the message truncation helper into truncatePiNotifyPushoverText.
  Document that the request payload never emits url or url_title fields,
  enforcing the 512-character and 100-character limits by construction.
  Bump REQUIREMENTS.md to 0.0.105 and refresh WORKFLOW.md/REFERENCES.md.
- default Pushover text to result plus output [useReq] *(pi-notify)*
  Default notify-pushover-text is now RESULT token followed by OUTPUT
  token per REQ-185.
  Global config loading upgrades both superseded legacy defaults
  (ARGS-based and output-only) to the new default per REQ-451 while
  distinct user-configured templates stay unchanged per REQ-452.
  Updated REQUIREMENTS.md, WORKFLOW.md, REFERENCES.md and the
  extension-registration test expectations covering TST-158.
- upgrade legacy persisted pushover text to %%OUTPUT%% [useReq] *(pi-notify)*
  Add LEGACY_PI_NOTIFY_PUSHOVER_TEXT plus upgradeLegacyPiNotifyPushoverText
  and apply it during global config loading so persisted legacy-default
  %%RESULT%%\n%%ARGS%% templates resolve to %%OUTPUT%% again.
  Fix stale-config bug where req-references pushed only 'successed' and
  agentic req-* pushed 'successed' + user request: agentOutput plumbing was
  already correct; the superseded persisted template never referenced
  %%OUTPUT%%.
  Update mapped Pushover routing test: legacy default now pushes the final
  assistant output; distinct user templates stay unchanged.
  Add REQ-451, REQ-452, TST-158; update WORKFLOW.md and REFERENCES.md.

## [0.89.0](https://github.com/Ogekuri/PI-useReq/compare/v0.88.0..v0.89.0) - 2026-10-21
### 🐛  Bug Fixes
- push full execution report via %%OUTPUT%% [useReq] *(req-references)*
  Add buildCommandReportEntryText to serialize the durable report header
  plus per-operation outcome lines as one plain-text payload.
  Resolve req-references completed-run %%OUTPUT%% from the complete
  execution report and failed-run %%OUTPUT%% from the error report so
  Pushover and command-notify bodies carry all produced output.
  Add one reproducer test asserting the pushed Pushover message equals
  the full report; update WORKFLOW.md call traces and REFERENCES.md.
  Refs REQ-436, REQ-447, REQ-448.

## [0.88.0](https://github.com/Ogekuri/PI-useReq/compare/v0.87.0..v0.88.0) - 2026-10-21
### 🚜  Changes
- make Pushover body default to final LLM output [useReq] *(pi-notify)*
  Default the Pushover text template to the %%OUTPUT%% token so the pushed body is the last LLM assistant message instead of the invoked user request (REQ-185).; Dispatch prompt-end notify, sound, and Pushover effects for completed and failed non-agentic req-references and req-reset runs (REQ-447).; Resolve %%OUTPUT%% for req-references from per-operation report lines (REQ-448) and for req-reset from recovery plus cleanup outcome lines (REQ-449).; Fall back empty substituted Pushover bodies to the %%RESULT%% outcome token (REQ-450).; Drop the non-agentic empty-%%OUTPUT%% clause from REQ-444, align TST-156, WORKFLOW.md call traces, REFERENCES.md, and the two default-template test assertions.

## [0.87.0](https://github.com/Ogekuri/PI-useReq/compare/v0.86.0..v0.87.0) - 2026-10-21
### 🚜  Changes
- add %%OUTPUT%% prompt-end notification placeholder [useReq] *(pi-notify)*
  Extend PiNotifyEventRequest with optional agentOutput and add the %%OUTPUT%% runtime token to PI_NOTIFY_CMD plus Pushover title and text substitution (REQ-169, REQ-186).; Extract the final agent output from the last agent_end assistant message text blocks, skipping thinking and tool-call blocks; empty for non-agentic commands and text-less runs (REQ-443, REQ-444).; Head-truncate over-limit Pushover message bodies at the 1024-character API limit with a fixed marker (REQ-445) and document the token in the Pushover text menu row (REQ-446).; Update REQUIREMENTS.md (REQ-169, REQ-186, REQ-443..446, TST-048, TST-050, TST-155..157), WORKFLOW.md call traces, and regenerate REFERENCES.md.

## [0.86.0](https://github.com/Ogekuri/PI-useReq/compare/v0.85.0..v0.86.0) - 2026-10-21
### 🐛  Bug Fixes
- persist durable command-report session entry [useReq] *(req-references)*
  Add src/core/command-report-entry.ts defining the pi-usereq.command-report
  custom session-entry payload, per-operation report-line builders, and the
  guarded appendEntry/registerEntryRenderer helpers.
  Register the report transcript entry renderer at extension activation and
  append one durable report entry on every req-references run (success and
  failure) so the executed-commands outcome report survives the transient
  notify-status collapsing and session-restore chat rebuilds.
  Extend the fake pi runtime with entry-renderer and appended-entry recording
  and add a reproducer test covering report payload, renderer output, and the
  error path.
  Update WORKFLOW.md call traces and regenerate REFERENCES.md.

## [0.85.0](https://github.com/Ogekuri/PI-useReq/compare/v0.84.0..v0.85.0) - 2026-10-21
### 🚜  Changes
- preserve non-agentic notification evidence across session restore [useReq] *(core)*
  Add process-scoped deferred-notification replay store in src/core/notification-replay.ts (DES-024).; Defer stale-dropped output notifications instead of discarding them (REQ-439).; Replay queued notifications on session_start reasons new/resume/reload/fork (REQ-440).; Route req-references and req-reset outcome plus retention notifications through deferred delivery (REQ-441).; Keep replay UI-notification-only with no duplicates (REQ-442).; Update REQUIREMENTS.md, WORKFLOW.md, and regenerate REFERENCES.md.

## [0.84.0](https://github.com/Ogekuri/PI-useReq/compare/v0.83.0..v0.84.0) - 2026-10-20
### 🚜  Changes
- emit outcome-conformant execution notifications [useReq] *(req-references)*
  req-references now reports per-operation outcome facts (references
  changed, commit created or skipped) and always emits execution
  notifications stating whether REFERENCES.md was updated or unchanged
  and whether the fixed-message commit was created or skipped,
  regardless of the update and commit outcomes (REQ-436, REQ-437,
  REQ-438). Requirements, workflow model, and references docs updated.

## [0.83.0](https://github.com/Ogekuri/PI-useReq/compare/v0.82.0..v0.83.0) - 2026-10-12
### 🐛  Bug Fixes
- re-anchor live pi session to base-path before worktree deletion [useReq] *(req-reset)*
  Accept reserved-but-unpersisted parentSession links and materialize the
  minimal base-path session header (pi lazy persistence) so req-reset can
  always switch the pi CLI session off a generated worktree before deletion,
  fixing the intermittent branch:unknown status after /req-reset.
  Allocate a fresh base session (pi /new semantics) when no original or
  recent base session resolves; guard stale getter-only ctx.cwd reads.
  Surface session re-anchor failures (REQ-313) and retain the anchoring
  worktree plus branch instead of orphaning the session cwd at a deleted
  directory; update WORKFLOW.md and regenerate REFERENCES.md; add a
  pi-faithful reproducer test (getter-only cwd, stale-after-switch ctx).

### 🚜  Changes
- add content-coherent extensions to prompt log filenames [useReq] *(debug)*
  Update REQ-417, REQ-423, REQ-429, REQ-431 and add REQ-435; align TST-144, TST-146, TST-149, TST-150, TST-152 fixture shapes; bump document version to 0.0.98.
  debug-runtime saves prompt logs as .md (request and prompt), provider error payloads as .json via the new formatPromptDebugErrorPayloadFileName helper, and provider error text as .txt; the late response append reuses the extensionless error base.
  Align extension-registration test filename fixtures and update README, WORKFLOW.md, and regenerated REFERENCES.md documentation shapes.

## [0.82.0](https://github.com/Ogekuri/PI-useReq/compare/v0.81.0..v0.82.0) - 2026-10-12
### 🚜  Changes
- snapshot execution session for log-local error replay [useReq] *(debug-runtime)*
  REQ-432: flush copies the retained execution session byte-for-byte as an identically timestamped -session.jsonl file inside DEBUG_PROMPTS_LOG_PATH.; REQ-433: the -replay.json sidecar piFork command targets the log-local session snapshot with the retained session as fallback.; REQ-434: README documents the pi --fork log-files-only reproduction line.; Tests: add TST-153/TST-154 coverage and update the error-flush family to the new file-set contract.; Docs: REQUIREMENTS 0.0.97, WORKFLOW call-trace nodes, regenerated REFERENCES.

## [0.81.0](https://github.com/Ogekuri/PI-useReq/compare/v0.80.0..v0.81.0) - 2026-10-12
### 🚜  Changes
- Persist provider error response text and replay sidecar [useReq] *(debug)*
  Add REQ-429/430/431 and TST-150/151/152; extend REQ-419 replay docs; Write <ts>-<cmd>-error-<status>-response with provider error text
  (late message_end append after after_provider_response flush)
  Write <ts>-<cmd>-error-<status>-replay.json sidecar with provider,
  baseUrl, model id, thinking level, contextWindow, maxTokens, session
  file, and ready-to-use curl / pi one-shot / pi --fork commands
  Keep -error-<status> payload file raw provider-request JSON; Capture live model facts at before_provider_request; correlate the
  dispatched -prompt file for replay; update README, WORKFLOW, REFERENCES

### 🎯  Cover Requirements
- Cover provider error response and replay sidecar debug files [useReq] *(tests)*
  Update TST-146 test for the REQ-430 replay sidecar file set (4 files,
  no -response without error text)
  Add TST-150 test: -response persists message_end error text in both
  flush orders, including the late append beside the flushed payload
  Add TST-151 test: -replay.json sidecar carries provider, baseUrl, api,
  model id, thinking level, contextWindow, maxTokens, session file,
  prompt/request files, and provider/piOneShot/piFork commands
  Add TST-152 coverage: -error-<status> stays raw provider-request JSON

## [0.80.0](https://github.com/Ogekuri/PI-useReq/compare/v0.79.0..v0.80.0) - 2026-10-09
### 🐛  Bug Fixes
- anchor provider error capture gate to prompt base config [useReq] *(index)*
  Load the before_provider_request capture gating config from the prompt
  execution plan's original base-path via loadPromptRunBaseConfig, bypassing
  the runtime path state that resolves to the worktree checkout whose
  untracked .pi-usereq.json is absent (REQ-416, REQ-421, REQ-422, REQ-424).
  Root cause of the missing <timestamp>-<req-command>-error-400 file beside
  -request/-prompt in /tmp/PI-useReq runs 20261009162721215 and
  20261009174607538: the rebound worktree-session extension loaded default
  DEBUG_PROMPTS_ENABLED=disable, skipping capture; commits 698ebd9c and
  a066aa7b fixed state-preservation gaps but not the config divergence.
  Add reproducer test with the git-ignored local config; repair 12 stale
  debug tests to the runtime-only DEBUG_ENABLED contract (REQ-236/REQ-426,
  TST-144/146/147/149); update WORKFLOW.md and REFERENCES.md.

## [0.79.0](https://github.com/Ogekuri/PI-useReq/compare/v0.78.0..v0.79.0) - 2026-10-09
### 🐛  Bug Fixes
- preserve prompt run across compact-and-retry; flush retried 400 payloads [useReq] *(extension-status)*
  Promote pendingPromptRequest into activePromptRequest on agent_start only
  when a pending request exists, keeping the in-flight /req-* prompt run in
  controller state and process-scoped persistence across the pi host overflow
  compact-and-retry agent restart (agent_end -> session_before_compact ->
  session_compact -> agent_start -> retried provider request).
  Root cause: the unconditional promotion wiped the active request, so every
  retried before_provider_request skipped the provider payload capture and a
  400 on the retried request wrote no <timestamp>-<req-command>-error-<status>
  file beside -request/-prompt (REQ-421/422/424), and matched-success closure
  lost the run (retained worktree/branch).
  Accept the raw SDK error.message shape '<status> <body>' in
  resolveProviderErrorFlushStatusFromMessage as an additional flush trigger.
  Add reproducer test replaying the recorded compact-and-retry sequence;
  verified end-to-end against the real pi 1.1.0 runtime; update WORKFLOW.md
  and REFERENCES.md.

## [0.78.0](https://github.com/Ogekuri/PI-useReq/compare/v0.77.0..v0.78.0) - 2026-10-09
### 🐛  Bug Fixes
- flush provider error payloads from message_end fallback [useReq] *(debug-runtime)*
  Add resolveProviderErrorFlushStatusFromMessage to extract the leading HTTP
  status from finalized assistant error messages (pi formatProviderError shapes).
  Trigger flushCapturedPromptErrorPayload on message_end so OpenAI-compatible
  providers (zai) whose SDK clients throw before onResponse still save
  <timestamp>-<req-command>-error-<status> files beside -request/-prompt.
  Add reproducer test covering the switchSession rebind plus two failing
  provider requests; update WORKFLOW.md and REFERENCES.md.

## [0.77.0](https://github.com/Ogekuri/PI-useReq/compare/v0.76.0..v0.77.0) - 2026-10-09
### 🚜  Changes
- make Debug flag runtime-only and save request/prompt/error debug files [useReq] *(debug)*
  REQ-236/REQ-426: DEBUG_ENABLED is process-scoped runtime state, reset to disable at pi CLI start, surviving ctrl+N sessions and req-reset, never persisted; REQ-417/418/427/428: save <timestamp>-<req-command>-request (on-screen summary) and -prompt (delivered prompt) files for every enabled /req-* run; REQ-416: prompt-content debug files are exempt from the DEBUG_LOG_ON_STATUS workflow-state filter; REQ-421/422/425: robust error-stage capture/flush (live prompt state, config fallback, capture-carried write inputs, run-end discard) so provider 400s always dump the last payload; Update WORKFLOW.md, regenerate REFERENCES.md, SRS version 0.0.95

## [0.76.0](https://github.com/Ogekuri/PI-useReq/compare/v0.75.0..v0.76.0) - 2026-10-09
### ⛰️  Features
- capture provider error payloads for prompt debug [useReq] *(debug-runtime)*
  Add REQ-421..REQ-425 and TST-146..TST-147 to the SRS; extend REQ-114 with the after_provider_response wrapper.; Capture the exact before_provider_request provider payload for active req-* prompt runs when DEBUG_ENABLED and DEBUG_PROMPTS_ENABLED are enable.; Dump the captured payload beside the initial prompt file as <timestamp>-<req-command>-error-<status> when after_provider_response reports status >= 400.; Store captures in a process-scoped globalThis store so payloads survive the forked execution-session switch, and discard them after every write attempt.; Update WORKFLOW.md runtime model and regenerate REFERENCES.md; extend hook-wrappers and prompt-debug tests.

## [0.75.0](https://github.com/Ogekuri/PI-useReq/compare/v0.74.0..v0.75.0) - 2026-10-09
### ⛰️  Features
- Bundled prompt resources updated to v0.9.0 and change version.

### ◀️  Revert
- Roll back branch to 92120939 (92120939dafcb39d1abd9a8bec51b7a5d5c02272).

## [0.74.0](https://github.com/Ogekuri/PI-useReq/compare/v0.73.0..v0.74.0) - 2026-10-09
### ⛰️  Features
- Bundled prompt resources updated to v0.9.0.

## [0.73.0](https://github.com/Ogekuri/PI-useReq/compare/v0.72.0..v0.73.0) - 2026-10-09
### 🐛  Bug Fixes
- inject context files only at the trailing placeholder [useReq] *(prompts)*
  renderPrompt replaced every %%CONTEXT_FILES%% occurrence, so bundled
  prompts carrying an inline backticked token reference were corrupted
  mid-sentence and the context-file block was duplicated. Inject the
  block in place of only the last (dedicated) placeholder so inline
  prompt prose stays verbatim. Adds a failing-first reproducer test and
  updates WORKFLOW/REFERENCES documents.

## [0.71.0](https://github.com/Ogekuri/PI-useReq/compare/v0.70.0..v0.71.0) - 2026-10-09
### ⛰️  Features
- save dispatched prompt content for pi CLI replay [useReq] *(debug)*
  Add gated prompt-content debug logging (REQ-413..REQ-420): DEBUG_PROMPTS_ENABLED plus DEBUG_PROMPTS_LOG_PATH local config, new Debug submenu rows 'Enable debug prompts' and 'Log path for prompts' right after the global Debug toggle, one <timestamp>-<req-command> file per dispatched prompt written under the configured path with the exact sendMessage/sendUserMessage payload, README replay instructions, SRS/WORKFLOW/REFERENCES updates, and TST-143..TST-145 coverage.
- Pi CLI reference sources and documentation updated to v1.1.0.

## [0.70.0](https://github.com/Ogekuri/PI-useReq/compare/v0.69.0..v0.70.0) - 2026-10-06
### 🚜  Changes
- default Context Files flags to enabled [useReq] *(config)*
  REQ-328: context-files-requirements, context-files-references and
  context-files-workflow now default to enabled for new projects and
  missing or malformed persisted payloads.
  REQ-333: Context Files subtree reset restores the enabled default.; Updated REQUIREMENTS.md, regenerated REFERENCES.md, and refreshed
  Doxygen docs for DEFAULT_CONTEXT_FILES_FLAG and
  normalizeContextFilesFlag in src/core/config.ts.

## [0.69.0](https://github.com/Ogekuri/PI-useReq/compare/v0.68.0..v0.69.0) - 2026-10-06
### 🐛  Bug Fixes
- Update version in package-lock.json.

## [0.68.0](https://github.com/Ogekuri/PI-useReq/compare/v0.67.0..v0.68.0) - 2026-10-06
### ✨  Refactor
- move tokenizer warm-up and context-file encoding off the menu critical path [useReq] *(core)*
  Pre-warm the shared cl100k_base encoder and canonical context-file
  measurements during idle time at extension bind and session_start via
  chained setImmediate slices (prewarmTokenCounterEncoder,
  prewarmContextFileMeasurements), so the one-time js-tiktoken require
  plus BPE-rank parse and first content encodes never execute inside the
  synchronous menu-building critical path.
  Persist the encoding cache, the stat-signed context-file measurement
  cache, and a new stat-signed countFilesMetrics metrics cache on
  globalThis so session rebinds never re-trigger the heavy path.
  Add lean countTextTokensAndChars (tokens+chars only) and yielding
  async measureContextFileSize(s)Async used by the async menu, submenu,
  and req-* summary call sites; collapse the top-level reset preview to
  a single measurement batch.
  Token and character estimates stay bit-identical (135873c/31128t for
  REQUIREMENTS.md verified); REQ-010, REQ-017, REQ-373-REQ-377,
  REQ-400-REQ-412 outputs unchanged; prompt preflight (REQ-408) keeps
  synchronous stat-signature-fresh measurement.

## [0.66.0](https://github.com/Ogekuri/PI-useReq/compare/v0.65.0..v0.66.0) - 2026-10-05
### 🚜  Changes
- render per-file occupancy suffix in Context Files submenu [useReq] *(context-files)*
  REQ-406 now mandates each Context Files submenu row percentage be computed from that row's measured token count, not the enabled aggregate.; REQ-412 added: omit a submenu row occupancy suffix when that row's measured token count is zero.; TST-141 updated to verify per-row token-derived suffixes alongside top-level summary size facts.; buildContextFilesMenuChoices (src/index.ts) computes per-file suffixes via computeContextOccupancyFacts; aggregate suffixes on the top-level summary and command invocation summary remain unchanged.; REQUIREMENTS.md bumped to 0.0.91; WORKFLOW.md and REFERENCES.md runtime references refreshed.

## [0.65.0](https://github.com/Ogekuri/PI-useReq/compare/v0.64.0..v0.65.0) - 2026-10-05
### ⛰️  Features
- Add pi-prompts-version.txt file.
- Update pi cli docs and src.
- add pi-cli reference updater script [useReq] *(scripts)*
  Add scripts/pi-cli-update-src-docs.sh (DES-023): clones the official pi
  CLI repository with .git/.git fallback URLs (REQ-385), resolves the
  newest release tag merged into the default branch (REQ-386), prints
  latest plus stored versions with unknown for missing or empty
  markers (REQ-387, REQ-388), and proceeds only on exact Y
  confirmation (REQ-389).
  Fully synchronize read-only pi.dev-src/pi excluding every
  dot-prefixed entry with exact file-set match and preserved
  timestamps (REQ-390, REQ-391), refresh docs/pi.dev
  coding-agent-docs, coding-agent-examples, and durable-docs
  (REQ-392, REQ-393, REQ-394), and write the resolved version into
  both version marker files (REQ-395).
  Document the new PROC:pi-cli-update execution unit in WORKFLOW.md.

### 🐛  Bug Fixes
- preserve EOL-only reference files in pi CLI updater [useReq] *(scripts)*
  sync_directory now keeps existing target files whose bytes differ from the staged upstream file only in carriage-return line-ending characters, via staged_copy_replaces_existing, so consecutive runs against an unchanged pi CLI release leave the git working tree clean (pi.dev-src/pi/pi-test.bat, pi-test.ps1). Real content changes, added entries, and error paths are unchanged. Adds tests/pi-cli-update-sync.test.ts covering clean consecutive runs, applied content changes, added entries, and missing-source failure. Updates WORKFLOW.md PROC:pi-cli-update runtime model. [useReq]
- Update docs.

### 🚜  Changes
- add context-occupancy percentage display and early prompt dispatch check [useReq] *(context)*
  Add reusable context-occupancy helpers (sum, percent label, suffix,
  exceeded diagnostic) in src/core/context-file-size.ts (REQ-400..REQ-411).
  Append '[<pct>% context]' or '[<pct>%/1.0M* context]' to the Context
  Files top-level summary, submenu rows, and command invocation summary.
  Resolve the selected model max input context from the normalized
  contextUsage.contextWindow with the documented 1,000,000-token
  fallback (REQ-401, REQ-403).
  Enforce a prompt-dispatch early check in preparePromptCommandExecution
  after git validation and before worktree creation; exceeding runs abort
  with workflow error, a diagnostic listing per-file sizes, total tokens,
  and the occupancy suffix, no worktree, and no prompt dispatch.
  Update SRS to v0.0.90 (REQ-400..REQ-411), WORKFLOW call traces, and
  regenerate REFERENCES.md.
- add version marker and Y-confirmation flow to pi-prompts-update.sh [useReq] *(scripts)*
  Requirements: add REQ-396..REQ-399 covering the PI-Prompts version marker read/print/confirm/write contract and bump SRS version to 0.0.89.
  Source: scripts/pi-prompts-update.sh now reads src/resources/pi-prompts-version.txt (missing or empty files report unknown), prints the resolved latest release version plus the stored version, requires an exact 'Y' confirmation before any modification, moves the release-ref checkout after confirmation, and writes the resolved version into src/resources/pi-prompts-version.txt after successful synchronization, mirroring pi-cli-update-src-docs.sh behavior.
  Docs: WORKFLOW.md PROC:pi-prompts-update index role, lifecycle, call-trace, and external boundaries updated.

### ✨  Refactor
- Cache tokenizer and context-file size measurements [useReq] *(token-counter)*
  Memoize js-tiktoken encoders per encoding name so TokenCounter construction is O(1) after first use (files-tokens and tokens tools).; Clear the encoder cache on test loader swaps to keep dependency-failure behavior deterministic.; Memoize context-file size facts keyed by mtimeMs+size in a bounded cache; re-measure only changed files.; pi-usereq menu renders drop from ~1384ms to ~0.05ms warm; one-time first measurement per process.; Update WORKFLOW.md call traces and regenerate REFERENCES.md; counts verified identical.

## [0.64.0](https://github.com/Ogekuri/PI-useReq/compare/v0.63.0..v0.64.0) - 2026-10-05
### ⛰️  Features
- Update prompts.
- Add pi-prompts-update.sh bundled-resource updater [useReq] *(scripts)*
  Add DES-022 plus REQ-379..REQ-384 covering PI-Prompts fallback clone
  URLs, latest-release-on-master ref selection, full synchronization of
  instructions/prompts/templates into src/resources, and timestamp
  preservation for synchronized files.
  Add scripts/pi-prompts-update.sh implementing the updater with
  git-only release checkout, staging backup-and-swap full sync, and
  cp -p access/modification timestamp preservation.
  Update REQUIREMENTS.md scope/model entries, WORKFLOW.md
  PROC:pi-prompts-update runtime unit, and front matter version.

## [0.63.0](https://github.com/Ogekuri/PI-useReq/compare/v0.62.0..v0.63.0) - 2026-10-02
### 🚜  Changes
- mandate read-only pi.dev-src SoT reference governance *(core/prompts)*
  Add CTN-023/CTN-024: pi.dev-src pi CLI client sources are mandatory reference and source-of-truth for new implementations, source-code modifications, and bug fixes.; Strengthen CTN-017 and REQ-273: forbid pi.dev-src modifications in any way.; Add REQ-378: governance block declares read-only pi CLI client reference and SoT mandates.; Emit the new mandates from PI_DEV_CONFORMANCE_BLOCK in src/core/prompts.ts; update WORKFLOW.md and regenerate REFERENCES.md.

## [0.62.0](https://github.com/Ogekuri/PI-useReq/compare/v0.61.0..v0.62.0) - 2026-10-02
### 🐛  Bug Fixes
- re-apply captured model via rebound extension api [useReq] *(prompt-runtime)*
  pi 1.0.0 invalidates the extension api captured by a session's extension
  instance whenever that session is replaced (ctx.switchSession/fork/new/reload),
  so the guarded model re-apply built its session-scoped setModel surface from a
  stale captured pi and degraded the preserved model into the observed
  stale-extension-context warning while leaving the default model active.
  Store the latest live extension api in process-scoped prompt-command state on
  every extension bind (writePersistedPromptCommandRuntimeApi).
  Source the re-apply surface from the stored rebound api, falling back to the
  captured api for hosts that do not rebind (REQ-367..372, DES-021).
  Add failing-first reproducer test simulating the pi 1.0.0 rebind contract;
  assert captured model plus thinking level are applied once on the replacement
  session, closure skips duplicates, and no stale warning is emitted.
  Refresh WORKFLOW.md call traces and regenerate REFERENCES.md.

## [0.61.0](https://github.com/Ogekuri/PI-useReq/compare/v0.60.0..v0.61.0) - 2026-10-02
### 🐛  Bug Fixes
- Update .g.conf references.

### 🚜  Changes
- add runtime context-file size estimation for menus and req summaries [useReq] *(core)*
  Add src/core/context-file-size.ts with reusable cl100k_base token and
  character measurement helpers for REQUIREMENTS/REFERENCES/WORKFLOW docs.
  Context Files submenu and top-level summary now render measured
  '<chars>c/<tokens>t' size facts next to each on|off flag.
  Command invocation summaries append size suffixes to enabled context
  files for every bundled prompt-backed req-* command.
  SRS: add REQ-373..377 and TST-140..142; refresh WORKFLOW call traces
  and regenerate REFERENCES.md.
- preserve selected model across session switches [useReq] *(prompt-runtime)*
  Add REQ-366..372 with CTN-022, DES-021, and TST-134..139 to REQUIREMENTS.md; Capture active model identity plus thinking level into the execution plan at preflight; Add guarded reapplyPromptCommandSessionSelection helper in prompt-command-runtime; Re-apply captured selection after worktree activation, base-path closure restore, and req-reset redirect; Skip duplicate model_change via match guard; emit warning-only notification on failures
- BREAKING CHANGE: Align extension to pi CLI 1.0.0 and fix bundled checker spawn [useReq] *(core)*
  package.json/package-lock.json: raise @earendil-works pi-coding-agent, pi-ai, and pi-tui peer dependency ranges from 0.x to ^1.0.0 so the extension resolves against pi CLI 1.0.0.; pi-usereq/docs/REQUIREMENTS.md: document the pi >=1.0.0 dependency floor in section 5.2 and bump front matter to 0.0.83.; pi-usereq/docs/REFERENCES.md: regenerate from the updated source surface.; src/core/prompt-command-runtime.ts: narrow PromptCommandActiveContext sendUserMessage to the string delivery contract so the local session-context mirror stays structurally assignable to the pi 1.0.0 ReplacedSessionContext signatures.; src/core/static-check.ts: spawn the resolveCheckerExecutable result instead of the bare command name so bundled node_modules/.bin resolution drives execution as required by DES-018 and REQ-351.; No requirement or test changes were mandatory beyond the dependency floor: the pi 1.0.0 extension API surface (events, contexts, SessionManager, session format v3, theme tokens, SettingsList) is backward compatible, and extension-registration plus the pi-host simulation suites pass 158/158.

### 📚  Documentation
- Updated pi docs from 0.87.1 to 1.0.0.
- Updated pi from 0.87.1 to 1.0.0.

## [0.60.0](https://github.com/Ogekuri/PI-useReq/compare/v0.59.0..v0.60.0) - 2026-09-25
### 📚  Documentation
- Update images.

## [0.59.0](https://github.com/Ogekuri/PI-useReq/compare/v0.58.0..v0.59.0) - 2026-09-24
### 🐛  Bug Fixes
- return pi CLI to main branch before removing worktrees [useReq] *(req-reset)*
  Redirect the pi CLI session, process.cwd(), and context cwd to the
  main base path before deleting any matching generated worktree when no
  persisted prompt execution plan restored the base-path session first.
  Resolve the redirect target from the active session parentSession link,
  falling back to the most recent persisted base-path session.
  Export the stale-context-tolerant session-switch helper for reuse.; Add a reproducer unit test proving the switch precedes worktree removal.
  Closes the reported /req-reset defect where the CLI stayed on the
  deleted worktree path with an undefined branch after cleanup.

### 🚜  Changes
- emit context-retention reminder after req-* runs and document clean sessions [useReq] *(core)*
  REQUIREMENTS.md: add REQ-359..REQ-365 covering clean-context README advice, final retained-context info notification with context-usage percentage, stale-safe channel constraints, and failure-path exclusion; src/index.ts: add notifyContextRetentionReminder(...) emitted at req-reset and req-references tails plus successful prompt closure for worktree-backed and no-worktree runs; README.md: recommend starting a new session with clean context (/new) before each /req-* command unless retaining the previous context; WORKFLOW.md and REFERENCES.md: update call traces and symbol index
- remove vscode settings support [useReq] *(core)*
- remove model configuration support [useReq] *(sdk-smoke)*

## [0.58.0](https://github.com/Ogekuri/PI-useReq/compare/v0.57.0..v0.58.0) - 2026-09-23
### 🐛  Bug Fixes
- ensure main-branch switch before worktree cleanup [useReq] *(req-reset)*
  Normalize req-reset cleanup to the main repository worktree so generated
  worktree matching and git probes never run from inside a linked worktree.
  Switch the main worktree back to the main branch before forced branch
  deletion when HEAD rests on a generated prompt-command branch.
  Restore deleted process and context cwd surfaces after worktree removal.; Add reproducer tests for both blocked-cleanup scenarios.

## [0.57.0](https://github.com/Ogekuri/PI-useReq/compare/v0.56.0..v0.57.0) - 2026-09-23
### 🐛  Bug Fixes
- Fix npm audit.

## [0.56.0](https://github.com/Ogekuri/PI-useReq/compare/v0.55.0..v0.56.0) - 2026-09-23
### 🚜  Changes
- guard git commits against empty-commit failures [useReq] *(req-references)*
  Requirements: add REQ-357/REQ-358 and TST-133, refine REQ-301 for conditional commits.
  Source: route the sole runtime git commit through runGuardedGitCommit with a hasStagedChangesForPaths precheck, skipping empty commits and preventing 'nothing to commit, working tree clean' failures.
  Docs: update WORKFLOW.md req-references call-traces and regenerate REFERENCES.md.
  Verification: eslint clean, extension-registration suite 112/112, guarded empty-commit scenario verified end-to-end.

## [0.55.0](https://github.com/Ogekuri/PI-useReq/compare/v0.54.0..v0.55.0) - 2026-09-23
### 🐛  Bug Fixes
- regenerate lock file in sync with manifest [useReq] *(npm-setup)*
  Regenerate package-lock.json via npm install so npm ci no longer fails
  with EUSAGE; lock root version now matches package.json 0.54.0 and
  includes all resolved @earendil-works peer dependencies.
  Approve @google/genai install script in package.json allowScripts as
  recorded by the synced install.

## [0.54.0](https://github.com/Ogekuri/PI-useReq/compare/v0.53.0..v0.54.0) - 2026-09-23
### 🐛  Bug Fixes
- pin GitHub Actions runner to ubuntu-24.04 [useReq] *(release-npm)*
  Pin both jobs (check-branch, build-release) to the ubuntu-24.04 label so the release pipeline compiles on Ubuntu 24.04 LTS tooling, immune to the GitHub ubuntu-latest re-target to Ubuntu 26.04 (Oct-Nov 2026 breaking change). Add a reproducer unit test in tests/release-workflow.test.ts (TST-039) asserting every runs-on declaration is ubuntu-24.04 and that ubuntu-latest is absent. Update pi-usereq/docs/WORKFLOW.md release execution units to document the pinned Ubuntu 24.04 hosted runner.
- Change version.

### ◀️  Revert
- Roll back branch to 868345f5 (868345f5c7cf1681ae77c3b0286c015c9986a67e).

## [0.53.0](https://github.com/Ogekuri/PI-useReq/compare/v0.52.0..v0.53.0) - 2026-09-23
### 🐛  Bug Fixes
- Pin GitHub Actions runner to ubuntu-24.04 for ubuntu-latest migration [useReq] *(release-workflow)*
  Pin check-branch and build-release jobs to the ubuntu-24.04 runner image because GitHub is migrating the ubuntu-latest label from Ubuntu 24.04 to Ubuntu 26.04, which can break the release build's prebuilt-binary npm dependencies.; Add regression test asserting both jobs pin the stable runner image.

## [0.52.0](https://github.com/Ogekuri/PI-useReq/compare/v0.51.0..v0.52.0) - 2026-09-23
### 🚜  Changes
- BREAKING CHANGE: re-gate pi.dev governance and make worktree closure capability-aware [useReq] *(core)*
  Gate the pi.dev governance block on docs/pi.dev/coding-agent-docs/ existing (manifest optional) and rework the block text to never require the manifest (REQ-032/033/034/108/273/274/275).; Make worktree finalization capability-aware: defer matched-success closure to agent_settled on 0.80.4+ hosts and execute it at agent_end on legacy hosts that never emit the event (REQ-208/228/229/230/282/291/292/354/355).; Align peer dependencies and source imports to the @earendil-works scope at >=0.80.4 and extend the SDK-parity probe with authPath/modelsPath createAgentSession options plus the new event surface (REQ-056/356).; Update requirements, WORKFLOW.md, CHANGELOG.md, REFERENCES.md; update tests/prompt-rendering.test.ts and add the legacy-host fallback test (TST-011/020/030/087/132).

## [0.51.0](https://github.com/Ogekuri/PI-useReq/compare/v0.50.0..v0.51.0) - 2026-09-18
### 🐛  Bug Fixes
- Fix PI source files.
- Fix PI source files.
- defer worktree finalization to agent_settled [useReq] *(prompt-orchestration)*
  pi 0.67.1+ switchSession awaits the active agent run to become idle via
  session.abort()/waitForIdle(), which deadlocks when invoked from the
  agent_end handler because the run stays active until agent_settled.
  Move the matched-success restore/merge/worktree-delete into a new
  agent_settled hook, keeping agent_end for outcome classification and
  notify dispatch. Adds agent_settled to the intercepted hook set and a
  pendingFinalizationOutcome state field.
- Fix tests.

### 📚  Documentation
- Update PI Cli docs and source files.

## [0.50.0](https://github.com/Ogekuri/PI-useReq/compare/v0.49.0..v0.50.0) - 2026-07-13
### 🚜  Changes
- exclude tests from npm package via files allowlist [useReq] *(packaging)*
  Add package.json files allowlist ["src","scripts"] so npm consumer
  installs (e.g. .pi/agent/npm/node_modules/pi-usereq/) omit tests/.
  Satisfies CTN-021: published package ships only runtime-required
  src/ and scripts/, keeping tests for development only.
  Bump REQUIREMENTS.md to v0.0.79 with CTN-021 plus evidence.

## [0.49.0](https://github.com/Ogekuri/PI-useReq/compare/v0.48.0..v0.49.0) - 2026-07-13
### 🚜  Changes
- Reorder command summary: Configuration before User's Request [useReq] *(prompts)*
  Move the User's Request line after the Configuration block in the bundled prompt-backed command invocation summary so sections render as Command, Configuration, then User's Request, each separated by one blank line. Add REQ-353 and TST-131, update renderPromptCommandSummary in src/core/prompts.ts, and regenerate REFERENCES.md.

## [0.48.0](https://github.com/Ogekuri/PI-useReq/compare/v0.47.0..v0.48.0) - 2026-07-13
### 🐛  Bug Fixes
- approve scripts at correct install root [useReq] *(install-static-checkers)*
  getConsumerInstallRoot preferred INIT_CWD over npm_config_local_prefix.; pi runs 'npm install --prefix <root>' from its own cwd, so INIT_CWD is the
  caller cwd, not the install root; the allowScripts approval was written to
  the wrong project (or nowhere) and 'npm warn allow-scripts' persisted on
  every 'pi update --extensions'.
  Swap priority to prefer npm_config_local_prefix (the real install root in
  both --prefix and plain installs), falling back to INIT_CWD.
  Add reproducer unit test; update WORKFLOW.md call-trace description.; Satisfies DES-020, REQ-352.

## [0.47.0](https://github.com/Ogekuri/PI-useReq/compare/v0.46.0..v0.47.0) - 2026-07-13
### 🐛  Bug Fixes
- Fix packages file.

## [0.46.0](https://github.com/Ogekuri/PI-useReq/compare/v0.45.0..v0.46.0) - 2026-07-13
### 🐛  Bug Fixes
- Fix extension installer.

## [0.45.0](https://github.com/Ogekuri/PI-useReq/compare/v0.44.0..v0.45.0) - 2026-07-13
### 🐛  Bug Fixes
- Fix packages.
- Fix packages.

### 🚜  Changes
- add view/reset menu actions, removal confirmation, embedded keyword resolution, approve-scripts [useReq] *(static-check)*
  REQ-008/248/345-349: add View static code checker (read-only, before
  Remove), Reset static code checker (after Remove, restores embedded
  defaults), and require config preview plus confirmation before Remove.
  DES-019/REQ-350/351: resolveCheckerExecutable substitutes the
  %%INSTALLATION_PATH%% keyword and fixes hoisted node_modules/.bin probing.
  DES-020/REQ-352: postinstall best-effort runs npm approve-scripts for
  bundled checker dependencies before probing.
  Update REQUIREMENTS/WORKFLOW/REFERENCES and the static-check menu test.

## [0.44.0](https://github.com/Ogekuri/PI-useReq/compare/v0.43.0..v0.44.0) - 2026-07-13
### 🚜  Changes
- BREAKING CHANGE: park failed worktree runs in error without resuming base-path [useReq] *(prompt-closure)*
  REQ-209/REQ-230/TST-058: failed/interrupted/aborted/incomplete worktree-backed runs no longer resume the original base-path session.; src/index.ts agent_end closure: the closure-failure branch keeps the worktree execution session visible, notifies the error, parks workflow in error, and retains the active request for req-reset recovery.; tests/extension-registration.test.ts: realign the prompt-failure test to assert session retention + workflow error.

## [0.43.0](https://github.com/Ogekuri/PI-useReq/compare/v0.42.0..v0.43.0) - 2026-07-10
### 🚜  Changes
- make tsx a runtime dependency so postinstall resolves [useReq] *(packaging)*
  Move tsx from devDependencies to dependencies in package.json and the root entry of package-lock.json. The package ships .ts source with noEmit and no dist build, so node --import tsx is required for package scripts, the postinstall checker installer, and the .ts extension entry. tsx was only a devDependency, hence absent on consumer installs, causing ERR_MODULE_NOT_FOUND during pi update --extensions.
  Requirements: add CTN-020; update Section 5.2 note; bump front-matter to 0.0.75; Verified: npm install --legacy-peer-deps runs postinstall with exit 0

## [0.42.0](https://github.com/Ogekuri/PI-useReq/compare/v0.41.0..v0.42.0) - 2026-07-10
### 🚜  Changes
- bundle pyright/ruff/eslint and add bundled-bin resolution [useReq] *(static-check)*
  Add pyright, ruff, and eslint as pinned npm dependencies with a best-effort postinstall installer (scripts/install-static-checkers.ts) that probes bundled node_modules/.bin, attempts npm install on miss, prints native-checker guidance, and always returns 0.
  Add resolveCheckerExecutable bundled-bin-plus-PATH resolver and checkDefaultCheckersAvailability session_start helper. Change TypeScript default static-check entry from npx+eslint to eslint. Emit one warning notification during session_start for missing enabled checkers without aborting.
  Add tests/static-check-bundled.test.ts covering resolveCheckerExecutable precedence, postinstall exit-code-0 invariant, and session_start missing-checker reporting. Update REQUIREMENTS.md (REQ-339..REQ-344, DES-017/018, TST-123..125), WORKFLOW.md, README.md, and REFERENCES.md.

## [0.41.0](https://github.com/Ogekuri/PI-useReq/compare/v0.40.0..v0.41.0) - 2026-07-10
### 🐛  Bug Fixes
- await and suppress summary sendMessage to prevent unhandled rejection breaking worktree merge [useReq] *(prompt-delivery)*
  deliverPromptCommand now awaits the non-critical display:true summary sendMessage and suppresses its failures before dispatching the authoritative hidden display:false prompt turn with triggerTurn:true; a rejecting fire-and-forget summary sendMessage previously surfaced as an unhandled rejection (Node default --unhandled-rejections=throw) that could terminate the process before prompt-end closure ran the worktree merge, branch deletion, and worktree deletion; add regression tests covering the production sendMessage triggerTurn path, the pi.sendMessage fallback, and a rejecting summary that must not interrupt the merge; update WORKFLOW.md call-traces and regenerate REFERENCES.md
- resolve tsc errors in req command and session-entry types [useReq] *(types)*
  Narrow runCapture/runGitCapture return types to SpawnSyncReturns<string>
  so UTF-8 stdout/stderr string methods are type-safe in
  req-references-command, req-reset-command, runtime-project-paths.
  Remove index signature from PromptCommandSessionEntry so the SDK
  SessionEntry union is structurally assignable, resolving all
  SessionEntry/ExtensionContext -> PromptCommandSessionContext mismatches.
  Narrow transitionPromptWorkflowState nextState parameter from
  DebugWorkflowState to PiUsereqWorkflowState to match setPiUsereqWorkflowState.
  Regenerate REFERENCES.md.
- add TST-122 summary test and resolve tsc errors [useReq] *(prompt-command)*
  Add prompt-command-summary unit test verifying renderPromptCommandSummary renders none for empty context files, static code checks, and enabled tools (TST-122, REQ-338).; Narrow runCapture return type to SpawnSyncReturns<string> and initialize switchResult to resolve tsc errors in src/core/prompt-command-runtime.ts; re-export PromptCommandName for prompts.ts.; Fix getAllTools type predicate in scripts/lib/recording-extension-api.ts to include required promptGuidelines: string[].; Regenerate REFERENCES.md.

### 🚜  Changes
- render none for empty summary lists [useReq] *(prompts)*
  Add REQ-338 and TST-122 requiring the command invocation summary to
  render 'none' for context files, static code checks, and enabled
  tools fields when their enabled-item list is empty.
  Update renderPromptCommandSummary to fall back to 'none' for the
  context-files, static-check-languages, and enabled-tools lists.
  Update WORKFLOW.md node descriptions and regenerate REFERENCES.md.
- default context files to disabled [useReq] *(config)*
  Update REQ-328 default to disabled and REQ-333 reset-to-disabled; Change DEFAULT_CONTEXT_FILES_FLAG from true to false; Update Doxygen docs on normalizeContextFilesFlag and constant; Bump SRS version to 0.0.72

## [0.40.0](https://github.com/Ogekuri/PI-useReq/compare/v0.39.0..v0.40.0) - 2026-07-10
### 🚜  Changes
- hide full prompt on screen, show command summary [useReq] *(prompt-delivery)*
  Deliver rendered prompt to LLM via sendMessage(display:false, triggerTurn:true); Display command invocation summary (command name, args, config) on screen; Fall back to sendUserMessage when sendMessage is unavailable; Add renderPromptCommandSummary in src/core/prompts.ts; Update deliverPromptCommand in src/index.ts for all req-<prompt> commands; Add requirements DES-016, REQ-334..337, TST-121; Update WORKFLOW.md call-traces and REFERENCES.md

## [0.39.0](https://github.com/Ogekuri/PI-useReq/compare/v0.38.0..v0.39.0) - 2026-07-09
### ⛰️  Features
- Add Context Files menu and %%CONTEXT_FILES%% prompt injection [useReq] *(context-files)*
  Add top-level `Context Files` menu between `Unit tests directory` and `Auto git commit` with per-file toggles for REQUIREMENTS.md, REFERENCES.md, WORKFLOW.md; Persist context-files-requirements/references/workflow boolean flags in local config, defaulting enabled; Replace %%CONTEXT_FILES%% with per-file markdown sections (file-name heading, pre-substituted HTML file reference, four-backtick fences) in documented order; Update REQ-190/191 ordering, add REQ-326..333/TST-117..120, and refresh WORKFLOW/REFERENCES
- Update prompts.

### 🚜  Changes
- Align stale tests with Context Files menu and verbatim injection [useReq] *(tests)*
  Add Context Files to expected top-level menu list in extension-registration test; Disable context-file injection in prompt-rendering placeholder/read-only tests so template-body assertions hold per REQ-332; Refine TST-060 to exclude the verbatim %%CONTEXT_FILES%% block from placeholder-absence assertions

## [0.38.0](https://github.com/Ogekuri/PI-useReq/compare/v0.37.0..v0.38.0) - 2026-07-09
### ⛰️  Features
- Add Google_TypeScript_Style_Guide.md and RFC2119.md.

## [0.37.0](https://github.com/Ogekuri/PI-useReq/compare/v0.36.0..v0.37.0) - 2026-07-08
### 🐛  Bug Fixes
- Update README.md file.

## [0.35.0](https://github.com/Ogekuri/PI-useReq/compare/v0.34.0..v0.35.0) - 2026-05-29
### 🐛  Bug Fixes
- Remove version from ts files.

### 🚜  Changes
- prepend runtime metadata in status bar [useReq] *(extension-status)*
  Update the SRS for the status-bar prefix ordering and runtime metadata contract.
  Read package metadata at runtime, prepend <extension>:v<version> before status, and keep the documented theme split.
  Refresh status-bar tests, WORKFLOW.md, and REFERENCES.md for the new runtime call path.

## [0.34.0](https://github.com/Ogekuri/PI-useReq/compare/v0.33.0..v0.34.0) - 2026-05-29
### 🚜  Changes
- add debug-summarize and YAML check [useReq] *(debug-menu)*
  Update the SRS for debug-menu ordering and debug wrapper coverage.
  Implement debug-summarize, move the tool-wrapper row before Log file, and refresh runtime docs.
  Add release-workflow YAML syntax coverage and align npm publish steps with the documented release contract.

## [0.33.0](https://github.com/Ogekuri/PI-useReq/compare/v0.32.0..v0.33.0) - 2026-05-29
### 🐛  Bug Fixes
- Clean workflow file after all tests and bug fixes.

## [0.32.0](https://github.com/Ogekuri/PI-useReq/compare/v0.31.0..v0.32.0) - 2026-05-29
### 🐛  Bug Fixes
- Revert workflow.

### 🚜  Changes
- update Node.js 24.15.0 release flow [useReq] *(release-workflow)*
  update REQUIREMENTS.md and WORKFLOW.md traceability for the release runtime; pin .github/workflows/release-npm.yml to Node.js 24.15.0 and restore npm publish auth; align tests/release-workflow.test.ts with the pinned runtime and publish contract

## [0.31.0](https://github.com/Ogekuri/PI-useReq/compare/v0.30.0..v0.31.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround, again, and again.

## [0.30.0](https://github.com/Ogekuri/PI-useReq/compare/v0.29.0..v0.30.0) - 2026-05-29
### 🐛  Bug Fixes
- Revert setup-node version.

## [0.29.0](https://github.com/Ogekuri/PI-useReq/compare/v0.28.0..v0.29.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround, again, and again.

## [0.28.0](https://github.com/Ogekuri/PI-useReq/compare/v0.27.0..v0.28.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround, again, and again.

## [0.27.0](https://github.com/Ogekuri/PI-useReq/compare/v0.26.0..v0.27.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround, again, and again.

## [0.26.0](https://github.com/Ogekuri/PI-useReq/compare/v0.25.0..v0.26.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround, again.

## [0.25.0](https://github.com/Ogekuri/PI-useReq/compare/v0.24.0..v0.25.0) - 2026-05-29
### 🐛  Bug Fixes
- Try another workaround.

## [0.24.0](https://github.com/Ogekuri/PI-useReq/compare/v0.23.0..v0.24.0) - 2026-05-29
### 🐛  Bug Fixes
- Remove install -g npm@latest from workflow.

## [0.23.0](https://github.com/Ogekuri/PI-useReq/compare/v0.22.0..v0.23.0) - 2026-05-29
### 🐛  Bug Fixes
- Workaround actions/setup-node OIDC bug.

## [0.22.0](https://github.com/Ogekuri/PI-useReq/compare/v0.21.0..v0.22.0) - 2026-05-29
### 🐛  Bug Fixes
- Update workflow file.

## [0.21.0](https://github.com/Ogekuri/PI-useReq/compare/v0.20.0..v0.21.0) - 2026-05-29
### 🐛  Bug Fixes
- Update workflow file.

## [0.20.0](https://github.com/Ogekuri/PI-useReq/compare/v0.19.0..v0.20.0) - 2026-05-29
### 🐛  Bug Fixes
- Update workflow file for 2FA publish.

## [0.19.0](https://github.com/Ogekuri/PI-useReq/compare/v0.18.0..v0.19.0) - 2026-05-29
### 🐛  Bug Fixes
- Update version number.

### ◀️  Revert
- Roll back branch to 6b800ba9 (6b800ba99e97ec88f7d9d10d6abe125020d3aebb).

## [0.18.0](https://github.com/Ogekuri/PI-useReq/compare/v0.17.0..v0.18.0) - 2026-05-29
### 🐛  Bug Fixes
- Fix workflow file.

## [0.17.0](https://github.com/Ogekuri/PI-useReq/compare/v0.16.0..v0.17.0) - 2026-05-29
### ⛰️  Features
- Re-add tocken.

## [0.16.0](https://github.com/Ogekuri/PI-useReq/compare/v0.15.0..v0.16.0) - 2026-05-29
### 🐛  Bug Fixes
- Fix workflow.

### 🚜  Changes
- adopt trusted npm publishing [useReq] *(release-npm)*
  update release requirements for Node 24 and OIDC trusted publishing; update workflow, package metadata, and release workflow tests; refresh release runtime documentation

## [0.14.0](https://github.com/Ogekuri/PI-useReq/compare/v0.13.0..v0.14.0) - 2026-05-29
### ⛰️  Features
- add debug tool slash commands [useReq] *(debug)*
  Add DEBUG_TOOL_COMMANDS_ENABLED local config and Debug submenu row.
  Register config-gated debug-compress, debug-references,
  debug-static-check, and debug-tokens wrappers.
  Update requirements, workflow, references, and tests for traceability.
- Update .gitignore file.
- Remove REFERENCES.md.

### 📚  Documentation
- Update REFERENCES.md document. [useReq] *(references)*

## [0.13.0](https://github.com/Ogekuri/PI-useReq/compare/v0.12.0..v0.13.0) - 2026-04-27
### 🚜  Changes
- BREAKING CHANGE: split local and global configuration [useReq] *(config)*
  update REQUIREMENTS, WORKFLOW, and REFERENCES for the split config model; persist tool, notification, git, and checker-command settings globally; keep project paths, debug, and static-check enable flags locally; rename Show configuration to Show local configuration and add Show global configuration; refresh tests for local/global persistence and CLI static-check behavior

## [0.12.0](https://github.com/Ogekuri/PI-useReq/compare/v0.11.0..v0.12.0) - 2026-04-25
### ⛰️  Features
- add req-reset recovery command and docs [useReq] *(req-reset)*
  Add dedicated req-reset recovery without prompt dispatch or worktree creation.
  Extend requirements, workflow, and references traceability for req-reset.
  Add extension-registration coverage for req-reset registration, success, and failure paths.

### 🐛  Bug Fixes
- keep toggle rows open and refresh status [useReq] *(settings-menu)*
  keep inline menu toggles focused without closing menus; refresh direct status renders from live context usage; show Pushover credential guidance when enablement is locked

### 🚜  Changes
- BREAKING CHANGE: reject busy req commands and finalize active runs [useReq] *(orchestration)*
  update REQUIREMENTS.md for req-reset and non-idle req-command behavior; enforce error-state rejection for req-references and bundled req prompts; preserve successful worktree finalization after busy-command rejection; extend extension-registration tests and refresh WORKFLOW/REFERENCES docs
- BREAKING CHANGE: specialize direct references workflow [useReq] *(req-references)*
  remove the bundled req-references prompt template; add direct references generation, staging, commit, and clean-repo checks; update requirements, workflow, references, and extension tests
- add status-only REFERENCES writer [useReq] *(references)*
  update requirements for references tool registration and output contract; implement the status-only references tool and default enablement; add extension tests and refresh workflow plus references docs
- derive req descriptions from markdown headings [useReq] *(prompt-command)*
  update REQ-004 and TST-080 for heading-based descriptions; remove YAML description extraction from bundled prompts; refresh workflow and references traceability
- BREAKING CHANGE: rename references tools to summarize [useReq] *(tool-runner)*
  Update REQUIREMENTS, WORKFLOW, and REFERENCES for files-summarize and summarize.; Rename CLI flags, tool registrations, startup-tool defaults, and debug harness examples.; Refresh oracle, parity, registration, and archived fixture tests.
- align low context gauge colors with status field [useReq] *(extension-status)*
  update REQ-126, TST-035, and TST-096 for low-band context gauge color\n- render context icons below 90% with the status warning token\n- refresh workflow, references, and status-bar tests for traceability
- BREAKING CHANGE: stash dirty base-path around merge [useReq] *(prompt-command-runtime)*
  update requirements, workflow, and references; add stash-assisted merge warning coverage
- decouple runtime sound from boot config [useReq] *(notifications)*
  update sound requirements and runtime docs; keep hotkey sound changes runtime-only; keep menu edits persisted as boot value only; refresh references and extension tests

## [0.11.0](https://github.com/Ogekuri/PI-useReq/compare/v0.10.0..v0.11.0) - 2026-04-24
### 🚜  Changes
- BREAKING CHANGE: revise status bar branch gauge and debug defaults [useReq] *(extension-status)*
  update requirements for branch field, context thresholds, and debug log defaults; remove Reset defaults right-side values across menus; align source, tests, workflow, and references with the breaking change
- preserve worktree transcript on session restore [useReq] *(prompt-command-runtime)*
  Update REQ-208 to require client-visible transcript preservation after closure.
  Copy execution-session JSONL entries into the restored base session before merge and cleanup.
  Refresh workflow and references docs for the new prompt-finalization path.
- remove current-path from status footer [useReq] *(status-bar)*
  Trace: useReq-20260424-1530
  update requirements, workflow, and references; stop rendering current-path in extension status output; align harness and registration status tests

## [0.10.0](https://github.com/Ogekuri/PI-useReq/compare/v0.7.0..v0.10.0) - 2026-04-24
### ⛰️  Features
- Add source code from a extranal branch.

## [0.7.0](https://github.com/Ogekuri/PI-useReq/compare/v0.6.0..v0.7.0) - 2026-04-20
### ⛰️  Features
- Add src/resources/images/ files.

### 🐛  Bug Fixes
- defer js-tiktoken loading for token tools [useReq] *(extension)*
  lazy-load js-tiktoken inside token counting instead of at extension import time; return structured token-tool failures when the dependency is unavailable; add coverage for deferred loading and dependency error handling

### 🚜  Changes
- BREAKING CHANGE: rename menus and notify defaults [useReq] *(config-menu)*
  update requirements for tilde config-path display and guided static-check menus; remove legacy startup-tool status and static-check raw-spec/reference actions; add %%RESULT%% defaults for notify and Pushover templates with tests/docs refresh
- BREAKING CHANGE: move event toggles into shared submenus [useReq] *(notifications)*
  update requirements for completed/interrupted/failed event contracts; replace direct notification toggles with shared event submenus; rename persisted notification keys and refresh extension docs/tests
- BREAKING CHANGE: remove terminal bell notification support [useReq] *(core)*
  update requirements and workflow docs for the breaking removal; delete terminal bell config and runtime handling; refresh notification UI tests and references
- BREAKING CHANGE: replace status context bar and notification menus [useReq] *(config-ui)*
  update requirements for breaking status and configuration UI behavior; switch context footer rendering to icon-based thresholds; remove notify, beep, and pushover footer fields; flatten Pushover settings into Notifications and add scoped submenu resets; preserve menu focus after toggles and edits; update configuration UI tests and debug harness assertions
- BREAKING CHANGE: unify notify beep sound and pushover [useReq] *(pi-notify)*
  update SRS for breaking notification model changes; replace legacy terminal notification implementations with PI_NOTIFY_CMD and terminal bell routing; add global and per-event toggles for notify, beep, sound, and pushover; update status bar, configuration menus, workflow, references, and tests

## [0.6.0](https://github.com/Ogekuri/PI-useReq/compare/v0.5.0..v0.6.0) - 2026-04-20
### 🚜  Changes
- BREAKING CHANGE: optimize tool response payloads [useReq] *(core)*
  Update requirements for token-minimized tool responses.
  Move static response facts into tool registration metadata.
  Reduce runtime payload sections and remove repeated request echoes.
  Update workflow, references, and targeted tool-contract tests.

## [0.5.0](https://github.com/Ogekuri/PI-useReq/compare/v0.4.0..v0.5.0) - 2026-04-19
### ⛰️  Features
- add pushover completion notifications [useReq] *(notify)*
  Add Pushover configuration, status-bar, and successful prompt delivery.
  Update requirements, workflow, references, and extension tests for REQ-163..172.

### 🐛  Bug Fixes
- Fix ignore file.
- Fix move req in pi-usereq/docs dir.
- Fix move req in pi-usereq/docs dir.

### 🚜  Changes
- BREAKING CHANGE: revise elapsed footer and config menu path [useReq] *(status-bar)*
  update requirements for footer, context bar, and show-config ordering; implement elapsed/footer rendering and config-path menu display; refresh workflow/references docs and extension registration tests
- BREAKING CHANGE: remove Pylance and Ruff modules [useReq] *(static-check)*
  update requirements, workflow, and references; simplify static-check menus to Command only; keep Dummy debug-only and remove obsolete fixtures
- BREAKING CHANGE: simplify status bar timing and defaults [useReq] *(extension-status)*
  update requirements for the breaking status-bar contract; remove git and tools fields and switch base to absolute path; consolidate timing into et with active, last, and total segments; enable all beep flags by default and refresh docs plus tests

### ◀️  Revert
- Roll back branch to bb44b543 (bb44b543846f3d73abc82f852784ec3c4a503d54).

## [0.4.0](https://github.com/Ogekuri/PI-useReq/compare/v0.3.0..v0.4.0) - 2026-04-19
### 🚜  Changes
- add npm provenance metadata and release checks [useReq] *(package)*
  add canonical repository, bugs, and homepage metadata for npm provenance; update SRS with REQ-157, REQ-158, and TST-044; align release workflow Node setup action with release test expectations; extend release-workflow tests for package provenance metadata

## [0.3.0](https://github.com/Ogekuri/PI-useReq/compare/v0.2.0..v0.3.0) - 2026-04-19
### 🐛  Bug Fixes
- Fix .github/workflows/release-npm.yml file.

### 🚜  Changes
- BREAKING CHANGE: align extension theme tokens with cli themes [useReq] *(settings-menu)*
  update requirements for CLI-theme token semantics; switch status overflow overlay from legacy redBright to error; reuse shared settings-list theming with offline fallback; extend menu and status tests for theme-token contracts

## [0.2.0](https://github.com/Ogekuri/PI-useReq/compare/v0.1.0..v0.2.0) - 2026-04-19
### ⛰️  Features
- Add release-npm.yml file.
- add configurable prompt beep and sound hooks [useReq] *(notify)*
  extend SRS with pi-notify beep and sound requirements; add pi-notify config, status, and agent_end handlers; add configurable shortcut, menu controls, and sound commands; update extension and debug harness tests for new status fields

### 🐛  Bug Fixes
- Fix .github/workflows/release-npm.yml file.

### 🚜  Changes
- publish pi-usereq in release workflow [useReq] *(release-npm)*
  update REQ-138 REQ-141 and add REQ-155/TST-042; keep existing tag trigger and changelog release flow intact; add npm setup and publish steps plus workflow assertions
- BREAKING CHANGE: derive runtime paths and restyle config menus [useReq] *(pi-usereq)*
  Update requirements for runtime-only base/git paths.
  Adopt shared settings-style menus with show-config submenu.
  Switch notify defaults to %%INSTALLATION_PATH%% and alt+s.
  Add status-bar git/base fields and CLEAR/FULL overlays.
  Refresh references and workflow documentation.
- wire npm publish workflow and requirements [useReq] *(release-npm)*
  update REQUIREMENTS.md with release workflow requirements and evidence; implement tag-gated npm publication and GitHub Release automation; add workflow-focused verification test and runtime model updates

## [0.1.0](https://github.com/Ogekuri/PI-useReq/releases/tag/v0.1.0) - 2026-04-19
### ⛰️  Features
- Add src/resources/sounds/ files.
- add hook-driven status telemetry [useReq] *(extension-status)*
  extend requirements for lifecycle hook interception and status fields; add shared extension status controller for context, elapsed, and last; update offline replay and registration tests for the new status contract
- enforce pi.dev manifest API contract guidance [useReq] *(prompts)*
  Add DES-009, REQ-108, and TST-030.; Require rendered pi.dev conformance blocks to treat the manifest as the authoritative API contract.; Extend prompt-rendering verification and refresh workflow/reference docs.; Trace-ID: REQ-108-20260418
- Update prompts.
- add req-debug wrapper and requirement traceability [useReq] *(debug-harness)*
  extend REQUIREMENTS.md with wrapper requirements for debug harness access; add scripts/req-debug.sh for inspect, session, prompt, tool, sdk, and raw flows; refresh WORKFLOW.md and REFERENCES.md for the new bash execution surface
- add offline harness and sdk smoke [useReq] *(debug-extension)*
  extend REQUIREMENTS.md for standalone extension debugging and parity validation; add scripts/debug-extension.ts with recording, replay, and sdk-smoke modules; add harness-focused tests and refresh WORKFLOW.md/REFERENCES.md
- archive expected CLI outputs [useReq] *(tests)*
  add archive-backed CLI output scenarios and verification tests; commit expected results under tests/fixtures_attended_results; extend requirements for normalized expected-result archives; align invalid enable-static-check error text with archived output
- add command option parity coverage [useReq] *(cli)*
  add CLI static-check enablement merge and validation support; route verbose command options through standalone dispatch; fix clean-repository git-check validation behavior; add TypeScript parity regressions and supporting test helpers; update requirements, workflow, references, tsconfig, and eslint config
- Fix source code doxygen documentation.
- Update manifest.
- add pi.dev manifest conformance guidance [useReq] *(prompts)*
  add REQ-032..REQ-034 and TST-011 for pi.dev-aware prompts; inject manifest-gated conformance rules during prompt rendering; cover manifest present and absent prompt-rendering cases
- Initial commit.

### 🐛  Bug Fixes
- route reset-context prompts via session_start [useReq] *(prompt)*
  queue reset-context prompt payloads in new-session setup instead of using the stale runtime; consume queued prompt payloads from the replacement session_start handler exactly once; add a runtime-replacement reproducer test and refresh workflow/reference docs
- start reset-context sessions with user delivery [useReq] *(prompt)*
  send req-* prompt content after ctx.newSession() so the new session starts a turn; replace the reset-context reproducer to assert post-reset user delivery; refresh workflow and references docs for the shared prompt-delivery path
- append reset prompt during session setup [useReq] *(prompt-delivery)*
  route reset-context prompt delivery through ctx.newSession setup; add req-workflow regression coverage for reset-session prompt startup; refresh workflow and references docs for the updated runtime path
- deliver reset prompts via sendUserMessage [useReq] *(prompt-commands)*
  restore post-reset prompt delivery through pi.sendUserMessage; add req-create regression coverage for reset-context=true; refresh WORKFLOW and REFERENCES for the updated call path
- inject reset prompt during new session setup [useReq] *(index)*
  move reset-context prompt delivery into ctx.newSession setup; update prompt command regression coverage; refresh workflow and references documentation
- send prompt after reset-session creation [useReq] *(prompt-command)*
  Add a targeted reproducer for reset-context prompt delivery.
  Deliver req-* prompts by creating the new session first.
  Send the rendered prompt through pi.sendUserMessage after reset.
  Update WORKFLOW and REFERENCES for the changed call trace.
- Fix version number to 0.0.0.

### 🚜  Changes
- add context bar overlay thresholds [useReq] *(extension-status)*
  REQ-127/REQ-128 add claer and full! overlay states.
  TST-035/TST-036 verify empty and above-90-percent context cases.
  Update workflow and references for the new status rendering path.
- BREAKING CHANGE: remove context-reset prompt flow and status field [useReq] *(index)*
  Update SRS for branchless current-session prompt delivery.
  Remove reset-context config, menu entries, status output, and replacement-session flow.
  Align offline recording and extension-registration tests with the breaking change.
- compact pi-usereq status summary [useReq] *(status-bar)*
  REQ-009/109/110/111: switch to single-line status output
  Record active-tool count and compact context mode
  Align offline replay with reset-context prompt capture
- render colored multiline config status [useReq] *(status-bar)*
  update REQUIREMENTS.md for multi-line colored status-bar fields\n- implement explicit docs/tests/src, tools, and reset-context rendering\n- refresh workflow/references docs and extend status replay tests
- BREAKING CHANGE: rename wrapper and disable find by default [useReq] *(debug-harness)*
  Update REQUIREMENTS, WORKFLOW, and REFERENCES.
  Switch debug wrapper path to scripts/pi-usereq-debug.sh.
  Disable custom find in default startup-tool configuration.
  Refresh debug manual examples to pi-usereq/docs paths.
  Adjust targeted tests for wrapper rename and default tool state.
- default docs-dir to pi-usereq/docs [useReq] *(config)*
  update CTN-001 for the new default docs directory; switch DEFAULT_DOCS_DIR to pi-usereq/docs; align fixture and registration tests with the new default; regenerate REFERENCES.md for updated symbol locations
- derive runtime paths from installation context [useReq] *(core)*
  update SRS for installation-path and execution-path derivation; persist config under .pi-usereq and copy that directory into worktrees; resolve prompt resources from installation-owned resources tree; expose runtime path facts in structured tool payloads; refresh workflow and references docs for the new path context
- remove unused bundled model metadata [useReq] *(resources)*
  update PRJ-005 and repository evidence for bundled resources; delete unused models and vscode settings resource files; keep runtime behavior limited to prompt, template, and guideline provisioning
- rename bundled templates path [useReq] *(resources)*
  rename src/resources/docs to src/resources/templates; replace %%TEMPLATE_PATH%% during prompt rendering; update requirements, workflow, references, and prompt tests
- structure tool json outputs and registrations [useReq] *(tools)*
  update general requirements for JSON-first agent-tool payloads and registrations; implement structured utility-tool payload builders and registration metadata; extend tests for compression and utility-tool payload and inspection coverage
- BREAKING CHANGE: refactor find tool payloads for agents [useReq] *(find)*
  update requirements for agent-oriented files-find/find payloads; implement structured find payload builders and tool descriptions; add focused registration and debug-harness tests
- refactor compression tool payloads for LLM JSON [useReq] *(compress)*
  update requirements, workflow, and references for the structured compression contract; add structured compression payload generation with line, symbol, and Doxygen metadata; keep CLI markdown compression output while tool responses and debug examples use JSON
- emit agent-oriented JSON for reference tools [useReq] *(references)*
  update requirements, workflow, and references docs for structured reference payloads; add structured Doxygen and symbol JSON extraction for files-references and references; refresh targeted tests and archived reference fixtures
- optimize token tool JSON payloads for agents [useReq] *(token-counter)*
  update requirements for agent-optimized files-tokens and tokens payloads; restructure token payloads with direct-access metrics and guidance sections; enrich tool registration metadata and add targeted extension tests
- refactor token tool JSON for agent parsing [useReq] *(token-tools)*
  REQ-010 REQ-017 REQ-069 REQ-072
  Refactor files-tokens and tokens agent-tool payloads into structured JSON.
  Add numeric summaries, canonical path fields, and guidance ordering.
  Update tool registration metadata, debug examples, and runtime docs.
- add reset-context pre-reset for req commands [useReq] *(prompt-commands)*
  update requirements, workflow, and references for reset-context; add persisted reset-context config with default true and UI toggle; route req-* commands through /new-equivalent session setup when enabled; extend offline replay and tests for reset and current-session flows
- support tool --args param conversion [useReq] *(req-debug)*
  add REQ-065 and TST-021 for req-debug tool arg normalization; convert wrapper tool --args text into debug-harness --params JSON; add wrapper integration coverage and refresh workflow/references docs
- configure active tools for embedded pi builtins [useReq] *(index)*
  update REQUIREMENTS.md for configurable embedded active tools; enable config defaults for read bash edit write and disable grep ls; extend runtime and harness inventories with supported builtin tools; cover menu and session_start behavior with targeted tests
- remove tool slash command wrappers [useReq] *(index)*
  update REQUIREMENTS.md for tool-only extension exposure\n- remove custom slash command registration for tool wrappers\n- keep agent tool registration and CLI static-check driver behavior\n- refresh workflow, references, and registration tests

### 📚  Documentation
- Update README.md file.
- add runtime workflow model [useReq] *(core)*
  create req/docs/WORKFLOW.md from src runtime analysis; document execution units, call traces, and communication edges
- add source reference index [useReq] *(core)*
  generate req/docs/REFERENCES.md from repository source; capture modules, symbols, and imports for agent navigation
- Add pi.dev api documentation.


# History

- \[0.1.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.1.0
- \[0.2.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.2.0
- \[0.3.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.3.0
- \[0.4.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.4.0
- \[0.5.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.5.0
- \[0.6.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.6.0
- \[0.7.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.7.0
- \[0.10.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.10.0
- \[0.11.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.11.0
- \[0.12.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.12.0
- \[0.13.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.13.0
- \[0.14.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.14.0
- \[0.15.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.15.0
- \[0.16.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.16.0
- \[0.17.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.17.0
- \[0.18.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.18.0
- \[0.19.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.19.0
- \[0.20.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.20.0
- \[0.21.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.21.0
- \[0.22.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.22.0
- \[0.23.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.23.0
- \[0.24.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.24.0
- \[0.25.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.25.0
- \[0.26.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.26.0
- \[0.27.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.27.0
- \[0.28.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.28.0
- \[0.29.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.29.0
- \[0.30.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.30.0
- \[0.31.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.31.0
- \[0.32.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.32.0
- \[0.33.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.33.0
- \[0.34.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.34.0
- \[0.35.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.35.0
- \[0.36.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.36.0
- \[0.37.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.37.0
- \[0.38.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.38.0
- \[0.39.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.39.0
- \[0.40.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.40.0
- \[0.41.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.41.0
- \[0.42.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.42.0
- \[0.43.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.43.0
- \[0.44.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.44.0
- \[0.45.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.45.0
- \[0.46.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.46.0
- \[0.47.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.47.0
- \[0.48.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.48.0
- \[0.49.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.49.0
- \[0.50.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.50.0
- \[0.51.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.51.0
- \[0.52.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.52.0
- \[0.53.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.53.0
- \[0.54.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.54.0
- \[0.55.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.55.0
- \[0.56.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.56.0
- \[0.57.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.57.0
- \[0.58.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.58.0
- \[0.59.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.59.0
- \[0.60.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.60.0
- \[0.61.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.61.0
- \[0.62.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.62.0
- \[0.63.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.63.0
- \[0.64.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.64.0
- \[0.65.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.65.0
- \[0.66.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.66.0
- \[0.67.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.67.0
- \[0.68.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.68.0
- \[0.69.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.69.0
- \[0.70.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.70.0
- \[0.71.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.71.0
- \[0.72.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.72.0
- \[0.73.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.73.0
- \[0.74.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.74.0
- \[0.75.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.75.0
- \[0.76.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.76.0
- \[0.77.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.77.0
- \[0.78.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.78.0
- \[0.79.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.79.0
- \[0.80.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.80.0
- \[0.81.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.81.0
- \[0.82.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.82.0
- \[0.83.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.83.0
- \[0.84.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.84.0
- \[0.85.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.85.0
- \[0.86.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.86.0
- \[0.87.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.87.0
- \[0.88.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.88.0
- \[0.89.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.89.0
- \[0.90.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.90.0
- \[0.91.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.91.0
- \[0.92.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.92.0
- \[0.93.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.93.0
- \[0.94.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.94.0
- \[0.95.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.95.0
- \[0.96.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.96.0
- \[0.97.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.97.0
- \[0.98.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.98.0
- \[0.99.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.99.0
- \[0.100.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.100.0
- \[0.101.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.101.0
- \[0.102.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.102.0
- \[0.103.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.103.0
- \[0.104.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.104.0
- \[0.105.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.105.0
- \[0.106.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.106.0
- \[0.107.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.107.0
- \[0.108.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.108.0
- \[0.109.0\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.109.0
- \[0.109.36\]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.109.36

[0.1.0]: https://github.com/Ogekuri/PI-useReq/releases/tag/v0.1.0
[0.2.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.1.0..v0.2.0
[0.3.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.2.0..v0.3.0
[0.4.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.3.0..v0.4.0
[0.5.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.4.0..v0.5.0
[0.6.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.5.0..v0.6.0
[0.7.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.6.0..v0.7.0
[0.10.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.7.0..v0.10.0
[0.11.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.10.0..v0.11.0
[0.12.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.11.0..v0.12.0
[0.13.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.12.0..v0.13.0
[0.14.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.13.0..v0.14.0
[0.15.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.14.0..v0.15.0
[0.16.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.15.0..v0.16.0
[0.17.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.16.0..v0.17.0
[0.18.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.17.0..v0.18.0
[0.19.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.18.0..v0.19.0
[0.20.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.19.0..v0.20.0
[0.21.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.20.0..v0.21.0
[0.22.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.21.0..v0.22.0
[0.23.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.22.0..v0.23.0
[0.24.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.23.0..v0.24.0
[0.25.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.24.0..v0.25.0
[0.26.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.25.0..v0.26.0
[0.27.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.26.0..v0.27.0
[0.28.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.27.0..v0.28.0
[0.29.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.28.0..v0.29.0
[0.30.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.29.0..v0.30.0
[0.31.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.30.0..v0.31.0
[0.32.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.31.0..v0.32.0
[0.33.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.32.0..v0.33.0
[0.34.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.33.0..v0.34.0
[0.35.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.34.0..v0.35.0
[0.36.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.35.0..v0.36.0
[0.37.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.36.0..v0.37.0
[0.38.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.37.0..v0.38.0
[0.39.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.38.0..v0.39.0
[0.40.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.39.0..v0.40.0
[0.41.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.40.0..v0.41.0
[0.42.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.41.0..v0.42.0
[0.43.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.42.0..v0.43.0
[0.44.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.43.0..v0.44.0
[0.45.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.44.0..v0.45.0
[0.46.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.45.0..v0.46.0
[0.47.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.46.0..v0.47.0
[0.48.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.47.0..v0.48.0
[0.49.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.48.0..v0.49.0
[0.50.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.49.0..v0.50.0
[0.51.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.50.0..v0.51.0
[0.52.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.51.0..v0.52.0
[0.53.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.52.0..v0.53.0
[0.54.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.53.0..v0.54.0
[0.55.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.54.0..v0.55.0
[0.56.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.55.0..v0.56.0
[0.57.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.56.0..v0.57.0
[0.58.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.57.0..v0.58.0
[0.59.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.58.0..v0.59.0
[0.60.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.59.0..v0.60.0
[0.61.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.60.0..v0.61.0
[0.62.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.61.0..v0.62.0
[0.63.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.62.0..v0.63.0
[0.64.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.63.0..v0.64.0
[0.65.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.64.0..v0.65.0
[0.66.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.65.0..v0.66.0
[0.67.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.66.0..v0.67.0
[0.68.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.67.0..v0.68.0
[0.69.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.68.0..v0.69.0
[0.70.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.69.0..v0.70.0
[0.71.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.70.0..v0.71.0
[0.72.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.71.0..v0.72.0
[0.73.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.72.0..v0.73.0
[0.74.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.73.0..v0.74.0
[0.75.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.74.0..v0.75.0
[0.76.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.75.0..v0.76.0
[0.77.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.76.0..v0.77.0
[0.78.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.77.0..v0.78.0
[0.79.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.78.0..v0.79.0
[0.80.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.79.0..v0.80.0
[0.81.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.80.0..v0.81.0
[0.82.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.81.0..v0.82.0
[0.83.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.82.0..v0.83.0
[0.84.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.83.0..v0.84.0
[0.85.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.84.0..v0.85.0
[0.86.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.85.0..v0.86.0
[0.87.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.86.0..v0.87.0
[0.88.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.87.0..v0.88.0
[0.89.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.88.0..v0.89.0
[0.90.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.89.0..v0.90.0
[0.91.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.90.0..v0.91.0
[0.92.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.91.0..v0.92.0
[0.93.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.92.0..v0.93.0
[0.94.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.93.0..v0.94.0
[0.95.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.94.0..v0.95.0
[0.96.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.95.0..v0.96.0
[0.97.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.96.0..v0.97.0
[0.98.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.97.0..v0.98.0
[0.99.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.98.0..v0.99.0
[0.100.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.99.0..v0.100.0
[0.101.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.100.0..v0.101.0
[0.102.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.101.0..v0.102.0
[0.103.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.102.0..v0.103.0
[0.104.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.103.0..v0.104.0
[0.105.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.104.0..v0.105.0
[0.106.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.105.0..v0.106.0
[0.107.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.106.0..v0.107.0
[0.108.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.107.0..v0.108.0
[0.109.0]: https://github.com/Ogekuri/PI-useReq/compare/v0.108.0..v0.109.0
[0.109.36]: https://github.com/Ogekuri/PI-useReq/compare/v0.109.0..v0.109.36
